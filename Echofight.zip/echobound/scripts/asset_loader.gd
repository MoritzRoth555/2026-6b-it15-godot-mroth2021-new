extends RefCounted
## Finds and prepares 3D models dropped into assets/models/<name>/.
## Supported: .glb .gltf .fbx .blend (needs Blender path in Godot editor settings) .obj
## Everything returns null when nothing is found, so callers can fall back to primitives.

const EXTS := ["glb", "gltf", "fbx", "blend", "obj"]


static func find_scene(folder: String, preferred_base := "") -> PackedScene:
	var dir := DirAccess.open(folder)
	if dir == null:
		return null
	var best: PackedScene = null
	for f in dir.get_files():
		var name := f.trim_suffix(".import").trim_suffix(".remap")
		if not EXTS.has(name.get_extension().to_lower()):
			continue
		var res := load(folder.path_join(name))
		if res is PackedScene:
			if preferred_base != "" and name.get_basename() == preferred_base:
				return res
			if best == null:
				best = res
	return best


## Instances the scene, scales it to `height` and puts its feet at y=0, centred on x/z.
static func instance_fitted(scene: PackedScene, height: float) -> Node3D:
	var inst := scene.instantiate() as Node3D
	if inst == null:
		return null
	var holder := Node3D.new()
	holder.add_child(inst)
	var box := _aabb(inst)
	if box.size.y > 0.0001:
		var s := height / box.size.y
		inst.scale = Vector3.ONE * s
		var c := box.get_center()
		inst.position = Vector3(-c.x * s, -box.position.y * s, -c.z * s)
	return holder


static func apply_override(root: Node, mat: Material) -> void:
	for n in root.find_children("*", "MeshInstance3D", true, false):
		(n as MeshInstance3D).material_override = mat


static func _aabb(root: Node3D) -> AABB:
	var result := AABB()
	var first := true
	for n in root.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		var t := Transform3D.IDENTITY
		var cur: Node = mi
		while cur != root and cur is Node3D:
			t = (cur as Node3D).transform * t
			cur = cur.get_parent()
		var box := t * mi.get_aabb()
		result = box if first else result.merge(box)
		first = false
	return result
