extends Node3D
## A ghost replaying one EchoRecording. Positions are driven by the recorded timestamps
## (interpolated), attacks / dashes / jumps fire exactly once from the event list.
## No hurtbox -> takes no damage. Never records anything itself.

signal finished(echo: Node3D)

const Recording := preload("res://scripts/echo_recording.gd")
const Hitbox := preload("res://scripts/hitbox.gd")
const Fx := preload("res://scripts/fx.gd")
const AssetLoader := preload("res://scripts/asset_loader.gd")
const Projectile := preload("res://scripts/projectile.gd")

const KNIGHT_DIR := "res://assets/models/knight"
const ECHO_COLOR := Color(0.25, 0.55, 1.0)
const SWORD_REST := Vector3(-70.0, 0.0, 0.0)

@export var damage_scale := 1.0
@export var base_alpha := 0.42

var recording: Recording
var playing := false

var _t := 0.0
var _i := 0
var _ev := 0
var _flags := 0
var _bob := 0.0
var _visual: Node3D
var _sword: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _arm_l: Node3D
var _hitbox: Hitbox
var _mat: StandardMaterial3D
var _ring_mat: StandardMaterial3D
var _trail: CPUParticles3D
var _swing_tween: Tween
var _sword_tween: Tween
var _fade_tween: Tween


func setup(rec: Recording) -> void:
	recording = rec


func _ready() -> void:
	add_to_group("echo")
	_build_material()
	_build_visual()
	_build_extras()
	_build_hitbox()


func start() -> void:
	if recording == null or recording.get_sample_count() == 0:
		return
	_t = 0.0
	_i = 0
	_ev = 0
	_apply_sample(0.0)
	playing = true
	_mat.albedo_color.a = 0.0
	_fade_tween = create_tween()
	_fade_tween.tween_property(_mat, "albedo_color:a", base_alpha, 0.5)
	_trail.emitting = true
	get_tree().call_group("audio", "play", "echo_spawn", global_position)
	Fx.burst(self, global_position + Vector3(0, 1.0, 0), ECHO_COLOR, 20, 3.0, 0.6)


func _physics_process(delta: float) -> void:
	if not playing:
		return
	_t += delta
	# Events first (each fires exactly once, in order, when its timestamp is reached).
	while _ev < recording.events.size() and float(recording.events[_ev]["t"]) <= _t:
		_fire_event(recording.events[_ev])
		_ev += 1
	if _t >= recording.duration:
		_apply_sample(recording.duration)
		_finish()
		return
	_apply_sample(_t)
	_animate(delta)


# ---------------------------------------------------------------- playback --

func _apply_sample(t: float) -> void:
	var n := recording.get_sample_count()
	_i = recording.find_index(t, _i)
	var j := mini(_i + 1, n - 1)
	var a := recording.times[_i]
	var b := recording.times[j]
	var k := 0.0 if b <= a else clampf((t - a) / (b - a), 0.0, 1.0)
	global_position = recording.positions[_i].lerp(recording.positions[j], k)
	rotation.y = lerp_angle(recording.yaws[_i], recording.yaws[j], k)
	_flags = recording.flags[_i]


## Walk cycle driven by the recorded state flags, plus a shimmering glow.
func _animate(delta: float) -> void:
	var moving: bool = (_flags & Recording.FLAG_MOVING) != 0 and (_flags & Recording.FLAG_AIRBORNE) == 0
	var sprint: bool = (_flags & Recording.FLAG_SPRINT) != 0
	var swing := 0.0
	if moving:
		_bob += delta * (14.0 if sprint else 9.0)
		_visual.position.y = absf(sin(_bob)) * 0.07
		swing = sin(_bob) * (0.9 if sprint else 0.65)
	else:
		_visual.position.y = move_toward(_visual.position.y, 0.0, delta)
	var k := 1.0 - exp(-18.0 * delta)
	if _leg_l != null:
		_leg_l.rotation.x = lerpf(_leg_l.rotation.x, swing, k)
		_leg_r.rotation.x = lerpf(_leg_r.rotation.x, -swing, k)
		_arm_l.rotation.x = lerpf(_arm_l.rotation.x, -swing * 0.8, k)
	_mat.emission_energy_multiplier = 1.3 + sin(_t * 4.0) * 0.25
	_ring_mat.albedo_color.a = _mat.albedo_color.a * 0.9


func _fire_event(ev: Dictionary) -> void:
	var type: StringName = ev["type"]
	if type == &"attack":
		_do_attack(ev)
	elif type == &"dash":
		Fx.burst(self, global_position + Vector3(0, 0.9, 0), ECHO_COLOR, 12, 2.5, 0.3)
	elif type == &"jump":
		Fx.burst(self, global_position + Vector3(0, 0.1, 0), ECHO_COLOR, 6, 2.0, 0.3)
	elif type == &"bolt":
		_do_bolt(ev)


func _do_attack(ev: Dictionary) -> void:
	# Never start a second swing while one is still running (no duplicate attacks).
	if _swing_tween != null and _swing_tween.is_running():
		return
	_hitbox.damage = float(ev.get("damage", 25.0)) * damage_scale
	get_tree().call_group("audio", "play", "echo_swing", global_position)
	_swing_tween = create_tween()
	_swing_tween.tween_property(_visual, "rotation_degrees:x", -14.0, 0.09)
	_swing_tween.tween_callback(_hitbox.begin_swing)
	_swing_tween.tween_property(_visual, "rotation_degrees:x", 10.0, 0.11)
	_swing_tween.tween_callback(_hitbox.end_swing)
	_swing_tween.tween_property(_visual, "rotation_degrees:x", 0.0, 0.25)
	if _sword != null:
		_sword_tween = create_tween()
		_sword_tween.tween_property(_sword, "rotation_degrees", Vector3(-30.0, 50.0, -30.0), 0.09)
		_sword_tween.tween_property(_sword, "rotation_degrees", Vector3(-100.0, -50.0, 20.0), 0.11)
		_sword_tween.tween_property(_sword, "rotation_degrees", SWORD_REST, 0.25)


## Replays a recorded echo bolt in the direction the player was facing (incl. pitch).
func _do_bolt(ev: Dictionary) -> void:
	var basis := global_transform.basis
	var dir := (basis * Vector3(0, 0, -1)).rotated(basis.x, recording.pitches[_i]).normalized()
	var bolt := Projectile.new()
	bolt.damage = float(ev.get("damage", 35.0)) * damage_scale
	bolt.direction = dir
	bolt.source = self
	bolt.tint = ECHO_COLOR
	get_tree().current_scene.add_child(bolt)
	bolt.global_position = global_position + Vector3(0, 1.4, 0) + dir * 0.9
	get_tree().call_group("audio", "play", "bolt", global_position)


func _finish() -> void:
	playing = false
	_hitbox.end_swing()
	_trail.emitting = false
	if _swing_tween:
		_swing_tween.kill()
	if _sword_tween:
		_sword_tween.kill()
	Fx.burst(self, global_position + Vector3(0, 1.0, 0), ECHO_COLOR, 24, 3.5, 0.8)
	Fx.burst(self, global_position + Vector3(0, 0.8, 0), Color(0.5, 0.9, 1.0), 12, 1.2, 1.5, 1.5)
	if _fade_tween:
		_fade_tween.kill()
	_fade_tween = create_tween()
	_fade_tween.tween_property(_mat, "albedo_color:a", 0.0, 0.6)
	_fade_tween.parallel().tween_property(_ring_mat, "albedo_color:a", 0.0, 0.6)
	_fade_tween.tween_callback(_on_faded)


func _on_faded() -> void:
	finished.emit(self)
	queue_free()


func _on_hit(hit_area: Area3D) -> void:
	Fx.burst(self, hit_area.global_position + Vector3(0, 0.4, 0), ECHO_COLOR, 8, 3.5, 0.3)


# ------------------------------------------------------------------ visuals --

func _build_material() -> void:
	_mat = StandardMaterial3D.new()
	_mat.albedo_color = Color(ECHO_COLOR.r, ECHO_COLOR.g, ECHO_COLOR.b, base_alpha)
	_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mat.emission_enabled = true
	_mat.emission = Color(0.15, 0.4, 1.0)
	_mat.emission_energy_multiplier = 1.3
	_mat.rim_enabled = true
	_mat.rim = 0.8
	_mat.rim_tint = 0.3


func _build_hitbox() -> void:
	_hitbox = Hitbox.new()
	_hitbox.name = "EchoHitbox"
	_hitbox.collision_layer = 16  # hitbox
	_hitbox.collision_mask = 64   # hurtbox_enemy
	_hitbox.source = self
	_hitbox.position = Vector3(0, 1.2, -1.3)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.5, 1.2, 1.7)
	col.shape = shape
	_hitbox.add_child(col)
	add_child(_hitbox)
	_hitbox.hit_landed.connect(_on_hit)


func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


func _pivot(parent: Node3D, node_name: String, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.name = node_name
	n.position = pos
	parent.add_child(n)
	return n


## Uses the knight model if one is in assets/models/knight/, otherwise a low-poly stand-in
## with swinging legs and arm.
func _build_visual() -> void:
	_visual = Node3D.new()
	_visual.name = "Visual"
	add_child(_visual)

	var scene := AssetLoader.find_scene(KNIGHT_DIR)
	var knight: Node3D = AssetLoader.instance_fitted(scene, 1.85) if scene != null else null
	if knight != null:
		knight.name = "KnightModel"
		knight.rotation_degrees.y = 180.0  # glTF models face +Z, echoes face -Z
		_visual.add_child(knight)
	else:
		_leg_l = _pivot(_visual, "LegLPivot", Vector3(-0.17, 0.8, 0.0))
		_box(_leg_l, "Leg", Vector3(0.22, 0.8, 0.25), Vector3(0.0, -0.4, 0.0))
		_leg_r = _pivot(_visual, "LegRPivot", Vector3(0.17, 0.8, 0.0))
		_box(_leg_r, "Leg", Vector3(0.22, 0.8, 0.25), Vector3(0.0, -0.4, 0.0))
		_box(_visual, "Torso", Vector3(0.62, 0.75, 0.36), Vector3(0.0, 1.15, 0.0))
		_arm_l = _pivot(_visual, "ArmLPivot", Vector3(-0.4, 1.5, 0.0))
		_box(_arm_l, "Arm", Vector3(0.18, 0.65, 0.2), Vector3(0.0, -0.3, 0.0))
		_box(_visual, "ArmR", Vector3(0.18, 0.65, 0.2), Vector3(0.4, 1.2, 0.0))
		var head := MeshInstance3D.new()
		head.name = "Head"
		var sphere := SphereMesh.new()
		sphere.radius = 0.21
		sphere.height = 0.42
		sphere.radial_segments = 6
		sphere.rings = 3
		head.mesh = sphere
		head.position = Vector3(0.0, 1.75, 0.0)
		_visual.add_child(head)
		_sword = _pivot(_visual, "SwordPivot", Vector3(0.4, 1.0, -0.1))
		_sword.rotation_degrees = SWORD_REST
		_box(_sword, "Guard", Vector3(0.24, 0.05, 0.07), Vector3(0.0, 0.12, 0.0))
		_box(_sword, "Blade", Vector3(0.07, 0.95, 0.03), Vector3(0.0, 0.62, 0.0))
	AssetLoader.apply_override(_visual, _mat)
	for n in _visual.find_children("*", "MeshInstance3D", true, false):
		(n as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


## Ground ring + drifting motes that trail behind the ghost.
func _build_extras() -> void:
	_ring_mat = StandardMaterial3D.new()
	_ring_mat.albedo_color = Color(ECHO_COLOR.r, ECHO_COLOR.g, ECHO_COLOR.b, base_alpha)
	_ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_ring_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	var torus := TorusMesh.new()
	torus.inner_radius = 0.5
	torus.outer_radius = 0.65
	torus.rings = 20
	torus.ring_segments = 4
	torus.material = _ring_mat
	var ring := MeshInstance3D.new()
	ring.name = "GroundRing"
	ring.mesh = torus
	ring.position = Vector3(0, 0.06, 0)
	ring.scale = Vector3(1.0, 0.1, 1.0)
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ring)

	var mote_mat := StandardMaterial3D.new()
	mote_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mote_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mote_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mote_mat.vertex_color_use_as_albedo = true
	var mote := SphereMesh.new()
	mote.radius = 0.04
	mote.height = 0.08
	mote.radial_segments = 4
	mote.rings = 2
	mote.material = mote_mat
	var grad := Gradient.new()
	grad.set_color(0, Color(0.5, 0.8, 1.0, 0.9))
	grad.set_color(1, Color(0.2, 0.4, 1.0, 0.0))
	_trail = CPUParticles3D.new()
	_trail.name = "Trail"
	_trail.mesh = mote
	_trail.amount = 26
	_trail.lifetime = 0.9
	_trail.local_coords = false  # motes stay behind where they were emitted
	_trail.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	_trail.emission_sphere_radius = 0.3
	_trail.position = Vector3(0, 1.0, 0)
	_trail.direction = Vector3.UP
	_trail.spread = 40.0
	_trail.initial_velocity_min = 0.2
	_trail.initial_velocity_max = 0.6
	_trail.gravity = Vector3(0, 0.4, 0)
	_trail.color_ramp = grad
	_trail.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_trail.emitting = false
	add_child(_trail)
