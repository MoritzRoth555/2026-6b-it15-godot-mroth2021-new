extends Area3D
## Echo Bolt: a fast, PIERCING bolt of echo energy (player: right mouse; echoes replay it as a recorded event).
## Hits every enemy hurtbox it passes through once, stops at walls/floor, expires after `lifetime`.
## Polls overlaps in _physics_process (never inside area signals), like hitbox.gd.

const Fx := preload("res://scripts/fx.gd")

var direction := Vector3.FORWARD
var speed := 30.0
var damage := 35.0
var source: Node
var tint := Color(0.2, 0.9, 1.0)
var lifetime := 1.4

var _age := 0.0
var _hit := {}
var _oriented := false
var _dying := false
var _trail: CPUParticles3D


func _ready() -> void:
	collision_layer = 16            # hitbox
	collision_mask = 64 | 1         # enemy hurtboxes (areas) + world (bodies)
	monitoring = true
	monitorable = false

	var col := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.5
	col.shape = shape
	add_child(col)

	var body := Node3D.new()
	body.name = "Body"
	body.scale = Vector3(1.0, 1.0, 2.4)  # streak along the flight direction (-Z)
	add_child(body)
	var core_mat := StandardMaterial3D.new()
	core_mat.albedo_color = Color(1, 1, 1)
	core_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var aura_mat := StandardMaterial3D.new()
	aura_mat.albedo_color = Color(tint.r, tint.g, tint.b, 0.55)
	aura_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	aura_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	aura_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	body.add_child(_sphere(0.14, core_mat))
	body.add_child(_sphere(0.34, aura_mat))

	var light := OmniLight3D.new()
	light.light_color = tint
	light.light_energy = 1.6
	light.omni_range = 6.0
	add_child(light)

	var mote_mat := StandardMaterial3D.new()
	mote_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mote_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mote_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mote_mat.vertex_color_use_as_albedo = true
	var mote := SphereMesh.new()
	mote.radius = 0.05
	mote.height = 0.1
	mote.radial_segments = 4
	mote.rings = 2
	mote.material = mote_mat
	var grad := Gradient.new()
	grad.set_color(0, Color(tint.r, tint.g, tint.b, 0.9))
	grad.set_color(1, Color(tint.r, tint.g, tint.b, 0.0))
	_trail = CPUParticles3D.new()
	_trail.mesh = mote
	_trail.amount = 24
	_trail.lifetime = 0.4
	_trail.local_coords = false
	_trail.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	_trail.emission_sphere_radius = 0.12
	_trail.gravity = Vector3.ZERO
	_trail.initial_velocity_min = 0.2
	_trail.initial_velocity_max = 0.8
	_trail.spread = 180.0
	_trail.color_ramp = grad
	_trail.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_trail)


func _physics_process(delta: float) -> void:
	if _dying:
		return
	if not _oriented:
		_oriented = true
		if absf(direction.dot(Vector3.UP)) < 0.99:
			look_at(global_position + direction, Vector3.UP)
	global_position += direction * speed * delta
	_age += delta

	for area in get_overlapping_areas():
		if not area.has_method("receive_hit"):
			continue
		var key: int = area.target.get_instance_id() if area.get("target") != null else area.get_instance_id()
		if _hit.has(key):
			continue
		_hit[key] = true
		area.receive_hit(damage, global_position - direction * 0.5, source)
		Fx.burst(self, global_position, tint, 12, 4.5, 0.4)
		get_tree().call_group("audio", "play", "hit", global_position)
	if not get_overlapping_bodies().is_empty() or _age >= lifetime:
		_die()


func _die() -> void:
	if _dying:
		return
	_dying = true
	Fx.burst(self, global_position, tint, 14, 3.5, 0.45)
	queue_free()


func _sphere(radius: float, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 8
	mesh.rings = 4
	mesh.material = mat
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi
