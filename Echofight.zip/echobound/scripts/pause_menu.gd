extends CanvasLayer
## Esc toggles pause: Resume / Main menu / Quit + master volume. Ignored while another
## screen (upgrade menu, game over) already paused the game.

const UiTheme := preload("res://scripts/ui_theme.gd")

var _open := false
var _resume_btn: Button


func _ready() -> void:
	layer = 30
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.0, 0.04, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.custom_minimum_size.x = 380.0
	center.add_child(vb)

	var title := UiTheme.make_label("PAUSE", 56, UiTheme.COL_CYAN)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	_resume_btn = _button(vb, "WEITERSPIELEN")
	_resume_btn.pressed.connect(close)
	var menu_btn := _button(vb, "HAUPTMENÜ")
	menu_btn.pressed.connect(func() -> void: UiTheme.go_to_menu(get_tree()))
	var quit_btn := _button(vb, "BEENDEN")
	quit_btn.pressed.connect(func() -> void: get_tree().quit())

	var vol_label := UiTheme.make_label("Lautstärke", 18, UiTheme.COL_VIOLET)
	vol_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(vol_label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = db_to_linear(AudioServer.get_bus_volume_db(0))
	slider.custom_minimum_size = Vector2(380, 24)
	slider.value_changed.connect(_on_volume)
	vb.add_child(slider)


func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("pause"):
		return
	if _open:
		close()
		get_viewport().set_input_as_handled()
	elif not get_tree().paused:
		open()
		get_viewport().set_input_as_handled()


func open() -> void:
	_open = true
	visible = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_resume_btn.grab_focus.call_deferred()


func close() -> void:
	_open = false
	visible = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _button(parent: Control, text: String) -> Button:
	var b := Button.new()
	b.text = text
	UiTheme.style_button(b, 24)
	parent.add_child(b)
	return b


func _on_volume(v: float) -> void:
	AudioServer.set_bus_mute(0, v <= 0.001)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(v, 0.001)))
