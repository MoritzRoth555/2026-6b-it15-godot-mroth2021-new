extends RefCounted
## Shared dark-fantasy UI helpers (colours, panels, buttons with sounds) and scene switching.

const COL_BG := Color(0.04, 0.02, 0.09, 0.80)
const COL_BORDER := Color(0.35, 0.25, 0.65)
const COL_CYAN := Color(0.3, 0.95, 0.95)
const COL_TEXT := Color(0.78, 0.92, 1.0)
const COL_VIOLET := Color(0.72, 0.55, 1.0)
const COL_BLOOD := Color(0.85, 0.15, 0.25)

const MENU_SCENE := "res://ui/main_menu.tscn"
const GAME_SCENE := "res://scenes/Main.tscn"


static func box(bg: Color, border: Color, border_w := 2, radius := 4, margin := 12) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(margin)
	return sb


static func panel_style() -> StyleBoxFlat:
	return box(COL_BG, COL_BORDER)


static func style_button(b: Button, font_size := 22, accent := COL_CYAN) -> void:
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", COL_TEXT)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_focus_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(0.4, 0.4, 0.5))
	b.add_theme_stylebox_override("normal", box(Color(0.08, 0.05, 0.16, 0.92), COL_BORDER, 2, 4, 14))
	b.add_theme_stylebox_override("hover", box(Color(0.14, 0.09, 0.28, 0.96), accent, 2, 4, 14))
	b.add_theme_stylebox_override("focus", box(Color(0.14, 0.09, 0.28, 0.96), accent, 2, 4, 14))
	b.add_theme_stylebox_override("pressed", box(Color(0.2, 0.12, 0.4), Color.WHITE, 2, 4, 14))
	b.add_theme_stylebox_override("disabled", box(Color(0.06, 0.05, 0.1, 0.8), Color(0.2, 0.2, 0.3), 2, 4, 14))
	b.custom_minimum_size.y = maxf(b.custom_minimum_size.y, 52.0)
	b.mouse_entered.connect(func() -> void: b.get_tree().call_group("audio", "play_ui", "ui_hover"))
	b.pressed.connect(func() -> void: b.get_tree().call_group("audio", "play_ui", "ui_click"))


static func make_label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func go_to_menu(tree: SceneTree) -> void:
	tree.paused = false
	Engine.time_scale = 1.0
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	tree.change_scene_to_file(MENU_SCENE)


static func start_game(tree: SceneTree) -> void:
	tree.paused = false
	Engine.time_scale = 1.0
	tree.change_scene_to_file(GAME_SCENE)
