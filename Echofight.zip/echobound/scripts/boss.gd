extends CharacterBody3D
## THE ECHO KEEPER - 600 HP boss.
## State machine: SPAWN (rises from the sigil, invulnerable) -> CHASE -> MELEE (slow greatsword slam)
## or SPECIAL (ground-slam shockwave ring: jump over it or dash through it) -> DEAD.
## Below 50 % HP it enrages (faster, shorter telegraphs, red glow).
## Its hurtbox is on the same layer as the guards', so echoes can hit it too.

signal died(boss: Node3D)
signal summon_requested(count: int)

const Health := preload("res://scripts/health_component.gd")
const Hitbox := preload("res://scripts/hitbox.gd")
const Hurtbox := preload("res://scripts/hurtbox.gd")
const Fx := preload("res://scripts/fx.gd")
const Pickup := preload("res://scripts/pickup.gd")

enum State { SPAWN, CHASE, MELEE, SPECIAL, DEAD }

const SCALE := 2.0
const SPAWN_DEPTH := 5.0
const CORE_COLOR := Color(0.2, 0.9, 1.0)
const RAGE_COLOR := Color(1.0, 0.2, 0.15)

@export var boss_name := "THE ECHO KEEPER"
@export var max_health := 900.0
@export var move_speed := 2.6
@export var enraged_speed := 3.4
@export var melee_range := 3.8
@export var melee_damage := 36.0
@export var melee_windup := 1.0
@export var melee_active := 0.25
@export var melee_recovery := 1.3
@export var melee_cooldown := 0.8
@export var special_damage := 30.0
@export var special_cooldown := 6.0
@export var special_telegraph := 1.4
@export var wave_speed := 11.0
@export var wave_max_radius := 24.0
@export var spawn_time := 3.0
@export var gravity := 22.0
@export var reward_orbs := 3
@export var reward_heal := 30.0

@onready var visual: Node3D = $Visual

var state: State = State.SPAWN
var health: Health
var hitbox: Hitbox
var hurtbox: Hurtbox
var is_enraged := false
var _final_summon := false

var _target: Node3D
var _t := 0.0
var _state_t := 0.0
var _cd_melee := 0.0
var _cd_special := 0.0
var _strike_started := false
var _wave_fired := false
var _wave_active := false
var _wave_hit := false
var _wave_r := 0.0
var _wave_center := Vector3.ZERO
var _dust_timer := 0.0
var _walk_phase := 0.0
var _recoil := 0.0

var _body_mat: StandardMaterial3D
var _core_mat: StandardMaterial3D
var _wave_mat: StandardMaterial3D
var _tele_mat: StandardMaterial3D
var _upper: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _arm_l: Node3D
var _weapon: Node3D
var _orbit: Node3D
var _wave_ring: MeshInstance3D
var _tele_ring: MeshInstance3D
var _light: OmniLight3D
var _flash_tween: Tween


func _ready() -> void:
	add_to_group("enemies")
	add_to_group("boss")
	collision_layer = 4          # enemy
	collision_mask = 1 | 2 | 4   # world, player, enemy
	visual.scale = Vector3.ONE * SCALE
	_build_visual()
	_build_effects()
	visual.position.y = -SPAWN_DEPTH

	health = Health.new()
	health.name = "Health"
	add_child(health)
	health.setup(max_health)
	health.invulnerable = true  # until fully risen
	health.died.connect(_on_died)
	health.damaged.connect(_on_damaged)

	hurtbox = Hurtbox.new()
	hurtbox.name = "Hurtbox"
	hurtbox.collision_layer = 64  # hurtbox_enemy (players AND echoes hit this)
	hurtbox.collision_mask = 0
	hurtbox.monitoring = false
	hurtbox.target = self
	_add_box_shape(hurtbox, Vector3(2.2, 4.2, 2.2), Vector3(0, 2.1, 0))
	add_child(hurtbox)

	hitbox = Hitbox.new()
	hitbox.name = "Hitbox"
	hitbox.collision_layer = 16   # hitbox
	hitbox.collision_mask = 32    # hurtbox_player
	hitbox.damage = melee_damage
	hitbox.source = self
	hitbox.position = Vector3(0, 2.0, -2.6)
	_add_box_shape(hitbox, Vector3(3.4, 3.0, 3.2), Vector3.ZERO)
	add_child(hitbox)

	_set_state(State.SPAWN)
	_cd_special = 3.0
	get_tree().call_group("audio", "play", "boss_roar", global_position)


func _physics_process(delta: float) -> void:
	_t += delta
	_state_t += delta
	_cd_melee = maxf(_cd_melee - delta, 0.0)
	_cd_special = maxf(_cd_special - delta, 0.0)
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1
	_target = _find_player()

	match state:
		State.SPAWN:
			_update_spawn(delta)
		State.CHASE:
			_update_chase(delta)
		State.MELEE:
			_update_melee(delta)
		State.SPECIAL:
			_update_special(delta)
		State.DEAD:
			_friction(delta)
	_update_wave(delta)
	_animate(delta)
	move_and_slide()


# ------------------------------------------------------------------ states --

func _set_state(new_state: State) -> void:
	state = new_state
	_state_t = 0.0


func _update_spawn(delta: float) -> void:
	_friction(delta)
	var k := clampf(_state_t / spawn_time, 0.0, 1.0)
	visual.position.y = lerpf(-SPAWN_DEPTH, 0.0, k * k * (3.0 - 2.0 * k))
	_dust_timer -= delta
	if _dust_timer <= 0.0:
		_dust_timer = 0.25
		Fx.burst(self, global_position + Vector3(randf_range(-2.5, 2.5), 0.2, randf_range(-2.5, 2.5)),
			Color(0.5, 0.45, 0.65), 10, 3.0, 0.7)
	if k >= 1.0:
		health.invulnerable = false
		Fx.burst(self, global_position + Vector3(0, 0.3, 0), CORE_COLOR, 50, 8.0, 0.9)
		_add_player_trauma(0.7)
		_set_state(State.CHASE)


func _update_chase(delta: float) -> void:
	if _target == null:
		_friction(delta)
		return
	var to := _flat_to_target()
	var dist := to.length()
	var dir := to.normalized()
	_face(dir, delta, 2.2)
	var spd := enraged_speed if is_enraged else move_speed
	if dist > melee_range * 0.85:
		velocity.x = dir.x * spd
		velocity.z = dir.z * spd
	else:
		_friction(delta)
	if _cd_melee <= 0.0 and dist <= melee_range:
		_strike_started = false
		_set_state(State.MELEE)
	elif _cd_special <= 0.0 and (dist > 6.0 or _state_t > 1.5):
		_wave_fired = false
		_tele_ring.visible = true
		get_tree().call_group("audio", "play", "boss_charge", global_position)
		_set_state(State.SPECIAL)


func _melee_times() -> Vector3:
	var f := 0.75 if is_enraged else 1.0
	var windup := melee_windup * f
	return Vector3(windup, windup + melee_active, windup + melee_active + melee_recovery * (0.8 if is_enraged else 1.0))


func _update_melee(delta: float) -> void:
	_friction(delta)
	var tm := _melee_times()
	if _state_t < tm.x:
		if _target != null:
			_face(_flat_to_target().normalized(), delta, 1.5)
		_weapon.rotation_degrees.x = lerpf(-10.0, 160.0, _state_t / tm.x)       # raise (telegraph)
	elif _state_t < tm.y:
		_weapon.rotation_degrees.x = lerpf(160.0, 70.0, (_state_t - tm.x) / melee_active)  # slam down
		if not _strike_started:
			_strike_started = true
			hitbox.damage = melee_damage
			hitbox.begin_swing()
			_slam_fx()
	else:
		if hitbox.active:
			hitbox.end_swing()
		_weapon.rotation_degrees.x = lerpf(70.0, -10.0, clampf((_state_t - tm.y) / (tm.z - tm.y), 0.0, 1.0))
		if _state_t >= tm.z:
			_cd_melee = melee_cooldown
			_set_state(State.CHASE)


func _special_telegraph() -> float:
	return special_telegraph * (0.75 if is_enraged else 1.0)


func _update_special(delta: float) -> void:
	_friction(delta)
	var tele := _special_telegraph()
	if _state_t < tele:
		var k := _state_t / tele
		_weapon.rotation_degrees.x = lerpf(-10.0, 170.0, k)
		var pulse := 3.2 + k * 1.8 + sin(_t * 16.0) * 0.25
		_tele_ring.scale = Vector3(pulse, 4.0, pulse)
		_tele_mat.albedo_color.a = 0.5 + 0.4 * sin(_t * 16.0)
	else:
		if not _wave_fired:
			_wave_fired = true
			_tele_ring.visible = false
			_weapon.rotation_degrees.x = 60.0
			_start_wave()
		if _state_t >= tele + 0.6:
			_weapon.rotation_degrees.x = lerpf(60.0, -10.0, clampf((_state_t - tele - 0.6) / 0.4, 0.0, 1.0))
		if _state_t >= tele + 1.0:
			_cd_special = special_cooldown * (0.65 if is_enraged else 1.0)
			_cd_melee = maxf(_cd_melee, 1.0)
			_set_state(State.CHASE)


func _start_wave() -> void:
	get_tree().call_group("audio", "play", "boss_wave", global_position)
	_wave_active = true
	_wave_hit = false
	_wave_r = 1.0
	_wave_center = global_position
	_wave_ring.global_position = Vector3(_wave_center.x, 0.12, _wave_center.z)
	_wave_ring.visible = true
	Fx.burst(self, _wave_center + Vector3(0, 0.3, 0), CORE_COLOR if not is_enraged else RAGE_COLOR, 40, 7.0, 0.7)
	_add_player_trauma(0.9)


## Expanding ring. Dodge it by jumping or dashing (dash = i-frames). Echoes are unaffected.
func _update_wave(delta: float) -> void:
	if not _wave_active:
		return
	_wave_r += wave_speed * (1.15 if is_enraged else 1.0) * delta
	if _wave_r >= wave_max_radius:
		_wave_active = false
		_wave_ring.visible = false
		return
	_wave_ring.scale = Vector3(_wave_r, 8.0, _wave_r)
	_wave_mat.albedo_color.a = clampf(1.0 - _wave_r / wave_max_radius * 0.8, 0.0, 1.0)
	if _wave_hit or _target == null:
		return
	var p := _target.global_position
	var d := Vector2(p.x - _wave_center.x, p.z - _wave_center.z).length()
	var half := 0.6 + _wave_r * 0.04
	if absf(d - _wave_r) <= half and p.y - _wave_center.y < 0.5:
		_wave_hit = true
		_target.apply_hit(special_damage, Vector3(_wave_center.x, p.y, _wave_center.z), self)


func _slam_fx() -> void:
	get_tree().call_group("audio", "play", "boss_slam", global_position)
	var p := global_position + (-global_transform.basis.z) * 2.6 + Vector3(0, 0.2, 0)
	Fx.burst(self, p, Color(0.6, 0.55, 0.75), 24, 6.0, 0.6)
	if _target != null and _flat_to_target().length() < 9.0:
		_add_player_trauma(0.45)


func _enrage() -> void:
	is_enraged = true
	get_tree().call_group("audio", "play", "boss_roar", global_position)
	_core_mat.albedo_color = RAGE_COLOR
	_core_mat.emission = RAGE_COLOR
	_light.light_color = RAGE_COLOR
	Fx.burst(self, global_position + Vector3(0, 3.0, 0), RAGE_COLOR, 40, 8.0, 0.9)
	_add_player_trauma(0.6)


# ------------------------------------------------------------------ damage --

## Called by Hurtbox (player sword or echo sword). No stagger: it only flinches.
func apply_hit(damage: float, _from_pos: Vector3, source: Node) -> void:
	if state == State.DEAD or state == State.SPAWN:
		return
	var dealt := health.take_damage(damage, source)
	if dealt <= 0.0:
		return
	Fx.burst(self, global_position + Vector3(0, 2.4, 0), Color(0.7, 0.9, 1.0), 14, 5.0, 0.45)
	if state == State.DEAD:
		return
	_recoil = 0.6
	_flash()


func _on_damaged(_amount: float, _source: Node) -> void:
	if health.is_dead:
		return
	if not is_enraged and health.current <= max_health * 0.5:
		_enrage()
		summon_requested.emit(3)   # reinforcements at 50 %
	elif is_enraged and not _final_summon and health.current <= max_health * 0.25:
		_final_summon = true
		summon_requested.emit(4)   # and again at 25 %
		Fx.burst(self, global_position + Vector3(0, 3.0, 0), RAGE_COLOR, 30, 7.0, 0.8)


func _flash() -> void:
	_body_mat.emission_enabled = true
	_body_mat.emission = Color(1, 1, 1)
	_body_mat.emission_energy_multiplier = 1.6
	if _flash_tween:
		_flash_tween.kill()
	_flash_tween = create_tween()
	_flash_tween.tween_property(_body_mat, "emission_energy_multiplier", 0.0, 0.2)


func _on_died() -> void:
	state = State.DEAD
	get_tree().call_group("audio", "play", "boss_death", global_position)
	hitbox.end_swing()
	_wave_active = false
	_wave_ring.visible = false
	_tele_ring.visible = false
	collision_layer = 0
	hurtbox.set_deferred("monitorable", false)
	Fx.burst(self, global_position + Vector3(0, 2.5, 0), CORE_COLOR, 40, 7.0, 0.9)
	var tw := create_tween()
	tw.tween_property(_upper, "rotation:x", -0.7, 1.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(visual, "position:y", -0.8, 1.6)
	tw.tween_callback(_death_burst)
	tw.tween_interval(1.2)
	tw.tween_property(visual, "scale", Vector3.ZERO, 0.6)
	tw.tween_callback(queue_free)
	_spawn_rewards.call_deferred()
	died.emit(self)


func _death_burst() -> void:
	Fx.burst(self, global_position + Vector3(0, 2.5, 0), CORE_COLOR, 70, 10.0, 1.1)
	Fx.burst(self, global_position + Vector3(0, 1.5, 0), Color(0.5, 0.9, 1.0), 30, 1.5, 2.0, 1.6)  # rising souls
	_add_player_trauma(0.8)
	_light.light_energy = 0.0


## Reward: heal orbs around the corpse (the upgrade pick is handled by the run manager).
func _spawn_rewards() -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return
	for i in reward_orbs:
		var a := TAU * float(i) / float(reward_orbs)
		var pu := Pickup.new()
		pu.name = "BossHealOrb_%d" % i
		pu.heal_amount = reward_heal
		scene.add_child(pu)
		pu.global_position = global_position + Vector3(cos(a) * 3.0, 0.6, sin(a) * 3.0)


# ----------------------------------------------------------------- helpers --

func _find_player() -> Node3D:
	var best: Node3D = null
	var best_d := INF
	for p in get_tree().get_nodes_in_group("player"):
		if p.get("is_dead") == true:
			continue
		var d := global_position.distance_squared_to(p.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best


func _flat_to_target() -> Vector3:
	var to := _target.global_position - global_position
	to.y = 0.0
	return to


func _face(dir: Vector3, delta: float, speed: float) -> void:
	if dir.length_squared() < 0.0001:
		return
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 1.0 - exp(-speed * delta))


func _friction(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 25.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 25.0 * delta)


func _add_player_trauma(amount: float) -> void:
	if _target != null and _target.has_method("add_trauma"):
		_target.add_trauma(amount)


func _add_box_shape(area: Area3D, size: Vector3, pos: Vector3) -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	col.position = pos
	area.add_child(col)


# --------------------------------------------------------------- animation --

func _animate(delta: float) -> void:
	if state == State.DEAD:
		return
	var speed := Vector2(velocity.x, velocity.z).length()
	var top := enraged_speed if is_enraged else move_speed
	var walk := clampf(speed / maxf(top, 0.1), 0.0, 1.0)
	_walk_phase += delta * (2.2 + speed * 1.4)
	var swing := sin(_walk_phase) * 0.55 * walk
	var k := 1.0 - exp(-14.0 * delta)
	_leg_l.rotation.x = lerpf(_leg_l.rotation.x, swing, k)
	_leg_r.rotation.x = lerpf(_leg_r.rotation.x, -swing, k)

	var lean := 0.0  # negative = forward
	var arm_target := -swing * 0.7
	match state:
		State.CHASE:
			lean = -0.08 * walk
		State.MELEE:
			var tm := _melee_times()
			if _state_t < tm.x:
				lean = lerpf(0.0, 0.3, _state_t / tm.x)
			elif _state_t < tm.y:
				lean = -0.45
			else:
				lean = lerpf(-0.45, 0.0, clampf((_state_t - tm.y) / (tm.z - tm.y), 0.0, 1.0))
		State.SPECIAL:
			var tele := _special_telegraph()
			if _state_t < tele:
				var kk := _state_t / tele
				lean = lerpf(0.0, 0.35, kk)
				arm_target = lerpf(0.0, 2.9, kk)  # both arms rise
			else:
				lean = -0.5
				arm_target = 0.6
	_recoil = move_toward(_recoil, 0.0, delta * 4.0)
	lean += 0.4 * _recoil
	_upper.rotation.x = lerpf(_upper.rotation.x, lean, 1.0 - exp(-12.0 * delta))
	_arm_l.rotation.x = lerpf(_arm_l.rotation.x, arm_target, 1.0 - exp(-12.0 * delta))
	_upper.scale = Vector3(1.0, 1.0 + sin(_t * 1.6) * 0.012, 1.0)
	if state != State.SPAWN:
		visual.position.y = absf(sin(_walk_phase)) * 0.08 * walk

	# Orbiting echo shards, pulsing core and light
	_orbit.rotation.y += delta * (2.2 if is_enraged else 1.2)
	_orbit.position.y = 1.5 + sin(_t * 1.5) * 0.12
	_core_mat.emission_energy_multiplier = (4.5 if is_enraged else 3.5) + sin(_t * 3.0) * 1.0
	_light.light_energy = (3.2 if is_enraged else 2.4) + sin(_t * 3.0) * 0.4


# ------------------------------------------------------------------ visuals --

func _mat(color: Color, roughness := 0.7, metallic := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m


func _pivot(parent: Node3D, node_name: String, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.name = node_name
	n.position = pos
	parent.add_child(n)
	return n


func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


func _cone(parent: Node3D, node_name: String, radius: float, height: float, pos: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.0
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 5
	mesh.rings = 1
	mesh.material = material
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


## Hulking armoured figure: dark violet plate, glowing echo core, crown of horns,
## orbiting echo shards and a huge greatsword. Built from pivots so it can animate.
func _build_visual() -> void:
	_body_mat = _mat(Color(0.10, 0.07, 0.16), 0.5, 0.5)
	var trim := _mat(Color(0.28, 0.12, 0.45), 0.7)
	var steel := _mat(Color(0.34, 0.34, 0.44), 0.35, 0.8)
	_core_mat = _mat(CORE_COLOR, 0.3)
	_core_mat.emission_enabled = true
	_core_mat.emission = CORE_COLOR
	_core_mat.emission_energy_multiplier = 3.5

	_leg_l = _pivot(visual, "LegLPivot", Vector3(-0.26, 0.85, 0))
	_box(_leg_l, "Leg", Vector3(0.36, 0.85, 0.38), Vector3(0, -0.425, 0), _body_mat)
	_box(_leg_l, "Boot", Vector3(0.42, 0.18, 0.52), Vector3(0, -0.77, -0.06), steel)
	_leg_r = _pivot(visual, "LegRPivot", Vector3(0.26, 0.85, 0))
	_box(_leg_r, "Leg", Vector3(0.36, 0.85, 0.38), Vector3(0, -0.425, 0), _body_mat)
	_box(_leg_r, "Boot", Vector3(0.42, 0.18, 0.52), Vector3(0, -0.77, -0.06), steel)

	_upper = _pivot(visual, "Upper", Vector3(0, 0.85, 0))
	_box(_upper, "Torso", Vector3(1.0, 1.0, 0.6), Vector3(0, 0.5, 0), _body_mat)
	_box(_upper, "Core", Vector3(0.24, 0.24, 0.08), Vector3(0, 0.62, -0.32), _core_mat)
	var crack1 := _box(_upper, "CrackA", Vector3(0.05, 0.7, 0.02), Vector3(-0.28, 0.45, -0.31), _core_mat)
	crack1.rotation_degrees.z = 14.0
	var crack2 := _box(_upper, "CrackB", Vector3(0.05, 0.6, 0.02), Vector3(0.3, 0.4, -0.31), _core_mat)
	crack2.rotation_degrees.z = -18.0
	_box(_upper, "Belt", Vector3(1.05, 0.14, 0.64), Vector3(0, 0.02, 0), trim)
	_box(_upper, "PauldronL", Vector3(0.55, 0.3, 0.65), Vector3(-0.78, 1.02, 0), steel)
	_box(_upper, "PauldronR", Vector3(0.55, 0.3, 0.65), Vector3(0.78, 1.02, 0), steel)
	_cone(_upper, "SpikeL", 0.12, 0.45, Vector3(-0.82, 1.35, 0), trim)
	_cone(_upper, "SpikeR", 0.12, 0.45, Vector3(0.82, 1.35, 0), trim)
	_box(_upper, "Helmet", Vector3(0.56, 0.6, 0.56), Vector3(0, 1.35, 0), steel)
	var horn_l := _cone(_upper, "HornL", 0.1, 0.6, Vector3(-0.24, 1.85, 0), trim)
	horn_l.rotation_degrees.z = 25.0
	var horn_r := _cone(_upper, "HornR", 0.1, 0.6, Vector3(0.24, 1.85, 0), trim)
	horn_r.rotation_degrees.z = -25.0
	_box(_upper, "EyeL", Vector3(0.14, 0.06, 0.04), Vector3(-0.12, 1.38, -0.29), _core_mat)
	_box(_upper, "EyeR", Vector3(0.14, 0.06, 0.04), Vector3(0.12, 1.38, -0.29), _core_mat)

	_arm_l = _pivot(_upper, "ArmLPivot", Vector3(-0.78, 0.9, 0))
	_box(_arm_l, "Arm", Vector3(0.3, 0.9, 0.32), Vector3(0, -0.4, 0), _body_mat)
	_box(_arm_l, "Fist", Vector3(0.36, 0.26, 0.38), Vector3(0, -0.92, 0), steel)

	_weapon = _pivot(_upper, "WeaponPivot", Vector3(0.78, 0.9, 0))
	_weapon.rotation_degrees.x = -10.0
	_box(_weapon, "ArmR", Vector3(0.3, 0.9, 0.32), Vector3(0, -0.4, 0), _body_mat)
	_box(_weapon, "Handle", Vector3(0.1, 0.4, 0.1), Vector3(0, -0.95, 0), trim)
	_box(_weapon, "Guard", Vector3(0.55, 0.1, 0.16), Vector3(0, -1.2, 0), steel)
	_box(_weapon, "Blade", Vector3(0.28, 2.2, 0.08), Vector3(0, -2.35, 0), steel)
	_box(_weapon, "BladeGlow", Vector3(0.04, 2.1, 0.1), Vector3(0, -2.35, 0), _core_mat)

	# Echo shards orbiting the chest (animated in _animate)
	_orbit = _pivot(visual, "EchoShards", Vector3(0, 1.5, 0))
	for i in 6:
		var a := TAU * float(i) / 6.0
		var shard := _cone(_orbit, "Shard_%d" % i, 0.12, 0.55,
			Vector3(cos(a) * 1.45, sin(float(i) * 1.7) * 0.35, sin(a) * 1.45), _core_mat)
		shard.rotation_degrees = Vector3(180.0, 0.0, float(i) * 20.0)

	for n in visual.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		if mi.name.begins_with("Shard") or mi.name.begins_with("Crack") or mi.name.begins_with("BladeGlow"):
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


## Floor telegraph ring, shockwave ring and the boss light.
func _build_effects() -> void:
	_tele_mat = StandardMaterial3D.new()
	_tele_mat.albedo_color = Color(1.0, 0.25, 0.2, 0.8)
	_tele_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_tele_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_tele_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	var tele_mesh := TorusMesh.new()
	tele_mesh.inner_radius = 0.93
	tele_mesh.outer_radius = 1.07
	tele_mesh.rings = 40
	tele_mesh.ring_segments = 4
	tele_mesh.material = _tele_mat
	_tele_ring = MeshInstance3D.new()
	_tele_ring.name = "TelegraphRing"
	_tele_ring.mesh = tele_mesh
	_tele_ring.position = Vector3(0, 0.1, 0)
	_tele_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_tele_ring.visible = false
	add_child(_tele_ring)

	_wave_mat = StandardMaterial3D.new()
	_wave_mat.albedo_color = Color(0.3, 0.9, 1.0, 1.0)
	_wave_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_wave_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_wave_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	var wave_mesh := TorusMesh.new()
	wave_mesh.inner_radius = 0.96
	wave_mesh.outer_radius = 1.04
	wave_mesh.rings = 64
	wave_mesh.ring_segments = 6
	wave_mesh.material = _wave_mat
	_wave_ring = MeshInstance3D.new()
	_wave_ring.name = "ShockwaveRing"
	_wave_ring.mesh = wave_mesh
	_wave_ring.top_level = true  # stays where the slam happened while the boss moves
	_wave_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_wave_ring.visible = false
	add_child(_wave_ring)

	_light = OmniLight3D.new()
	_light.name = "BossLight"
	_light.position = Vector3(0, 3.0, 0)
	_light.light_color = CORE_COLOR
	_light.light_energy = 2.4
	_light.omni_range = 14.0
	add_child(_light)
