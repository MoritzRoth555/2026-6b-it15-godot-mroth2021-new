extends Node3D
## Game scene: wires HUD, audio, echo/run/upgrade managers and the menus together.
## Run flow lives in run_manager.gd.

const Hud := preload("res://scripts/hud.gd")
const AudioManager := preload("res://scripts/audio_manager.gd")
const EchoManager := preload("res://scripts/echo_manager.gd")
const RunManager := preload("res://scripts/run_manager.gd")
const UpgradeManager := preload("res://scripts/upgrade_manager.gd")
const UpgradeMenu := preload("res://scripts/upgrade_menu.gd")
const PauseMenu := preload("res://scripts/pause_menu.gd")
const GameOver := preload("res://scripts/game_over.gd")

@onready var dungeon: Node3D = $Dungeon
@onready var player: CharacterBody3D = $Player

var audio: Node
var hud: CanvasLayer
var echo_manager: Node
var upgrade_manager: Node
var upgrade_menu: CanvasLayer
var pause_menu: CanvasLayer
var game_over: CanvasLayer
var run_manager: Node


func _ready() -> void:
	audio = AudioManager.new()
	audio.name = "AudioManager"
	add_child(audio)
	hud = Hud.new()
	hud.name = "Hud"
	add_child(hud)
	# Added after the player so they process after it in every physics tick.
	echo_manager = EchoManager.new()
	echo_manager.name = "EchoManager"
	add_child(echo_manager)
	upgrade_manager = UpgradeManager.new()
	upgrade_manager.name = "UpgradeManager"
	add_child(upgrade_manager)
	upgrade_menu = UpgradeMenu.new()
	upgrade_menu.name = "UpgradeMenu"
	add_child(upgrade_menu)
	game_over = GameOver.new()
	game_over.name = "GameOver"
	add_child(game_over)
	pause_menu = PauseMenu.new()
	pause_menu.name = "PauseMenu"
	add_child(pause_menu)
	run_manager = RunManager.new()
	run_manager.name = "RunManager"
	add_child(run_manager)

	echo_manager.echoes_changed.connect(hud.set_echoes)
	player.health_changed.connect(hud.set_health)
	player.damaged.connect(func(_amount: float) -> void: hud.flash_damage())

	run_manager.setup(player, dungeon, echo_manager, hud, upgrade_manager, upgrade_menu, game_over)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	audio.start_ambience()
	run_manager.start_run()


func _process(_delta: float) -> void:
	hud.set_dash(player.dash_cooldown_left, player.dash_cooldown)
	hud.set_bolt(player.bolt_cooldown_left, player.bolt_cooldown)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("debug_die") and not player.is_dead:
		player.health.take_damage(99999.0)  # debug: die instantly to test echoes
	elif event.is_action_pressed("debug_reset"):
		run_manager.reset_progress()  # debug: delete save, echoes and stats
