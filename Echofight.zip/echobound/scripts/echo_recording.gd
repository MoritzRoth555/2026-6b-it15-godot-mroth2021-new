extends RefCounted
## One recorded run: timestamped samples (position, rotation, state flags) plus discrete events.
## Attacks / dashes / jumps are stored as individual events (never as a held boolean).

const FLAG_MOVING := 1
const FLAG_SPRINT := 2
const FLAG_DASH := 4
const FLAG_AIRBORNE := 8
const FLAG_ATTACK := 16

var run_index := 0
var duration := 0.0
var times := PackedFloat32Array()
var positions := PackedVector3Array()
var yaws := PackedFloat32Array()
var pitches := PackedFloat32Array()
var flags := PackedInt32Array()
## Each event: {"t": float, "type": StringName, ...extra data}. Sorted by time.
var events: Array = []


func add_sample(t: float, pos: Vector3, yaw: float, pitch: float, state_flags: int) -> void:
	times.append(t)
	positions.append(pos)
	yaws.append(yaw)
	pitches.append(pitch)
	flags.append(state_flags)
	duration = maxf(duration, t)


func add_event(t: float, type: StringName, data := {}) -> void:
	var ev := {"t": t, "type": type}
	ev.merge(data)
	events.append(ev)


func get_sample_count() -> int:
	return times.size()


func to_dict() -> Dictionary:
	var t: Array = []
	var pos: Array = []
	var yaw: Array = []
	var pitch: Array = []
	var fl: Array = []
	for i in times.size():
		t.append(snappedf(times[i], 0.001))
		pos.append(snappedf(positions[i].x, 0.001))
		pos.append(snappedf(positions[i].y, 0.001))
		pos.append(snappedf(positions[i].z, 0.001))
		yaw.append(snappedf(yaws[i], 0.001))
		pitch.append(snappedf(pitches[i], 0.001))
		fl.append(flags[i])
	var evs: Array = []
	for ev in events:
		var e := {}
		for k in ev:
			e[k] = String(ev[k]) if k == "type" else ev[k]
		evs.append(e)
	return {"run": run_index, "duration": snappedf(duration, 0.001),
		"t": t, "pos": pos, "yaw": yaw, "pitch": pitch, "flags": fl, "events": evs}


## Fills this recording from to_dict() data. Returns false if the data is malformed.
func load_dict(d: Dictionary) -> bool:
	var t: Array = d.get("t", [])
	var pos: Array = d.get("pos", [])
	var yaw: Array = d.get("yaw", [])
	var pitch: Array = d.get("pitch", [])
	var fl: Array = d.get("flags", [])
	var n := t.size()
	if n == 0 or pos.size() != n * 3 or yaw.size() != n or pitch.size() != n or fl.size() != n:
		return false
	run_index = int(d.get("run", 0))
	times = PackedFloat32Array()
	positions = PackedVector3Array()
	yaws = PackedFloat32Array()
	pitches = PackedFloat32Array()
	flags = PackedInt32Array()
	for i in n:
		times.append(float(t[i]))
		positions.append(Vector3(float(pos[i * 3]), float(pos[i * 3 + 1]), float(pos[i * 3 + 2])))
		yaws.append(float(yaw[i]))
		pitches.append(float(pitch[i]))
		flags.append(int(fl[i]))
	events = []
	for e in d.get("events", []):
		if typeof(e) != TYPE_DICTIONARY:
			continue
		var ev := {"t": float(e.get("t", 0.0)), "type": StringName(str(e.get("type", "")))}
		if e.has("damage"):
			ev["damage"] = float(e["damage"])
		events.append(ev)
	events.sort_custom(func(a, b): return a["t"] < b["t"])
	duration = float(d.get("duration", times[n - 1]))
	return true


## Index of the last sample with times[i] <= t, searching forward from `from`.
func find_index(t: float, from := 0) -> int:
	if times.is_empty():
		return 0
	var i := clampi(from, 0, times.size() - 1)
	while i < times.size() - 1 and times[i + 1] <= t:
		i += 1
	return i
