extends CanvasLayer
## Pick-one-of-three upgrade screen. Pauses nothing itself; the run manager pauses the tree.
## Works with mouse (buttons) or keys 1-3. Styled placeholder until the Phase 6 UI pass.

signal upgrade_chosen(id: String)

var _offers: Array = []
var _cards: HBoxContainer


func _ready() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS  # must keep working while the tree is paused
	visible = false

	var root := Control.new()
	root.name = "Root"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.0, 0.06, 0.84)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 24)
	center.add_child(box)

	var title := Label.new()
	title.text = "WÄHLE EIN UPGRADE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color(0.55, 0.95, 1.0))
	box.add_child(title)

	_cards = HBoxContainer.new()
	_cards.add_theme_constant_override("separation", 22)
	_cards.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(_cards)

	var hint := Label.new()
	hint.text = "Klicken oder Taste 1 / 2 / 3"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_color_override("font_color", Color(0.6, 0.55, 0.8))
	box.add_child(hint)


func show_offers(offers: Array) -> void:
	_offers = offers
	for c in _cards.get_children():
		_cards.remove_child(c)
		c.queue_free()
	for i in offers.size():
		var o: Dictionary = offers[i]
		var b := Button.new()
		b.custom_minimum_size = Vector2(250, 220)
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.text = "[%d]\n\n%s\n\n%s\n\nStufe %d → %d" % [i + 1, o["name"], o["desc"], o["level"], o["level"] + 1]
		b.add_theme_font_size_override("font_size", 19)
		b.add_theme_color_override("font_color", Color(0.78, 0.95, 1.0))
		b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
		b.add_theme_stylebox_override("normal", _style(Color(0.08, 0.05, 0.16), Color(0.3, 0.2, 0.55)))
		b.add_theme_stylebox_override("hover", _style(Color(0.14, 0.09, 0.28), Color(0.2, 0.95, 0.9)))
		b.add_theme_stylebox_override("pressed", _style(Color(0.2, 0.12, 0.4), Color(0.4, 1.0, 1.0)))
		b.add_theme_stylebox_override("focus", _style(Color(0.14, 0.09, 0.28), Color(0.2, 0.95, 0.9)))
		b.pressed.connect(_choose.bind(i))
		_cards.add_child(b)
	visible = true
	if _cards.get_child_count() > 0:
		(_cards.get_child(0) as Button).grab_focus.call_deferred()


func _unhandled_input(event: InputEvent) -> void:
	if not visible or not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var idx := -1
	match event.physical_keycode:
		KEY_1: idx = 0
		KEY_2: idx = 1
		KEY_3: idx = 2
	if idx >= 0 and idx < _offers.size():
		get_viewport().set_input_as_handled()
		_choose(idx)


func _choose(index: int) -> void:
	if not visible or index >= _offers.size():
		return
	get_tree().call_group("audio", "play_ui", "ui_click")
	visible = false
	upgrade_chosen.emit(str(_offers[index]["id"]))


func _style(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(6)
	sb.set_content_margin_all(14)
	return sb
