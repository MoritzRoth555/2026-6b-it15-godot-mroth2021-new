extends RefCounted
## Procedurally synthesized placeholder sounds, so the game has audio without any asset files.
## Real files in assets/audio/<name>.ogg|wav|mp3 always take priority (see audio_manager.gd).

const RATE := 22050


static func make(sound: String) -> AudioStreamWAV:
	match sound:
		"sword_swing":
			return _wav(_swoosh(0.28, 1800.0, 0.5))
		"echo_swing":
			return _wav(_swoosh(0.28, 3200.0, 0.25))
		"enemy_swing":
			return _wav(_swoosh(0.35, 900.0, 0.55))
		"enemy_windup":
			return _wav(_sweep(0.45, 90.0, 170.0, 0.35, 1.5, true, 0.1))
		"bolt":
			return _wav(_sweep(0.4, 300.0, 1100.0, 0.4, 3.0, false, 0.25))
		"hit":
			return _wav(_impact(0.28, 150.0, 0.8))
		"player_hurt":
			return _wav(_sweep(0.3, 260.0, 120.0, 0.45, 5.0, true, 0.35))
		"player_death":
			return _wav(_sweep(1.2, 180.0, 35.0, 0.5, 2.5, true, 0.2, 0.5))
		"enemy_death":
			return _wav(_sweep(0.7, 220.0, 50.0, 0.5, 3.0, true, 0.3))
		"dash":
			return _wav(_whoosh(0.3, 0.45))
		"jump":
			return _wav(_sweep(0.14, 260.0, 520.0, 0.3, 4.0))
		"pickup":
			return _wav(_arp([660.0, 880.0, 1100.0], 0.08, 0.35))
		"upgrade":
			return _wav(_arp([440.0, 554.0, 660.0, 880.0], 0.12, 0.35))
		"echo_spawn":
			return _wav(_shimmer(0.6, 0.35))
		"arena_clear":
			return _wav(_arp([330.0, 440.0, 550.0], 0.15, 0.35))
		"portal_open":
			return _wav(_chord_rise(1.0, [220.0, 330.0, 440.0, 660.0], 0.3))
		"boss_roar":
			return _wav(_roar(1.4, 70.0, 50.0, 0.6, 1.2))
		"boss_charge":
			return _wav(_sweep(1.4, 60.0, 180.0, 0.45, 0.3, true, 0.15, 0.3))
		"boss_slam":
			return _wav(_impact(0.6, 70.0, 0.9))
		"boss_wave":
			return _wav(_sweep(0.9, 90.0, 420.0, 0.45, 2.5, false, 0.3))
		"boss_death":
			return _wav(_roar(2.0, 60.0, 30.0, 0.6, 1.5))
		"ui_hover":
			return _wav(_sweep(0.05, 720.0, 720.0, 0.15, 3.0))
		"ui_click":
			return _wav(_sweep(0.09, 520.0, 300.0, 0.3, 4.0))
		"run_win":
			return _wav(_arp([440.0, 554.0, 660.0, 880.0, 1100.0], 0.14, 0.35))
		"run_lose":
			return _wav(_sweep(1.0, 220.0, 110.0, 0.35, 2.0, true, 0.1))
		"ambience":
			return _drone_loop()
	return null


# ------------------------------------------------------------- generators --

static func _noise() -> RandomNumberGenerator:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	return rng


static func _swoosh(dur: float, cutoff: float, vol: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := _noise()
	var lp := 0.0
	for i in n:
		var t := float(i) / float(n)
		var alpha := clampf(TAU * cutoff * (0.3 + 0.9 * t) / float(RATE), 0.0, 1.0)
		lp += alpha * (rng.randf_range(-1.0, 1.0) - lp)
		out[i] = lp * sin(PI * t) * vol * 2.0
	return out


static func _whoosh(dur: float, vol: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := _noise()
	var lp := 0.0
	for i in n:
		var t := float(i) / float(n)
		var x := rng.randf_range(-1.0, 1.0)
		lp += 0.15 * (x - lp)
		var env := sin(PI * t)
		out[i] = (x - lp) * env * env * vol
	return out


static func _impact(dur: float, f0: float, vol: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := _noise()
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		var f := f0 * exp(-t * dur * 8.0) + 35.0
		phase += f / float(RATE)
		var thump := sin(TAU * phase) * exp(-t * dur * 14.0)
		var crack := rng.randf_range(-1.0, 1.0) * exp(-t * dur * 45.0) * 0.6
		out[i] = (thump + crack) * vol
	return out


## Generic pitch sweep: sine or saw, optional noise mix and tremolo.
static func _sweep(dur: float, f0: float, f1: float, vol: float, decay: float, saw := false, noise_mix := 0.0, trem := 0.0) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		phase += lerpf(f0, f1, t) / float(RATE)
		var wave := (phase - floorf(phase)) * 2.0 - 1.0 if saw else sin(TAU * phase)
		var env := minf(1.0, t * 40.0) * exp(-t * decay)
		var s := wave * (1.0 - noise_mix) + rng.randf_range(-1.0, 1.0) * noise_mix
		if trem > 0.0:
			s *= 1.0 - trem * (0.5 + 0.5 * sin(TAU * 14.0 * t * dur))
		out[i] = s * env * vol
	return out


static func _arp(notes: Array, note_dur: float, vol: float) -> PackedFloat32Array:
	var per := int(note_dur * RATE)
	var note_len := int((note_dur + 0.2) * RATE)
	var out := PackedFloat32Array()
	out.resize(per * (notes.size() - 1) + note_len)
	for k in notes.size():
		var f: float = notes[k]
		for i in note_len:
			out[k * per + i] += sin(TAU * f * float(i) / float(RATE)) * exp(-float(i) / float(note_len) * 6.0) * vol
	return out


static func _chord_rise(dur: float, freqs: Array, vol: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var phases: Array = []
	for f in freqs:
		phases.append(0.0)
	for i in n:
		var t := float(i) / float(n)
		var s := 0.0
		for k in freqs.size():
			phases[k] += float(freqs[k]) * (1.0 + 0.25 * t) / float(RATE)
			s += sin(TAU * phases[k])
		out[i] = s / float(freqs.size()) * sin(PI * t) * vol
	return out


static func _shimmer(dur: float, vol: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		phase += lerpf(500.0, 900.0, t) / float(RATE)
		out[i] = sin(TAU * phase + 3.0 * sin(TAU * 9.0 * t * dur)) * sin(PI * t) * vol
	return out


static func _roar(dur: float, f0: float, f1: float, vol: float, decay: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 23
	var phase := 0.0
	var lp := 0.0
	for i in n:
		var t := float(i) / float(n)
		phase += lerpf(f0, f1, t) / float(RATE)
		var saw := (phase - floorf(phase)) * 2.0 - 1.0
		lp += 0.08 * (rng.randf_range(-1.0, 1.0) - lp)
		var s := tanh(saw * 3.0) * 0.7 + lp * 2.0
		out[i] = s * minf(1.0, t * 8.0) * exp(-t * decay) * vol
	return out


## 6 s seamless loop (all partials have whole cycles per loop) at a low sample rate.
static func _drone_loop() -> AudioStreamWAV:
	var rate := 11025
	var n := rate * 6
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var t := float(i) / float(rate)
		var lfo := 0.6 + 0.4 * sin(TAU * t / 3.0)
		var s := 0.5 * sin(TAU * 55.0 * t) + 0.3 * sin(TAU * 82.5 * t) + 0.2 * sin(TAU * 110.0 * t)
		s += 0.12 * sin(TAU * 165.0 * t) * (0.5 + 0.5 * sin(TAU * t / 6.0))
		out[i] = s * lfo * 0.5
	return _wav(out, rate, true)


static func _wav(buf: PackedFloat32Array, rate := RATE, loop := false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(buf.size() * 2)
	for i in buf.size():
		bytes.encode_s16(i * 2, int(clampf(buf[i], -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = buf.size()
	return w
