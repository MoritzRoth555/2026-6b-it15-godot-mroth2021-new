extends Node
## Upgrade pool, random offers, stacking levels and applying them to the player.
## Levels are persistent (saved) and re-applied at the start of every run.
## Echoes record the damage value of each attack, so they carry the upgrades you had when recorded.

signal upgrades_changed

const POOL := [
	{"id": "damage", "name": "Klingenschärfe", "desc": "+20 % Schwertschaden"},
	{"id": "health", "name": "Eiserner Wille", "desc": "+25 maximale Lebenspunkte"},
	{"id": "speed", "name": "Windschritt", "desc": "+10 % Bewegungsgeschwindigkeit"},
	{"id": "attack_speed", "name": "Flinke Klinge", "desc": "-12 % Angriffs-Abklingzeit"},
	{"id": "dash", "name": "Schattenschritt", "desc": "-15 % Dash-Abklingzeit"},
	{"id": "resonance", "name": "Echo-Resonanz", "desc": "+25 % Bolzenschaden, -12 % Bolzen-Cooldown"},
]

const DAMAGE_PER_LEVEL := 0.2
const HEALTH_PER_LEVEL := 25.0
const SPEED_PER_LEVEL := 0.1
const ATTACK_COOLDOWN_FACTOR := 0.88
const DASH_COOLDOWN_FACTOR := 0.85
const BOLT_POWER_PER_LEVEL := 0.25
const BOLT_COOLDOWN_FACTOR := 0.88

var levels := {}  # String id -> int level
var _base := {}


## Remember the player's un-upgraded stats. Call once before anything is applied.
func capture_base(player) -> void:
	_base = {
		"attack_cooldown": player.attack_cooldown,
		"dash_cooldown": player.dash_cooldown,
		"bolt_cooldown": player.bolt_cooldown,
		"max_health": player.max_health,
	}


func level_of(id: String) -> int:
	return int(levels.get(id, 0))


## `count` distinct random upgrades from the pool.
func roll_offers(count := 3) -> Array:
	var pool := POOL.duplicate()
	pool.shuffle()
	var out: Array = []
	for i in mini(count, pool.size()):
		var offer: Dictionary = pool[i].duplicate()
		offer["level"] = level_of(offer["id"])
		out.append(offer)
	return out


func pick(id: String, player) -> void:
	levels[id] = level_of(id) + 1
	apply_to_player(player, true)
	upgrades_changed.emit()


## Recomputes all upgraded stats from base values + levels (idempotent).
## heal_new_max: raise current HP by the same amount when max HP grows (mid-run pick).
func apply_to_player(player, heal_new_max := false) -> void:
	player.damage_multiplier = 1.0 + DAMAGE_PER_LEVEL * level_of("damage")
	player.speed_multiplier = 1.0 + SPEED_PER_LEVEL * level_of("speed")
	player.attack_cooldown = maxf(0.2, float(_base["attack_cooldown"]) * pow(ATTACK_COOLDOWN_FACTOR, level_of("attack_speed")))
	player.dash_cooldown = maxf(0.4, float(_base["dash_cooldown"]) * pow(DASH_COOLDOWN_FACTOR, level_of("dash")))
	player.bolt_power = 1.0 + BOLT_POWER_PER_LEVEL * level_of("resonance")
	player.bolt_cooldown = maxf(0.8, float(_base["bolt_cooldown"]) * pow(BOLT_COOLDOWN_FACTOR, level_of("resonance")))
	var target_hp: float = float(_base["max_health"]) + HEALTH_PER_LEVEL * level_of("health")
	var delta: float = target_hp - player.max_health
	player.max_health = target_hp
	if heal_new_max and delta > 0.0:
		player.health.increase_max(delta)


func summary() -> String:
	var parts: Array[String] = []
	for u in POOL:
		var l := level_of(u["id"])
		if l > 0:
			parts.append("%s %d" % [u["name"], l])
	return "Upgrades: " + (", ".join(parts) if not parts.is_empty() else "keine")


func export_levels() -> Dictionary:
	return levels.duplicate()


func load_levels(d: Dictionary) -> void:
	levels.clear()
	for u in POOL:
		var id: String = u["id"]
		if d.has(id):
			levels[id] = maxi(0, int(d[id]))


func clear() -> void:
	levels.clear()
	upgrades_changed.emit()
