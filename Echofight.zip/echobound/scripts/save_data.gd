extends RefCounted
## Persistent save file (user://echobound_save.json): lifetime stats + stored echo recordings.
## A missing or corrupt file simply yields fresh default data.

const PATH := "user://echobound_save.json"
const VERSION := 1


static func default_stats() -> Dictionary:
	return {
		"total_runs": 0,
		"total_kills": 0,
		"wins": 0,
		"bosses_defeated": 0,
		"best_score": 0,
		"best_kills": 0,
		"best_win_time": 0.0,
	}


static func default_data() -> Dictionary:
	return {"version": VERSION, "stats": default_stats(), "recordings": [], "upgrades": {}}


static func load_data() -> Dictionary:
	var data := default_data()
	if not FileAccess.file_exists(PATH):
		return data
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return data
	var parsed = JSON.parse_string(f.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		push_warning("EchoBound: save file corrupt, starting fresh.")
		return data
	var stats = parsed.get("stats", {})
	if typeof(stats) == TYPE_DICTIONARY:
		for k in data["stats"]:
			if stats.has(k):
				data["stats"][k] = stats[k]
	var ups = parsed.get("upgrades", {})
	if typeof(ups) == TYPE_DICTIONARY:
		data["upgrades"] = ups
	var recs = parsed.get("recordings", [])
	if typeof(recs) == TYPE_ARRAY:
		data["recordings"] = recs
	return data


static func save_data(data: Dictionary) -> bool:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f == null:
		push_warning("EchoBound: could not write save file.")
		return false
	f.store_string(JSON.stringify(data))
	return true


static func delete_save() -> void:
	if FileAccess.file_exists(PATH):
		DirAccess.remove_absolute(PATH)
