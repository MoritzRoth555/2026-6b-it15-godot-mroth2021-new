extends Node
## Reusable health. Used by player, enemies, echoes (invulnerable) and the boss.

signal health_changed(current: float, maximum: float)
signal damaged(amount: float, source: Node)
signal died

@export var max_health := 100.0
var current := 100.0
var invulnerable := false
var is_dead := false


func setup(max_hp: float) -> void:
	max_health = max_hp
	reset()


func reset() -> void:
	current = max_health
	is_dead = false
	health_changed.emit(current, max_health)


## Returns the damage actually dealt (0 if dead / invulnerable).
func take_damage(amount: float, source: Node = null) -> float:
	if is_dead or invulnerable or amount <= 0.0:
		return 0.0
	var dealt := minf(amount, current)
	current -= dealt
	damaged.emit(dealt, source)
	health_changed.emit(current, max_health)
	if current <= 0.0:
		is_dead = true
		died.emit()
	return dealt


func heal(amount: float) -> void:
	if is_dead:
		return
	current = minf(current + amount, max_health)
	health_changed.emit(current, max_health)


## Raises max health (upgrades) and heals by the same amount.
func increase_max(amount: float) -> void:
	max_health += amount
	current += amount
	health_changed.emit(current, max_health)
