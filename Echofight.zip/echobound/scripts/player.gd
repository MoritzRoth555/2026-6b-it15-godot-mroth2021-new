extends CharacterBody3D
## First-person player: WASD, mouse look, sprint, jump, dash (cooldown, i-frames),
## sword attack with hitbox, health, hit reaction, death + revive.

signal jumped
signal dashed
signal attack_started
signal bolt_fired
signal damaged(amount: float)
signal health_changed(current: float, maximum: float)
signal died

const InputSetup := preload("res://scripts/input_setup.gd")
const Health := preload("res://scripts/health_component.gd")
const Hitbox := preload("res://scripts/hitbox.gd")
const Hurtbox := preload("res://scripts/hurtbox.gd")
const Fx := preload("res://scripts/fx.gd")
const Projectile := preload("res://scripts/projectile.gd")

const EYE_HEIGHT := 1.65
const SWORD_REST_ROT := Vector3(-28.0, 8.0, -6.0)
const ARC_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;
uniform vec4 tint : source_color = vec4(0.4, 0.9, 1.0, 1.0);
uniform float progress : hint_range(0.0, 1.0) = 0.0;
uniform float fade : hint_range(0.0, 1.0) = 1.0;
void fragment() {
	vec2 p = UV - vec2(0.5);
	float r = length(p);
	float a01 = (atan(p.y, p.x) + PI) / TAU;
	float ring = smoothstep(0.30, 0.42, r) * (1.0 - smoothstep(0.42, 0.5, r));
	float tail = clamp(progress - 0.35, 0.0, 1.0);
	float sweep = step(tail, a01) * step(a01, progress) * clamp((a01 - tail) / max(progress - tail, 0.001), 0.0, 1.0);
	ALBEDO = tint.rgb * 2.0;
	ALPHA = ring * sweep * fade;
}
"""

@export_group("Movement")
@export var walk_speed := 6.0
@export var sprint_speed := 9.5
@export var acceleration := 45.0
@export var air_control := 0.45
@export var jump_velocity := 7.5
@export var gravity := 22.0
## Multiplier for upgrades (Phase 5).
@export var speed_multiplier := 1.0

@export_group("Dash")
@export var dash_speed := 22.0
@export var dash_duration := 0.18
@export var dash_cooldown := 1.2

@export_group("Combat")
@export var max_health := 100.0
@export var attack_damage := 25.0
@export var attack_cooldown := 0.55
## Multiplier for upgrades (Phase 5).
@export var damage_multiplier := 1.0

@export_group("Echo Bolt (right mouse)")
@export var bolt_damage := 35.0
@export var bolt_cooldown := 3.0
@export var bolt_speed := 30.0
## Multiplier for upgrades.
@export var bolt_power := 1.0

@export_group("Camera")
@export var mouse_sensitivity := 0.0025
@export var base_fov := 75.0
@export var dash_fov := 88.0

@onready var visual: Node3D = $Visual  # body model slot (hidden in first person, used for echoes later)
@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D

var is_dashing := false
var is_sprinting := false
var is_attacking := false
var is_dead := false
var dash_cooldown_left := 0.0
var viewmodel: Node3D
var sword_pivot: Node3D
var health: Health
var sword_hitbox: Hitbox
var hurtbox: Hurtbox

var _dash_time_left := 0.0
var _dash_dir := Vector3.ZERO
var _bob_time := 0.0
var _vm_rest_pos := Vector3(0.34, -0.34, -0.55)
var _attack_cd_left := 0.0
var _iframes := 0.0
var _trauma := 0.0
var _swing_tween: Tween
var _vm_tween: Tween
var _arc: MeshInstance3D
var _arc_mat: ShaderMaterial
var _orb_mat: StandardMaterial3D
var _idle_time := 0.0
var _land_dip := 0.0
var _was_on_floor := true
var _fall_speed := 0.0
var _hitstop_active := false
var bolt_cooldown_left := 0.0
var _left_hand: Node3D
var _orb_flash := 0.0


func _ready() -> void:
	InputSetup.ensure_actions()
	add_to_group("player")
	collision_layer = 2      # player
	collision_mask = 1 | 4   # world, enemy
	visual.visible = false
	head.position = Vector3(0, EYE_HEIGHT, 0)
	camera.fov = base_fov
	camera.near = 0.05
	camera.current = true
	_build_viewmodel()
	_build_combat()


## Moves the player instantly (spawn / respawn).
func teleport(pos: Vector3, yaw := 0.0) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	rotation.y = yaw
	head.rotation.x = 0.0


## Full reset for a new life (called by the run flow).
func revive() -> void:
	is_dead = false
	is_dashing = false
	is_attacking = false
	_iframes = 0.0
	_attack_cd_left = 0.0
	dash_cooldown_left = 0.0
	bolt_cooldown_left = 0.0
	if _swing_tween:
		_swing_tween.kill()
	if _vm_tween:
		_vm_tween.kill()
	sword_hitbox.end_swing()
	sword_pivot.rotation_degrees = SWORD_REST_ROT
	viewmodel.position = _vm_rest_pos
	_arc.visible = false
	camera.rotation.z = 0.0
	viewmodel.visible = true
	health.setup(max_health)


func heal(amount: float) -> void:
	health.heal(amount)


## Camera shake hook (boss slams etc.). 0..1
func add_trauma(amount: float) -> void:
	_trauma = minf(_trauma + amount, 1.0)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not is_dead:
		rotate_y(-event.relative.x * mouse_sensitivity)
		head.rotation.x = clampf(head.rotation.x - event.relative.y * mouse_sensitivity,
			deg_to_rad(-85.0), deg_to_rad(85.0))
	elif event is InputEventMouseButton and event.pressed \
			and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _physics_process(delta: float) -> void:
	dash_cooldown_left = maxf(dash_cooldown_left - delta, 0.0)
	_attack_cd_left = maxf(_attack_cd_left - delta, 0.0)
	bolt_cooldown_left = maxf(bolt_cooldown_left - delta, 0.0)
	_iframes = maxf(_iframes - delta, 0.0)

	if is_dead:
		if not is_on_floor():
			velocity.y -= gravity * delta
		velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
		move_and_slide()
		_update_view(delta)
		return

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var wish := global_transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)
	wish.y = 0.0
	var has_input := input_dir.length_squared() > 0.001

	if Input.is_action_just_pressed("dash") and dash_cooldown_left <= 0.0 and not is_dashing:
		_start_dash(wish if has_input else -global_transform.basis.z)

	if Input.is_action_just_pressed("attack") and _attack_cd_left <= 0.0 \
			and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_start_attack()

	if Input.is_action_just_pressed("attack_alt") and bolt_cooldown_left <= 0.0 \
			and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_fire_bolt()

	if is_dashing:
		_dash_time_left -= delta
		velocity.x = _dash_dir.x * dash_speed
		velocity.z = _dash_dir.z * dash_speed
		velocity.y = 0.0
		if _dash_time_left <= 0.0:
			is_dashing = false
	else:
		if not is_on_floor():
			velocity.y -= gravity * delta
		elif Input.is_action_just_pressed("jump"):
			velocity.y = jump_velocity
			jumped.emit()
			get_tree().call_group("audio", "play", "jump")

		is_sprinting = Input.is_action_pressed("sprint") and has_input
		var speed := (sprint_speed if is_sprinting else walk_speed) * speed_multiplier
		var target := wish.normalized() * speed if has_input else Vector3.ZERO
		var rate := acceleration * (1.0 if is_on_floor() else air_control)
		var flat := Vector2(velocity.x, velocity.z).move_toward(Vector2(target.x, target.z), rate * delta)
		velocity.x = flat.x
		velocity.z = flat.y

	_fall_speed = velocity.y
	move_and_slide()
	if is_on_floor() and not _was_on_floor and _fall_speed < -5.0:
		_land_dip = clampf(-_fall_speed / 25.0, 0.05, 0.3)
	_was_on_floor = is_on_floor()
	_update_view(delta)


func _start_dash(dir: Vector3) -> void:
	dir.y = 0.0
	_dash_dir = dir.normalized()
	is_dashing = true
	_dash_time_left = dash_duration
	dash_cooldown_left = dash_cooldown
	dashed.emit()
	get_tree().call_group("audio", "play", "dash")


# ------------------------------------------------------------------ combat --

func _build_combat() -> void:
	health = Health.new()
	health.name = "Health"
	add_child(health)
	health.setup(max_health)
	health.health_changed.connect(health_changed.emit)
	health.died.connect(_on_died)

	hurtbox = Hurtbox.new()
	hurtbox.name = "Hurtbox"
	hurtbox.collision_layer = 32  # hurtbox_player
	hurtbox.collision_mask = 0
	hurtbox.monitoring = false
	hurtbox.target = self
	_add_box_shape(hurtbox, Vector3(0.8, 1.8, 0.8), Vector3(0, 0.9, 0))
	add_child(hurtbox)

	sword_hitbox = Hitbox.new()
	sword_hitbox.name = "SwordHitbox"
	sword_hitbox.collision_layer = 16  # hitbox
	sword_hitbox.collision_mask = 64   # hurtbox_enemy
	sword_hitbox.source = self
	sword_hitbox.position = Vector3(0, -0.1, -1.3)
	_add_box_shape(sword_hitbox, Vector3(1.5, 1.2, 1.7), Vector3.ZERO)
	head.add_child(sword_hitbox)
	sword_hitbox.hit_landed.connect(_on_sword_hit)


func _add_box_shape(area: Area3D, size: Vector3, pos: Vector3) -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	col.position = pos
	area.add_child(col)


func _start_attack() -> void:
	_attack_cd_left = attack_cooldown
	is_attacking = true
	attack_started.emit()
	get_tree().call_group("audio", "play", "sword_swing")
	sword_hitbox.damage = attack_damage * damage_multiplier
	if _swing_tween:
		_swing_tween.kill()
	if _vm_tween:
		_vm_tween.kill()
	_swing_tween = create_tween()
	_swing_tween.tween_property(sword_pivot, "rotation_degrees", Vector3(-15, 60, -40), 0.09) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)                      # wind-up
	_swing_tween.tween_callback(sword_hitbox.begin_swing)
	_swing_tween.tween_callback(_play_slash_arc)
	_swing_tween.tween_property(sword_pivot, "rotation_degrees", Vector3(-40, -60, 30), 0.11) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)                       # slash
	_swing_tween.tween_callback(sword_hitbox.end_swing)
	_swing_tween.tween_property(sword_pivot, "rotation_degrees", SWORD_REST_ROT, 0.25) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)                      # recover
	_swing_tween.tween_callback(func() -> void: is_attacking = false)
	# Whole arm/sword lunges with the swing.
	_vm_tween = create_tween()
	_vm_tween.tween_property(viewmodel, "position", _vm_rest_pos + Vector3(0.10, 0.05, 0.08), 0.09) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_vm_tween.tween_property(viewmodel, "position", _vm_rest_pos + Vector3(-0.12, -0.05, -0.24), 0.11) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	_vm_tween.tween_property(viewmodel, "position", _vm_rest_pos, 0.25) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func get_bolt_damage() -> float:
	return bolt_damage * damage_multiplier * bolt_power


## Right mouse: a piercing echo bolt shot from the left hand towards the crosshair.
func _fire_bolt() -> void:
	bolt_cooldown_left = bolt_cooldown
	bolt_fired.emit()
	get_tree().call_group("audio", "play", "bolt")
	var forward := -camera.global_transform.basis.z
	var origin := camera.global_transform * Vector3(-0.3, -0.25, -0.9)
	var aim_point := camera.global_position + forward * 40.0
	var bolt := Projectile.new()
	bolt.damage = get_bolt_damage()
	bolt.direction = (aim_point - origin).normalized()
	bolt.speed = bolt_speed
	bolt.source = self
	get_tree().current_scene.add_child(bolt)
	bolt.global_position = origin
	_trauma = minf(_trauma + 0.15, 1.0)
	_orb_flash = 1.0
	var tw := create_tween()
	tw.tween_property(_left_hand, "position", Vector3(-0.72, 0.03, -0.16), 0.07) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_left_hand, "position", Vector3(-0.72, -0.02, 0.05), 0.3) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


## Glowing crescent that sweeps across the screen during the slash.
func _play_slash_arc() -> void:
	_arc_mat.set_shader_parameter("progress", 0.0)
	_arc_mat.set_shader_parameter("fade", 1.0)
	_arc.visible = true
	var tw := create_tween()
	tw.tween_method(func(v: float) -> void: _arc_mat.set_shader_parameter("progress", v), 0.0, 1.0, 0.11)
	tw.tween_method(func(v: float) -> void: _arc_mat.set_shader_parameter("fade", v), 1.0, 0.0, 0.08)
	tw.tween_callback(func() -> void: _arc.visible = false)


## Tiny freeze-frame on hit for impact (uses real time, so it always ends).
func _hit_stop(duration := 0.05) -> void:
	if _hitstop_active:
		return
	_hitstop_active = true
	Engine.time_scale = 0.08
	await get_tree().create_timer(duration, true, false, true).timeout
	Engine.time_scale = 1.0
	_hitstop_active = false


func _on_sword_hit(hit_area: Area3D) -> void:
	Fx.burst(self, hit_area.global_position + Vector3(0, 0.4, 0), Color(0.5, 0.9, 1.0), 10, 4.0, 0.35)
	_trauma = minf(_trauma + 0.25, 1.0)
	_hit_stop()


## Called by Hurtbox. Dash grants invulnerability frames.
func apply_hit(damage: float, from_pos: Vector3, source: Node) -> void:
	if is_dead or is_dashing or _iframes > 0.0:
		return
	var dealt := health.take_damage(damage, source)
	if dealt <= 0.0:
		return
	_iframes = 0.35
	_trauma = minf(_trauma + 0.6, 1.0)
	var away := global_position - from_pos
	away.y = 0.0
	if away.length_squared() > 0.001:
		velocity += away.normalized() * 7.0
	damaged.emit(dealt)
	get_tree().call_group("audio", "play", "player_hurt")


func _on_died() -> void:
	is_dead = true
	get_tree().call_group("audio", "play", "player_death")
	is_dashing = false
	is_attacking = false
	if _swing_tween:
		_swing_tween.kill()
	if _vm_tween:
		_vm_tween.kill()
	sword_hitbox.end_swing()
	_arc.visible = false
	viewmodel.visible = false
	var tw := create_tween().set_parallel(true)
	tw.tween_property(camera, "rotation:z", 0.7, 0.8).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(head, "position:y", 0.4, 0.8).set_trans(Tween.TRANS_QUAD)
	died.emit()


# -------------------------------------------------------------------- view --

func _update_view(delta: float) -> void:
	var flat_speed := Vector2(velocity.x, velocity.z).length()
	var moving := not is_dead and is_on_floor() and flat_speed > 0.5
	_idle_time += delta
	if moving:
		_bob_time += delta * flat_speed * 1.5
	_land_dip = move_toward(_land_dip, 0.0, delta * 1.4)

	if not is_dead:
		var bob := (sin(_bob_time * 2.0) * 0.035) if moving else 0.0
		head.position.y = lerpf(head.position.y, EYE_HEIGHT + bob - _land_dip, 1.0 - exp(-20.0 * delta))
		# Strafe roll
		var local_v := global_transform.basis.inverse() * velocity
		var roll := clampf(-local_v.x / sprint_speed, -1.0, 1.0) * 0.025
		camera.rotation.z = lerpf(camera.rotation.z, roll, 1.0 - exp(-10.0 * delta))

	var target_fov := dash_fov if is_dashing else (base_fov + 4.0 if is_sprinting else base_fov)
	camera.fov = lerpf(camera.fov, target_fov, 1.0 - exp(-14.0 * delta))

	# Camera shake from hits
	_trauma = maxf(_trauma - delta * 1.8, 0.0)
	var shake := _trauma * _trauma
	camera.h_offset = randf_range(-1.0, 1.0) * shake * 0.12
	camera.v_offset = randf_range(-1.0, 1.0) * shake * 0.12

	# Viewmodel: walk bob, idle breathing, sprint carry, dash pull-back, landing dip
	if viewmodel and not is_attacking:
		var sway := Vector3.ZERO
		if moving:
			var amp := 1.4 if is_sprinting else 1.0
			sway = Vector3(sin(_bob_time) * 0.014 * amp, absf(cos(_bob_time)) * -0.016 * amp, 0.0)
		else:
			sway = Vector3(sin(_idle_time * 1.1) * 0.004, sin(_idle_time * 1.6) * 0.005, 0.0)
		var rest := _vm_rest_pos + sway + Vector3(0.0, -_land_dip * 0.6, 0.0)
		if is_sprinting:
			rest += Vector3(0.04, -0.05, 0.02)
		if is_dashing:
			rest += Vector3(0.0, -0.04, 0.12)
		viewmodel.position = viewmodel.position.lerp(rest, 1.0 - exp(-12.0 * delta))
		var tilt := Vector3(8.0, 0.0, -6.0) if is_sprinting else Vector3.ZERO
		viewmodel.rotation_degrees = viewmodel.rotation_degrees.lerp(tilt, 1.0 - exp(-10.0 * delta))
	if _orb_mat:
		_orb_flash = move_toward(_orb_flash, 0.0, delta * 3.0)
		_orb_mat.emission_energy_multiplier = 2.5 + sin(_idle_time * 3.0) + _orb_flash * 6.0


# --------------------------------------------------------------- viewmodel --

func _mat(color: Color, roughness := 0.8, metallic := 0.0, glow := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	if glow > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = glow
	return m


func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


## Armoured gauntlet + sword (right) and an echo orb (left) held in front of the camera.
func _build_viewmodel() -> void:
	var armor := _mat(Color(0.28, 0.28, 0.34), 0.4, 0.7)
	var cloth := _mat(Color(0.14, 0.10, 0.24), 0.9)
	var gold := _mat(Color(0.55, 0.42, 0.2), 0.35, 0.9)
	var glow := _mat(Color(0.1, 0.9, 0.85), 0.3, 0.0, 2.5)
	var steel := _mat(Color(0.78, 0.84, 0.94), 0.2, 0.9, 0.2)
	var dark := _mat(Color(0.08, 0.08, 0.12), 0.5, 0.6)
	_orb_mat = _mat(Color(0.25, 0.55, 1.0), 0.2, 0.0, 2.5)

	viewmodel = Node3D.new()
	viewmodel.name = "Viewmodel"
	viewmodel.position = _vm_rest_pos
	camera.add_child(viewmodel)

	# Right arm
	var arm := _box(viewmodel, "Forearm", Vector3(0.11, 0.11, 0.42), Vector3(0.0, -0.1, 0.22), armor)
	arm.rotation_degrees.x = 12.0
	_box(viewmodel, "Cuff", Vector3(0.15, 0.15, 0.07), Vector3(0.0, -0.06, 0.1), gold)
	_box(viewmodel, "Gauntlet", Vector3(0.13, 0.13, 0.16), Vector3(0.0, -0.04, 0.02), armor)
	_box(viewmodel, "Knuckles", Vector3(0.14, 0.05, 0.05), Vector3(0.0, 0.03, -0.07), dark)
	_box(viewmodel, "Sleeve", Vector3(0.14, 0.14, 0.2), Vector3(0.0, -0.15, 0.45), cloth)

	# Sword
	sword_pivot = Node3D.new()
	sword_pivot.name = "SwordPivot"
	sword_pivot.rotation_degrees = SWORD_REST_ROT
	viewmodel.add_child(sword_pivot)
	_box(sword_pivot, "Hilt", Vector3(0.04, 0.2, 0.04), Vector3.ZERO, cloth)
	_box(sword_pivot, "Guard", Vector3(0.26, 0.035, 0.06), Vector3(0.0, 0.11, 0.0), gold)
	_box(sword_pivot, "QuillonL", Vector3(0.04, 0.08, 0.06), Vector3(-0.13, 0.12, 0.0), gold)
	_box(sword_pivot, "QuillonR", Vector3(0.04, 0.08, 0.06), Vector3(0.13, 0.12, 0.0), gold)
	_box(sword_pivot, "Pommel", Vector3(0.06, 0.06, 0.06), Vector3(0.0, -0.12, 0.0), glow)
	_box(sword_pivot, "Blade", Vector3(0.06, 0.85, 0.02), Vector3(0.0, 0.55, 0.0), steel)
	_box(sword_pivot, "Fuller", Vector3(0.014, 0.65, 0.024), Vector3(0.0, 0.5, 0.0), dark)
	_box(sword_pivot, "BladeGlow", Vector3(0.01, 0.62, 0.026), Vector3(0.0, 0.5, 0.0), glow)
	var tip := _box(sword_pivot, "Tip", Vector3(0.06, 0.06, 0.02), Vector3(0.0, 0.98, 0.0), steel)
	tip.rotation_degrees.z = 45.0

	# Left hand holding a pulsing echo orb
	var left := Node3D.new()
	left.name = "LeftHand"
	left.position = Vector3(-0.72, -0.02, 0.05)
	_left_hand = left
	viewmodel.add_child(left)
	var larm := _box(left, "Forearm", Vector3(0.11, 0.11, 0.4), Vector3(0.0, -0.1, 0.22), armor)
	larm.rotation_degrees.x = 12.0
	_box(left, "Cuff", Vector3(0.15, 0.15, 0.07), Vector3(0.0, -0.06, 0.1), gold)
	_box(left, "Gauntlet", Vector3(0.13, 0.13, 0.16), Vector3(0.0, -0.04, 0.02), armor)
	var orb := MeshInstance3D.new()
	orb.name = "EchoOrb"
	var sphere := SphereMesh.new()
	sphere.radius = 0.06
	sphere.height = 0.12
	sphere.radial_segments = 8
	sphere.rings = 4
	sphere.material = _orb_mat
	orb.mesh = sphere
	orb.position = Vector3(0.0, 0.1, -0.06)
	left.add_child(orb)

	# Slash arc effect (hidden until a swing)
	_arc = MeshInstance3D.new()
	_arc.name = "SlashArc"
	var quad := QuadMesh.new()
	quad.size = Vector2(2.4, 2.4)
	_arc_mat = ShaderMaterial.new()
	var shader := Shader.new()
	shader.code = ARC_SHADER
	_arc_mat.shader = shader
	quad.material = _arc_mat
	_arc.mesh = quad
	_arc.position = Vector3(0.0, -0.1, -1.1)
	_arc.rotation_degrees.z = -20.0
	_arc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_arc.visible = false
	camera.add_child(_arc)
