extends RefCounted
## Registers all input actions in code, so the project does not depend on a
## hand-edited InputMap. Actions already defined in Project Settings are kept.

static func ensure_actions() -> void:
	_key("move_forward", KEY_W)
	_key("move_back", KEY_S)
	_key("move_left", KEY_A)
	_key("move_right", KEY_D)
	_key("jump", KEY_SPACE)
	_key("sprint", KEY_SHIFT)
	_key("dash", KEY_Q)
	_key("interact", KEY_F)
	_key("pause", KEY_ESCAPE)
	_key("debug_die", KEY_K)
	_key("debug_reset", KEY_F9)
	_mouse("attack", MOUSE_BUTTON_LEFT)
	_mouse("attack_alt", MOUSE_BUTTON_RIGHT)


static func _key(action: String, keycode: Key) -> void:
	if InputMap.has_action(action):
		return
	InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)


static func _mouse(action: String, button: MouseButton) -> void:
	if InputMap.has_action(action):
		return
	InputMap.add_action(action)
	var ev := InputEventMouseButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)
