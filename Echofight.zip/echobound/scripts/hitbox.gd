extends Area3D
## Damage dealer. Active only between begin_swing() and end_swing().
## Each target can be hit at most ONCE per swing (no multi-hit from one attack).

signal hit_landed(hurtbox: Area3D)

var damage := 10.0
var source: Node
var active := false
var _already_hit := {}


func _ready() -> void:
	monitoring = false
	monitorable = false


func begin_swing() -> void:
	_already_hit.clear()
	active = true
	monitoring = true


func end_swing() -> void:
	active = false
	monitoring = false


func _physics_process(_delta: float) -> void:
	if not active:
		return
	for area in get_overlapping_areas():
		if not area.has_method("receive_hit"):
			continue
		var key: int = area.target.get_instance_id() if area.get("target") != null else area.get_instance_id()
		if _already_hit.has(key):
			continue
		_already_hit[key] = true
		area.receive_hit(damage, global_position, source)
		get_tree().call_group("audio", "play", "hit", global_position)
		hit_landed.emit(area)
