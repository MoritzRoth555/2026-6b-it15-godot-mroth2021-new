extends CanvasLayer
## Dark-fantasy HUD: status panel, score panel, health + dash bars, boss bar, messages, vignette.
## Public API (used by main.gd / run_manager.gd): set_health, set_dash, set_enemies, set_run,
## set_echoes, set_stats, set_upgrades, show_boss_bar / hide_boss_bar / set_boss_health,
## flash_damage, show_message / hide_message.  F3 toggles the FPS counter.

const UiTheme := preload("res://scripts/ui_theme.gd")
const BAR_W := 380.0
const BOSS_W := 640.0
const VIGNETTE_SHADER := """
shader_type canvas_item;
uniform float intensity = 0.55;
uniform float hurt = 0.0;
uniform float low = 0.0;
void fragment() {
	vec2 uv = UV - vec2(0.5);
	float d = length(uv * vec2(1.0, 0.85));
	float v = smoothstep(0.25, 0.75, d);
	float h = clamp(hurt + low * (0.35 + 0.35 * sin(TIME * 4.0)), 0.0, 1.0);
	vec3 col = mix(vec3(0.0, 0.0, 0.03), vec3(0.8, 0.0, 0.05), h);
	COLOR = vec4(col, clamp(v * intensity + v * h * 0.9 + h * 0.10, 0.0, 1.0));
}
"""

var _vignette_mat: ShaderMaterial
var _hp := {}
var _dash := {}
var _bolt := {}
var _boss := {}
var _boss_root: Control
var _boss_name: Label
var _run_label: Label
var _echo_label: Label
var _enemy_label: Label
var _score_label: Label
var _kills_label: Label
var _best_label: Label
var _fps_label: Label
var _upgrades_label: Label
var _msg: Label
var _hint: Label
var _msg_tween: Tween


func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.name = "Root"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	var vignette := ColorRect.new()
	vignette.name = "Vignette"
	vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vignette.color = Color.WHITE
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vignette_mat = ShaderMaterial.new()
	var vshader := Shader.new()
	vshader.code = VIGNETTE_SHADER
	_vignette_mat.shader = vshader
	vignette.material = _vignette_mat
	root.add_child(vignette)

	_build_status_panel(root)
	_build_score_panel(root)
	_build_bottom_left(root)
	_build_upgrades(root)
	_build_boss_bar(root)
	_build_message(root)
	_build_crosshair(root)
	_build_hint(root)


func _process(delta: float) -> void:
	_update_ghost(_hp, delta)
	_update_ghost(_boss, delta)
	_fps_label.text = "FPS %d" % Engine.get_frames_per_second()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F3:
		_fps_label.visible = not _fps_label.visible


# ------------------------------------------------------------------ builders --

func _anchor(c: Control, preset: Control.LayoutPreset, margin := 20) -> void:
	c.set_anchors_and_offsets_preset(preset, Control.PRESET_MODE_MINSIZE, margin)
	match preset:
		Control.PRESET_BOTTOM_LEFT:
			c.grow_vertical = Control.GROW_DIRECTION_BEGIN
		Control.PRESET_TOP_RIGHT:
			c.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		Control.PRESET_BOTTOM_RIGHT:
			c.grow_horizontal = Control.GROW_DIRECTION_BEGIN
			c.grow_vertical = Control.GROW_DIRECTION_BEGIN
		Control.PRESET_CENTER_BOTTOM:
			c.grow_horizontal = Control.GROW_DIRECTION_BOTH
			c.grow_vertical = Control.GROW_DIRECTION_BEGIN


func _panel(parent: Control) -> VBoxContainer:
	var pc := PanelContainer.new()
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_theme_stylebox_override("panel", UiTheme.panel_style())
	parent.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_child(vb)
	return vb


func _build_status_panel(root: Control) -> void:
	var vb := _panel(root)
	_run_label = UiTheme.make_label("Run 1", 20, UiTheme.COL_VIOLET)
	_echo_label = UiTheme.make_label("Echos: 0", 18, Color(0.45, 0.7, 1.0))
	_enemy_label = UiTheme.make_label("Gegner: 0", 18, Color(1.0, 0.55, 0.5))
	vb.add_child(_run_label)
	vb.add_child(_echo_label)
	vb.add_child(_enemy_label)
	_anchor(vb.get_parent(), Control.PRESET_TOP_LEFT)


func _build_score_panel(root: Control) -> void:
	var vb := _panel(root)
	_score_label = UiTheme.make_label("SCORE 0", 26, UiTheme.COL_CYAN)
	_kills_label = UiTheme.make_label("Kills 0", 18, UiTheme.COL_TEXT)
	_best_label = UiTheme.make_label("Highscore 0", 16, UiTheme.COL_VIOLET)
	_fps_label = UiTheme.make_label("FPS", 14, Color(0.5, 0.5, 0.6))
	for l in [_score_label, _kills_label, _best_label, _fps_label]:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		vb.add_child(l)
	_anchor(vb.get_parent(), Control.PRESET_TOP_RIGHT)


func _build_bottom_left(root: Control) -> void:
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vb)
	_hp = _make_bar(vb, Vector2(BAR_W, 28), Color(0.75, 0.1, 0.2), Color(0.95, 0.55, 0.55), true)
	_dash = _make_bar(vb, Vector2(BAR_W * 0.6, 8), UiTheme.COL_CYAN, Color(0, 0, 0, 0), false)
	_bolt = _make_bar(vb, Vector2(BAR_W * 0.6, 8), Color(0.6, 0.45, 1.0), Color(0, 0, 0, 0), false)
	_anchor(vb, Control.PRESET_BOTTOM_LEFT)


func _build_upgrades(root: Control) -> void:
	_upgrades_label = UiTheme.make_label("", 16, UiTheme.COL_VIOLET)
	_upgrades_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_upgrades_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_upgrades_label.custom_minimum_size.x = 320.0
	root.add_child(_upgrades_label)
	_anchor(_upgrades_label, Control.PRESET_BOTTOM_RIGHT)


func _build_boss_bar(root: Control) -> void:
	_boss_root = Control.new()
	_boss_root.name = "BossBar"
	_boss_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_boss_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_root.visible = false
	root.add_child(_boss_root)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	center.offset_top = 16.0
	center.offset_bottom = 96.0
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_root.add_child(center)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vb)
	_boss_name = UiTheme.make_label("", 24, Color(0.85, 0.7, 1.0))
	_boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_boss_name)
	_boss = _make_bar(vb, Vector2(BOSS_W, 20), Color(0.55, 0.15, 0.9), Color(0.9, 0.75, 1.0), false)


func _build_message(root: Control) -> void:
	_msg = UiTheme.make_label("", 44, UiTheme.COL_TEXT)
	_msg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_msg.add_theme_constant_override("outline_size", 8)
	_msg.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_msg.modulate.a = 0.0
	root.add_child(_msg)


func _build_crosshair(root: Control) -> void:
	var dot := ColorRect.new()
	dot.name = "Crosshair"
	dot.color = Color(0.7, 0.95, 1.0, 0.85)
	dot.size = Vector2(4, 4)
	dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dot)


func _build_hint(root: Control) -> void:
	_hint = UiTheme.make_label("WASD Bewegen  ·  Maus Umsehen  ·  LMB Schwert  ·  RMB Echo-Bolzen  ·  Shift Sprint  ·  Space Springen  ·  Q Dash  ·  Esc Pause", 15, Color(0.6, 0.7, 0.85))
	root.add_child(_hint)
	_anchor(_hint, Control.PRESET_CENTER_BOTTOM, 14)
	var tw := create_tween()
	tw.tween_interval(14.0)
	tw.tween_property(_hint, "modulate:a", 0.0, 1.5)


## Bar with a trailing "ghost" that shows recently lost health.
func _make_bar(parent: Control, size: Vector2, color: Color, ghost_color: Color, with_text: bool) -> Dictionary:
	var holder := Control.new()
	holder.custom_minimum_size = size
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(holder)
	var back := ColorRect.new()
	back.color = Color(0.05, 0.03, 0.09, 0.85)
	back.size = size
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(back)
	var ghost := ColorRect.new()
	ghost.color = ghost_color
	ghost.size = size
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(ghost)
	var fill := ColorRect.new()
	fill.color = color
	fill.size = size
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(fill)
	var frame := Panel.new()
	frame.size = size
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	frame.add_theme_stylebox_override("panel", UiTheme.box(Color(0, 0, 0, 0), UiTheme.COL_BORDER, 2, 3, 0))
	holder.add_child(frame)
	var label: Label = null
	if with_text:
		label = UiTheme.make_label("", 15, Color.WHITE)
		label.size = size
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		holder.add_child(label)
	return {"width": size.x, "target": size.x, "ghost_w": size.x, "fill": fill, "ghost": ghost, "label": label, "color": color}


func _update_ghost(bar: Dictionary, delta: float) -> void:
	if bar.is_empty():
		return
	var target: float = bar["target"]
	var g: float = bar["ghost_w"]
	if g > target:
		g = maxf(target, g - float(bar["width"]) * 0.35 * delta)
	else:
		g = target
	bar["ghost_w"] = g
	bar["ghost"].size.x = g


func _set_bar(bar: Dictionary, ratio: float) -> void:
	var w := float(bar["width"]) * clampf(ratio, 0.0, 1.0)
	bar["target"] = w
	bar["fill"].size.x = w
	if w > float(bar["ghost_w"]):
		bar["ghost_w"] = w


# ---------------------------------------------------------------------- API --

func set_health(current: float, maximum: float) -> void:
	var ratio := current / maxf(maximum, 1.0)
	_set_bar(_hp, ratio)
	_hp["label"].text = "%d / %d" % [roundi(current), roundi(maximum)]
	_vignette_mat.set_shader_parameter("low", clampf((0.35 - ratio) / 0.35, 0.0, 1.0) if current > 0.0 else 0.0)


func set_dash(cooldown_left: float, cooldown_total: float) -> void:
	var ready := cooldown_left <= 0.001
	_set_bar(_dash, 1.0 - clampf(cooldown_left / maxf(cooldown_total, 0.01), 0.0, 1.0))
	_dash["fill"].color = UiTheme.COL_CYAN if ready else Color(0.15, 0.45, 0.5)


func set_bolt(cooldown_left: float, cooldown_total: float) -> void:
	var ready := cooldown_left <= 0.001
	_set_bar(_bolt, 1.0 - clampf(cooldown_left / maxf(cooldown_total, 0.01), 0.0, 1.0))
	_bolt["fill"].color = Color(0.6, 0.45, 1.0) if ready else Color(0.3, 0.22, 0.5)


func set_enemies(count: int) -> void:
	_enemy_label.text = "Gegner: %d" % count


func set_run(number: int) -> void:
	_run_label.text = "Run %d" % number


func set_echoes(active: int, stored: int) -> void:
	_echo_label.text = "Echos: %d aktiv  (%d gespeichert)" % [active, stored]


func set_stats(kills: int, score: int, best: int) -> void:
	_score_label.text = "SCORE %d" % score
	_kills_label.text = "Kills %d" % kills
	_best_label.text = "Highscore %d" % best


func set_upgrades(text: String) -> void:
	_upgrades_label.text = text


func show_boss_bar(boss_name: String) -> void:
	_boss_name.text = boss_name
	_set_bar(_boss, 1.0)
	_boss["ghost_w"] = _boss["width"]
	_boss_root.visible = true


func hide_boss_bar() -> void:
	_boss_root.visible = false


func set_boss_health(current: float, maximum: float) -> void:
	_set_bar(_boss, current / maxf(maximum, 1.0))


func flash_damage() -> void:
	var tw := create_tween()
	tw.tween_method(func(v: float) -> void: _vignette_mat.set_shader_parameter("hurt", v), 1.0, 0.0, 0.55)


## seconds < 0 keeps the message until the next one.
func show_message(text: String, seconds := 2.5) -> void:
	_msg.text = text
	if _msg_tween:
		_msg_tween.kill()
	_msg.modulate.a = 1.0
	if seconds > 0.0:
		_msg_tween = create_tween()
		_msg_tween.tween_interval(seconds)
		_msg_tween.tween_property(_msg, "modulate:a", 0.0, 0.6)


func hide_message() -> void:
	if _msg_tween:
		_msg_tween.kill()
	_msg.modulate.a = 0.0
