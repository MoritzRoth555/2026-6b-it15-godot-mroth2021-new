extends Area3D
## Glowing heal orb dropped by enemies.

const Fx := preload("res://scripts/fx.gd")

@export var heal_amount := 15.0
var _t := 0.0
var _orb: MeshInstance3D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2  # player
	monitoring = true
	monitorable = false
	var color := Color(0.1, 0.95, 0.85)
	var sphere := SphereMesh.new()
	sphere.radius = 0.2
	sphere.height = 0.4
	sphere.radial_segments = 8
	sphere.rings = 4
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 3.0
	sphere.material = mat
	_orb = MeshInstance3D.new()
	_orb.name = "Orb"
	_orb.mesh = sphere
	add_child(_orb)
	var light := OmniLight3D.new()
	light.light_color = color
	light.light_energy = 1.2
	light.omni_range = 4.0
	add_child(light)
	var col := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.9
	col.shape = shape
	add_child(col)
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_t += delta
	_orb.position.y = sin(_t * 3.0) * 0.1
	_orb.rotation.y += delta * 2.0


func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("player") and body.has_method("heal"):
		body.heal(heal_amount)
		get_tree().call_group("audio", "play", "pickup")
		Fx.burst(self, global_position, Color(0.1, 0.95, 0.85), 16, 3.0, 0.5)
		queue_free()
