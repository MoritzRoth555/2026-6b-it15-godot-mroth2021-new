extends Area3D
## Detectable damage receiver. `target` must implement apply_hit(damage, from_pos, source).

var target: Node


func receive_hit(damage: float, from_pos: Vector3, source: Node) -> void:
	if target != null and target.has_method("apply_hit"):
		target.apply_hit(damage, from_pos, source)
