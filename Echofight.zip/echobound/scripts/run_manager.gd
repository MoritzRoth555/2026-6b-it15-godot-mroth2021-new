extends Node
## Run management: arena start/reset, kills, score, run counter, highscore,
## death / victory handling, echo storage + persistence.
## Runs end by dying OR by reaching the opened exit portal; both store an echo.

signal run_started(run_number: int)
signal run_ended(summary: Dictionary)

const EnemyScene := preload("res://scenes/Enemy.tscn")
const BossScene := preload("res://scenes/Boss.tscn")
const SaveData := preload("res://scripts/save_data.gd")
const UiTheme := preload("res://scripts/ui_theme.gd")
const Fx := preload("res://scripts/fx.gd")

## Enemy waves before the boss. kinds: guard (standard), scout (fast, fragile), brute (big, tanky).
const WAVES := [
	{"guard": 5},
	{"guard": 3, "scout": 4},
	{"guard": 3, "scout": 2, "brute": 2},
]
## +1 guard per this many ACTIVE echoes (capped) - the more echoes help you, the more enemies come.
const ECHOES_PER_EXTRA_GUARD := 2
const MAX_EXTRA_GUARDS := 4

enum RunState { RUNNING, UPGRADE, ENDING }

@export var game_over_delay := 1.6
@export var kill_score := 100
@export var win_bonus := 1000
@export var boss_bonus := 500
## false = upgrades reset every run (harder, classic roguelike). true = they persist across runs.
@export var persistent_upgrades := false

var state: RunState = RunState.ENDING
var kills := 0
var run_time := 0.0
var stats: Dictionary = {}

var player
var dungeon
var echo_manager
var hud
var upgrade_manager
var upgrade_menu
var game_over

var _enemies_alive := 0
var _boss
var _boss_defeated := false
var _wave := 0
var _arena_cleared := false
var _generation := 0  # invalidates pending restart timers (e.g. after a progress reset)


func setup(p_player, p_dungeon, p_echo_manager, p_hud, p_upgrades, p_menu, p_game_over) -> void:
	player = p_player
	dungeon = p_dungeon
	echo_manager = p_echo_manager
	hud = p_hud
	upgrade_manager = p_upgrades
	upgrade_menu = p_menu
	game_over = p_game_over
	upgrade_manager.capture_base(player)  # un-upgraded stats, before anything is applied
	var data := SaveData.load_data()
	stats = _normalize_stats(data["stats"])
	echo_manager.load_recordings(data["recordings"])
	if persistent_upgrades:
		upgrade_manager.load_levels(data["upgrades"])
	upgrade_menu.upgrade_chosen.connect(_on_upgrade_chosen)
	game_over.restart_requested.connect(start_run)
	game_over.menu_requested.connect(go_to_menu)
	echo_manager.run_number = int(stats["total_runs"])
	player.died.connect(_on_player_died)
	dungeon.exit_entered.connect(_on_exit_entered)


func _physics_process(delta: float) -> void:
	if state == RunState.RUNNING:
		run_time += delta


## Resets the arena and begins a new recording. Stored echoes start playing again.
func start_run() -> void:
	_generation += 1
	get_tree().paused = false
	game_over.hide_screen()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	for e in get_tree().get_nodes_in_group("enemies"):
		e.queue_free()
	_enemies_alive = 0
	kills = 0
	run_time = 0.0
	_arena_cleared = false
	_boss = null
	_boss_defeated = false
	hud.hide_boss_bar()
	state = RunState.RUNNING
	dungeon.set_exit_active(false)
	hud.hide_message()
	if not persistent_upgrades:
		upgrade_manager.clear()
	upgrade_manager.apply_to_player(player)  # base stats (+ upgrades if persistent) before the reset
	player.revive()  # full health, fresh cooldowns
	player.teleport(dungeon.get_player_spawn().global_position, 0.0)
	_wave = 0
	_spawn_wave()
	echo_manager.begin_run(player)
	hud.set_run(echo_manager.run_number)
	hud.set_upgrades(upgrade_manager.summary())
	_update_stats_hud()
	run_started.emit(echo_manager.run_number)


## Wipes echoes, stats and the save file, then starts over.
func reset_progress() -> void:
	SaveData.delete_save()
	stats = SaveData.default_stats()
	echo_manager.clear_all()
	upgrade_manager.clear()
	start_run()
	hud.show_message("Fortschritt gelöscht", 2.0)


func end_run(won: bool) -> void:
	if state != RunState.RUNNING:
		return
	state = RunState.ENDING
	hud.hide_boss_bar()
	var rec = echo_manager.end_run()
	var score := _current_score() + (win_bonus if won else 0)
	stats["total_runs"] = int(stats["total_runs"]) + 1
	stats["total_kills"] = int(stats["total_kills"]) + kills
	stats["best_kills"] = maxi(int(stats["best_kills"]), kills)
	if won:
		stats["wins"] = int(stats["wins"]) + 1
		var best_time := float(stats["best_win_time"])
		if best_time <= 0.0 or run_time < best_time:
			stats["best_win_time"] = run_time
	var new_best := score > int(stats["best_score"])
	if new_best:
		stats["best_score"] = score
	_save()

	_update_stats_hud()
	var summary := {
		"won": won, "kills": kills, "score": score, "time": run_time,
		"new_best": new_best, "best_score": int(stats["best_score"]),
		"boss": _boss_defeated, "echo_saved": rec != null,
		"echoes_stored": echo_manager.get_stored_count(),
		"run_number": echo_manager.run_number,
	}
	run_ended.emit(summary)
	get_tree().call_group("audio", "play", "run_win" if won else "run_lose")
	var gen := _generation
	await get_tree().create_timer(game_over_delay).timeout  # lets the death animation play
	if gen == _generation:
		game_over.show_summary(summary)  # pauses the game; its buttons call start_run() / go_to_menu()


func _on_enemy_died(_enemy: Node3D) -> void:
	if state != RunState.RUNNING:
		return
	kills += 1
	_enemies_alive -= 1
	hud.set_enemies(_enemies_alive)
	_update_stats_hud()
	if _enemies_alive <= 0 and _boss == null and not _boss_defeated:
		var last_wave := _wave + 1 >= WAVES.size()
		_offer_upgrades("ARENA GERÄUMT" if last_wave else "WELLE %d / %d GERÄUMT" % [_wave + 1, WAVES.size()])


## Spawns the current wave: preset composition + extra guards scaling with active echoes.
func _spawn_wave() -> void:
	var list: Array = []
	var comp: Dictionary = WAVES[_wave]
	for kind in comp:
		for i in int(comp[kind]):
			list.append(kind)
	var active_echoes := mini(echo_manager.get_stored_count(), echo_manager.max_active_echoes)
	var extra := mini(active_echoes / ECHOES_PER_EXTRA_GUARD, MAX_EXTRA_GUARDS)
	for i in extra:
		list.append("guard")
	list.shuffle()
	var markers: Array = dungeon.get_enemy_spawns()
	for i in list.size():
		var pos: Vector3 = markers[i % markers.size()].global_position
		if i >= markers.size():
			pos += Vector3(randf_range(-1.5, 1.5), 0.0, randf_range(-1.5, 1.5))
		_spawn_enemy(list[i], pos)
	hud.set_enemies(_enemies_alive)
	var text := "WELLE %d / %d" % [_wave + 1, WAVES.size()]
	if extra > 0:
		text += "\n+%d Gegner durch deine Echos" % extra
	hud.show_message(text, 2.5)


func _spawn_enemy(kind: String, pos: Vector3):
	var e = EnemyScene.instantiate()
	match kind:
		"scout":
			e.max_health = 35.0
			e.move_speed = 5.4
			e.attack_damage = 10.0
			e.attack_windup = 0.3
			e.attack_active = 0.12
			e.attack_recovery = 0.4
			e.attack_cooldown = 0.3
			e.attack_range = 1.9
			e.scale_factor = 0.85
			e.tint = Color(0.08, 0.2, 0.26)
			e.drop_chance = 0.15
			e.detect_range = 40.0
		"brute":
			e.max_health = 170.0
			e.move_speed = 2.5
			e.attack_damage = 28.0
			e.attack_windup = 0.85
			e.attack_recovery = 0.9
			e.attack_range = 2.7
			e.scale_factor = 1.35
			e.tint = Color(0.3, 0.06, 0.09)
			e.stagger_resist = 0.7
			e.drop_chance = 0.5
	e.position = pos
	e.rotation.y = randf_range(0.0, TAU)
	get_parent().add_child(e)
	e.died.connect(_on_enemy_died)
	_enemies_alive += 1
	Fx.burst(self, pos + Vector3(0, 1.0, 0), Color(0.5, 0.3, 1.0), 14, 3.0, 0.6)
	return e


func _on_boss_summon(count: int) -> void:
	if state == RunState.ENDING:
		return
	var markers: Array = dungeon.get_enemy_spawns()
	for i in count:
		var pos: Vector3 = markers[randi() % markers.size()].global_position
		_spawn_enemy("scout", pos)
	hud.set_enemies(_enemies_alive + 1)
	hud.show_message("DER ECHO KEEPER RUFT VERSTÄRKUNG", 2.5)


func _spawn_boss() -> void:
	_boss = BossScene.instantiate()
	_boss.position = dungeon.get_boss_spawn().global_position
	get_parent().add_child(_boss)
	_boss.died.connect(_on_boss_died)
	_boss.summon_requested.connect(_on_boss_summon)
	_boss.health.health_changed.connect(hud.set_boss_health)
	hud.show_boss_bar(_boss.boss_name)
	hud.set_boss_health(_boss.health.current, _boss.health.max_health)
	hud.set_enemies(1)
	hud.show_message("THE ECHO KEEPER ERWACHT", 3.0)


func _on_boss_died(_b: Node3D) -> void:
	if state != RunState.RUNNING:
		return
	_boss_defeated = true
	stats["bosses_defeated"] = int(stats["bosses_defeated"]) + 1
	hud.set_enemies(0)
	hud.hide_boss_bar()
	_update_stats_hud()
	_offer_upgrades("THE ECHO KEEPER BESIEGT", 2.2)  # reward: another upgrade pick + heal orbs


## Arena cleared: after a short beat, pause and let the player pick 1 of 3 random upgrades.
func _offer_upgrades(title: String, delay := 0.9) -> void:
	var gen := _generation
	hud.show_message(title, delay + 0.5)
	get_tree().call_group("audio", "play", "arena_clear")
	await get_tree().create_timer(delay).timeout
	if gen != _generation or state != RunState.RUNNING:
		return
	state = RunState.UPGRADE
	get_tree().paused = true  # recorder, echoes and enemies freeze together -> echo timing stays in sync
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	upgrade_menu.show_offers(upgrade_manager.roll_offers(3))


func _on_upgrade_chosen(id: String) -> void:
	if state != RunState.UPGRADE:
		return
	upgrade_manager.pick(id, player)
	get_tree().call_group("audio", "play", "upgrade")
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	state = RunState.RUNNING
	hud.set_upgrades(upgrade_manager.summary())
	_save()
	if _boss_defeated:
		_arena_cleared = true
		dungeon.set_exit_active(true)
		get_tree().call_group("audio", "play", "portal_open")
		hud.show_message("Upgrade erhalten – Portal geöffnet", 2.5)
	elif _wave + 1 < WAVES.size():
		_wave += 1
		_spawn_wave()
	else:
		hud.show_message("Upgrade erhalten", 1.2)
		_spawn_boss()


func go_to_menu() -> void:
	UiTheme.go_to_menu(get_tree())


func _on_player_died() -> void:
	end_run(false)


func _on_exit_entered() -> void:
	if state == RunState.RUNNING and _arena_cleared:
		end_run(true)


func _save() -> void:
	SaveData.save_data({
		"version": SaveData.VERSION,
		"stats": stats,
		"recordings": echo_manager.export_recordings(),
		"upgrades": upgrade_manager.export_levels() if persistent_upgrades else {},
	})


func _update_stats_hud() -> void:
	hud.set_stats(kills, _current_score(), int(stats["best_score"]))


func _current_score() -> int:
	return kills * kill_score + (boss_bonus if _boss_defeated else 0)


func _normalize_stats(raw: Dictionary) -> Dictionary:
	var s := SaveData.default_stats()
	for k in s:
		if raw.has(k):
			s[k] = float(raw[k]) if k == "best_win_time" else int(raw[k])
	return s
