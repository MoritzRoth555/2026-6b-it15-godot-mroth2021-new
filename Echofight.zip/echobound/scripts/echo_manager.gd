extends Node
## Owns the recorder and all stored recordings. Recordings are only ever appended
## (old runs are never overwritten). Each new run spawns one Echo per stored recording.

signal echoes_changed(active: int, stored: int)

const Recording := preload("res://scripts/echo_recording.gd")
const Recorder := preload("res://scripts/echo_recorder.gd")
const EchoScene := preload("res://scenes/Echo.tscn")

## Only the newest N recordings are replayed at once (all stay stored).
@export var max_active_echoes := 8
## Runs shorter than this many samples (30 per second) are discarded.
@export var min_recording_samples := 10
## Storage cap (save file size). Only beyond this the OLDEST recording is dropped.
@export var max_stored_recordings := 30

var recordings: Array = []   # Array of Recording
var run_number := 0

var _recorder: Node
var _active: Array = []      # Array of Echo nodes


func _ready() -> void:
	_recorder = Recorder.new()
	_recorder.name = "EchoRecorder"
	add_child(_recorder)


func get_stored_count() -> int:
	return recordings.size()


func get_active_count() -> int:
	return _active.size()


## Call when a run starts (after the player is placed at the spawn).
func begin_run(player: Node) -> void:
	_clear_active()
	run_number += 1
	var first := maxi(0, recordings.size() - max_active_echoes)
	for idx in range(first, recordings.size()):
		var echo = EchoScene.instantiate()
		echo.setup(recordings[idx])
		echo.finished.connect(_on_echo_finished)
		add_child(echo)
		echo.start()
		_active.append(echo)
	_recorder.start(player, run_number)
	echoes_changed.emit(_active.size(), recordings.size())


## Call when the run ends (player death). Returns the stored recording or null.
func end_run() -> Recording:
	var rec: Recording = _recorder.stop()
	if rec == null or rec.get_sample_count() < min_recording_samples:
		return null
	recordings.append(rec)
	while recordings.size() > max_stored_recordings:
		recordings.pop_front()
	echoes_changed.emit(_active.size(), recordings.size())
	return rec


## Restores recordings from save data (array of Recording.to_dict() dictionaries).
func load_recordings(arr: Array) -> void:
	recordings.clear()
	for d in arr:
		if typeof(d) != TYPE_DICTIONARY:
			continue
		var rec := Recording.new()
		if rec.load_dict(d):
			recordings.append(rec)
	while recordings.size() > max_stored_recordings:
		recordings.pop_front()
	echoes_changed.emit(_active.size(), recordings.size())


func export_recordings() -> Array:
	var out: Array = []
	for rec in recordings:
		out.append(rec.to_dict())
	return out


## Forget everything (new game).
func clear_all() -> void:
	_clear_active()
	recordings.clear()
	run_number = 0
	echoes_changed.emit(0, 0)


func _clear_active() -> void:
	for e in _active:
		if is_instance_valid(e):
			e.queue_free()
	_active.clear()


func _on_echo_finished(echo: Node3D) -> void:
	_active.erase(echo)
	echoes_changed.emit(_active.size(), recordings.size())
