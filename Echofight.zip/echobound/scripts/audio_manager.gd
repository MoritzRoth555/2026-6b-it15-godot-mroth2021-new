extends Node
## Audio interface. Anything can request a sound without knowing this node:
##   get_tree().call_group("audio", "play", "hit", global_position)   # positional (3D)
##   get_tree().call_group("audio", "play", "dash")                    # non-positional
##   get_tree().call_group("audio", "play_ui", "ui_click")
## Sound names: sword_swing, hit, enemy_death, dash, player_death, boss_slam, ambience, ...
## Lookup order: assets/audio/<name>.ogg|wav|mp3 -> synthesized fallback -> silence (never errors).

const SfxSynth := preload("res://scripts/sfx_synth.gd")
const AUDIO_DIR := "res://assets/audio"
const EXTS := ["ogg", "wav", "mp3"]
const VOLUME_DB := {
	"sword_swing": -8.0, "echo_swing": -14.0, "enemy_swing": -8.0, "enemy_windup": -10.0,
	"hit": -4.0, "bolt": -7.0, "player_hurt": -4.0, "player_death": -2.0, "enemy_death": -5.0,
	"dash": -8.0, "jump": -14.0, "pickup": -6.0, "upgrade": -4.0, "echo_spawn": -10.0,
	"arena_clear": -4.0, "portal_open": -5.0, "boss_roar": -2.0, "boss_charge": -4.0,
	"boss_slam": -1.0, "boss_wave": -3.0, "boss_death": -1.0, "ui_hover": -14.0,
	"ui_click": -8.0, "run_win": -4.0, "run_lose": -6.0, "ambience": -20.0,
}

@export var use_synth_fallback := true
@export var pool_2d := 8
@export var pool_3d := 14

var _cache := {}
var _players_2d: Array = []
var _players_3d: Array = []
var _next_2d := 0
var _next_3d := 0
var _ambience: AudioStreamPlayer


func _ready() -> void:
	add_to_group("audio")
	process_mode = Node.PROCESS_MODE_ALWAYS  # UI sounds must work while the tree is paused
	for i in pool_2d:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players_2d.append(p)
	for i in pool_3d:
		var p3 := AudioStreamPlayer3D.new()
		p3.unit_size = 8.0
		p3.max_distance = 70.0
		add_child(p3)
		_players_3d.append(p3)
	_ambience = AudioStreamPlayer.new()
	_ambience.name = "Ambience"
	add_child(_ambience)


func start_ambience() -> void:
	var stream := _get_stream("ambience")
	if stream == null:
		return
	_ambience.stream = stream
	_ambience.volume_db = float(VOLUME_DB.get("ambience", -20.0))
	_ambience.play()


func stop_ambience() -> void:
	_ambience.stop()


## pos = Vector3.INF (default) plays non-positional; a real position plays 3D.
func play(sound: String, pos := Vector3.INF) -> void:
	var stream := _get_stream(sound)
	if stream == null:
		return
	var vol := float(VOLUME_DB.get(sound, -6.0))
	var pitch := randf_range(0.93, 1.07)
	if pos.is_finite():
		var p3: AudioStreamPlayer3D = _players_3d[_next_3d]
		_next_3d = (_next_3d + 1) % _players_3d.size()
		p3.stream = stream
		p3.volume_db = vol
		p3.pitch_scale = pitch
		p3.global_position = pos
		p3.play()
	else:
		var p: AudioStreamPlayer = _players_2d[_next_2d]
		_next_2d = (_next_2d + 1) % _players_2d.size()
		p.stream = stream
		p.volume_db = vol
		p.pitch_scale = pitch
		p.play()


func play_ui(sound: String) -> void:
	var stream := _get_stream(sound)
	if stream == null:
		return
	var p: AudioStreamPlayer = _players_2d[_next_2d]
	_next_2d = (_next_2d + 1) % _players_2d.size()
	p.stream = stream
	p.volume_db = float(VOLUME_DB.get(sound, -8.0))
	p.pitch_scale = 1.0
	p.play()


func _get_stream(sound: String) -> AudioStream:
	if _cache.has(sound):
		return _cache[sound]
	var stream: AudioStream = null
	for ext in EXTS:
		var path := "%s/%s.%s" % [AUDIO_DIR, sound, ext]
		if ResourceLoader.exists(path):
			stream = load(path)
			break
	if stream == null and use_synth_fallback:
		stream = SfxSynth.make(sound)
	_cache[sound] = stream
	return stream
