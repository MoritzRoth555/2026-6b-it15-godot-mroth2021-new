extends Node
## Records the REAL player only (30 Hz samples + attack/dash/jump events).
## Echoes are never passed to start(), so playback is never re-recorded.

const Recording := preload("res://scripts/echo_recording.gd")
const SAMPLE_INTERVAL := 1.0 / 30.0

var is_recording := false
var recording: Recording

var _player: Node
var _elapsed := 0.0
var _accum := 0.0


func start(player: Node, run_index := 0) -> void:
	_disconnect_player()
	_player = player
	recording = Recording.new()
	recording.run_index = run_index
	_elapsed = 0.0
	_accum = 0.0
	is_recording = true
	_take_sample()
	player.attack_started.connect(_on_attack)
	player.dashed.connect(_on_dash)
	player.jumped.connect(_on_jump)
	player.bolt_fired.connect(_on_bolt)


## Ends the recording and returns it (null if nothing was being recorded).
func stop() -> Recording:
	if not is_recording:
		return null
	if is_instance_valid(_player):
		_take_sample()
	recording.duration = _elapsed
	is_recording = false
	_disconnect_player()
	return recording


func _physics_process(delta: float) -> void:
	if not is_recording or not is_instance_valid(_player):
		return
	_elapsed += delta
	_accum += delta
	if _accum >= SAMPLE_INTERVAL:
		_accum -= SAMPLE_INTERVAL
		_take_sample()


func _take_sample() -> void:
	var f := 0
	var horizontal := Vector2(_player.velocity.x, _player.velocity.z).length()
	if horizontal > 0.5:
		f |= Recording.FLAG_MOVING
	if _player.is_sprinting:
		f |= Recording.FLAG_SPRINT
	if _player.is_dashing:
		f |= Recording.FLAG_DASH
	if not _player.is_on_floor():
		f |= Recording.FLAG_AIRBORNE
	if _player.is_attacking:
		f |= Recording.FLAG_ATTACK
	recording.add_sample(_elapsed, _player.global_position, _player.rotation.y, _player.head.rotation.x, f)


## The player runs earlier in the physics tick than this node, so events get the
## timestamp of the tick they happened in (elapsed + one physics step).
func _now() -> float:
	return _elapsed + get_physics_process_delta_time()


func _on_attack() -> void:
	if is_recording:
		recording.add_event(_now(), &"attack", {"damage": _player.attack_damage * _player.damage_multiplier})


func _on_dash() -> void:
	if is_recording:
		recording.add_event(_now(), &"dash")


func _on_jump() -> void:
	if is_recording:
		recording.add_event(_now(), &"jump")


func _on_bolt() -> void:
	if is_recording:
		recording.add_event(_now(), &"bolt", {"damage": _player.get_bolt_damage()})


func _disconnect_player() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	if _player.attack_started.is_connected(_on_attack):
		_player.attack_started.disconnect(_on_attack)
	if _player.dashed.is_connected(_on_dash):
		_player.dashed.disconnect(_on_dash)
	if _player.jumped.is_connected(_on_jump):
		_player.jumped.disconnect(_on_jump)
	if _player.bolt_fired.is_connected(_on_bolt):
		_player.bolt_fired.disconnect(_on_bolt)
