extends Control
## Title screen: Play / Delete progress (two-step) / Quit, with lifetime stats.

const UiTheme := preload("res://scripts/ui_theme.gd")
const SaveData := preload("res://scripts/save_data.gd")
const AudioManager := preload("res://scripts/audio_manager.gd")

const BG_SHADER := """
shader_type canvas_item;
void fragment() {
	float g = UV.y;
	vec3 top = vec3(0.01, 0.0, 0.03);
	vec3 bottom = vec3(0.08, 0.035, 0.18);
	vec3 col = mix(top, bottom, g * g);
	float glow = smoothstep(0.7, 0.0, distance(UV, vec2(0.5, 1.05)));
	col += vec3(0.05, 0.3, 0.35) * glow * 0.6;
	COLOR = vec4(col, 1.0);
}
"""

var _t := 0.0
var _title_main: Label
var _ghost_a: Label
var _ghost_b: Label
var _stats_label: Label
var _play_btn: Button
var _reset_btn: Button
var _confirming := false
var _motes: CPUParticles2D


func _ready() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var audio := AudioManager.new()
	audio.name = "AudioManager"
	add_child(audio)

	var bg := ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat := ShaderMaterial.new()
	var shader := Shader.new()
	shader.code = BG_SHADER
	mat.shader = shader
	bg.material = mat
	add_child(bg)

	_motes = CPUParticles2D.new()
	_motes.amount = 70
	_motes.lifetime = 10.0
	_motes.preprocess = 10.0
	_motes.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	_motes.direction = Vector2.UP
	_motes.spread = 25.0
	_motes.gravity = Vector2.ZERO
	_motes.initial_velocity_min = 20.0
	_motes.initial_velocity_max = 60.0
	_motes.scale_amount_min = 2.0
	_motes.scale_amount_max = 4.0
	_motes.color = Color(0.5, 0.7, 1.0, 0.55)
	add_child(_motes)
	_place_motes()
	resized.connect(_place_motes)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	vb.custom_minimum_size.x = 420.0
	center.add_child(vb)

	# Title with two "echo" ghosts behind it
	var title_box := Control.new()
	title_box.custom_minimum_size = Vector2(900, 120)
	vb.add_child(title_box)
	_ghost_a = _title_label("ECHOBOUND", Color(0.2, 0.8, 1.0, 0.35))
	_ghost_b = _title_label("ECHOBOUND", Color(0.7, 0.3, 1.0, 0.35))
	_title_main = _title_label("ECHOBOUND", Color(0.75, 0.97, 1.0))
	for l in [_ghost_a, _ghost_b, _title_main]:
		title_box.add_child(l)

	var sub := UiTheme.make_label("T H E   L A S T   L O O P", 28, UiTheme.COL_VIOLET)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(sub)
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 24.0
	vb.add_child(spacer)

	_play_btn = _button(vb, "SPIELEN", 30)
	_play_btn.pressed.connect(func() -> void: UiTheme.start_game(get_tree()))
	_reset_btn = _button(vb, "FORTSCHRITT LÖSCHEN", 20)
	_reset_btn.pressed.connect(_on_reset_pressed)
	var quit_btn := _button(vb, "BEENDEN", 22)
	quit_btn.pressed.connect(func() -> void: get_tree().quit())

	_stats_label = UiTheme.make_label("", 18, UiTheme.COL_TEXT)
	_stats_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_stats_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 24)
	_stats_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_stats_label.grow_vertical = Control.GROW_DIRECTION_BEGIN
	add_child(_stats_label)
	_refresh_stats()
	_play_btn.grab_focus.call_deferred()


func _process(delta: float) -> void:
	_t += delta
	_ghost_a.position.x = sin(_t * 1.3) * 8.0 - 6.0
	_ghost_b.position.x = sin(_t * 1.1 + 2.0) * 8.0 + 6.0
	_title_main.modulate.a = 0.88 + 0.12 * sin(_t * 2.0)


func _title_label(text: String, color: Color) -> Label:
	var l := UiTheme.make_label(text, 96, color)
	l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.0, 0.06, 0.9))
	return l


func _button(parent: Control, text: String, size: int) -> Button:
	var b := Button.new()
	b.text = text
	UiTheme.style_button(b, size)
	parent.add_child(b)
	return b


func _place_motes() -> void:
	_motes.position = Vector2(size.x * 0.5, size.y + 10.0)
	_motes.emission_rect_extents = Vector2(size.x * 0.5, 10.0)


func _refresh_stats() -> void:
	var data := SaveData.load_data()
	var s: Dictionary = data["stats"]
	_stats_label.text = "Runs: %d     Highscore: %d     Echos gespeichert: %d     Bosse besiegt: %d" % [
		int(s["total_runs"]), int(s["best_score"]), (data["recordings"] as Array).size(), int(s["bosses_defeated"])]


func _on_reset_pressed() -> void:
	if not _confirming:
		_confirming = true
		_reset_btn.text = "WIRKLICH LÖSCHEN? (nochmal klicken)"
		get_tree().create_timer(3.0).timeout.connect(_cancel_confirm)
		return
	_confirming = false
	SaveData.delete_save()
	_reset_btn.text = "GELÖSCHT"
	_refresh_stats()


func _cancel_confirm() -> void:
	if _confirming:
		_confirming = false
		_reset_btn.text = "FORTSCHRITT LÖSCHEN"
