extends Node3D
const AssetLoader := preload("res://scripts/asset_loader.gd")
const STONE_TEXTURE := "res://assets/models/stones/stone_base_color.jpg"
const CRYSTAL_DIR := "res://assets/models/crystal"
const STONE_DIR := "res://assets/models/stones"
const KNIGHT_DIR := "res://assets/models/knight"
## Builds the dark-fantasy arena from Godot primitives (no external assets).
## Public API: get_player_spawn(), get_enemy_spawns(), set_exit_active(), signal exit_entered.

signal exit_entered

const ARENA_HALF := 20.0
const WALL_HEIGHT := 6.0
const WALL_THICKNESS := 1.0
const TILE_COUNT := 8

const PORTAL_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;
uniform vec4 tint : source_color = vec4(0.1, 0.95, 0.85, 1.0);
uniform float speed = 2.5;
void fragment() {
	vec2 p = (UV - vec2(0.5)) * 2.0;
	float r = length(p);
	float a = atan(p.y, p.x);
	float swirl = 0.5 + 0.5 * sin(a * 3.0 + r * 10.0 - TIME * speed);
	float swirl2 = 0.5 + 0.5 * sin(a * 5.0 - r * 14.0 + TIME * speed * 0.7);
	float edge = smoothstep(1.0, 0.55, r);
	float core = smoothstep(0.7, 0.0, r);
	float v = (0.25 + 0.5 * swirl * swirl2 + 0.5 * core) * edge;
	ALBEDO = tint.rgb * (0.6 + v * 1.8);
	ALPHA = clamp(v, 0.0, 1.0);
}
"""

var exit_active := false

var _rng := RandomNumberGenerator.new()
var _player_spawn: Marker3D
var _boss_spawn: Marker3D
var _enemy_spawns: Array[Marker3D] = []
var _exit_glow_mat: ShaderMaterial
var _mat_rune: StandardMaterial3D
var _mat_rune_cyan: StandardMaterial3D
var _pulse: Array = []
var _time := 0.0
var _exit_light: OmniLight3D

var _mat_base: StandardMaterial3D
var _mat_tile_a: StandardMaterial3D
var _mat_tile_b: StandardMaterial3D
var _mat_wall: StandardMaterial3D
var _mat_pillar: StandardMaterial3D
var _mat_rubble: StandardMaterial3D
var _crystal_scene: PackedScene
var _stone_scene: PackedScene


func _ready() -> void:
	_rng.seed = 1337
	_mat_base = _make_mat(Color(0.06, 0.06, 0.08), 1.0)
	# Stone pack texture, tinted dark violet/grey, triplanar so any mesh gets a fitting mapping.
	_mat_tile_a = _stone_mat(Color(0.55, 0.52, 0.65), 0.25)
	_mat_tile_b = _stone_mat(Color(0.38, 0.36, 0.5), 0.25)
	_mat_wall = _stone_mat(Color(0.34, 0.3, 0.45), 0.15)
	_mat_pillar = _stone_mat(Color(0.7, 0.66, 0.8), 0.3)
	_mat_rubble = _stone_mat(Color(0.5, 0.47, 0.58), 0.4)
	_mat_rune = _make_mat(Color(0.55, 0.25, 0.95), 0.4, 2.0)
	_mat_rune_cyan = _make_mat(Color(0.1, 0.9, 0.85), 0.4, 2.0)
	_add_pulse(_mat_rune, null, 1.2, 3.0, 0.0, 0.0, 1.0, 0.0)
	_add_pulse(_mat_rune_cyan, null, 1.4, 3.4, 0.0, 0.0, 1.3, 1.5)
	_crystal_scene = AssetLoader.find_scene(CRYSTAL_DIR, "crystal")
	_stone_scene = AssetLoader.find_scene(STONE_DIR)

	_build_environment()
	_build_floor()
	_build_walls()
	_build_pillars()
	_build_obstacles()
	_build_rocks()
	_build_crystals()
	_build_knight_preview()
	_build_spawn_points()
	_build_exit()
	_build_runes()
	_build_trim()
	_build_dust()
	set_exit_active(false)


func get_player_spawn() -> Marker3D:
	return _player_spawn


func get_boss_spawn() -> Marker3D:
	return _boss_spawn


func get_enemy_spawns() -> Array[Marker3D]:
	return _enemy_spawns


## Unlocks / locks the exit (unlocked after the arena is cleared, Phase 5+).
func set_exit_active(active: bool) -> void:
	exit_active = active
	var color := Color(0.1, 0.95, 0.85) if active else Color(0.35, 0.12, 0.45)
	_exit_glow_mat.set_shader_parameter("tint", color)
	_exit_glow_mat.set_shader_parameter("speed", 2.5 if active else 0.6)
	_exit_light.light_color = color


# ----------------------------------------------------------------- helpers --

func _make_mat(color: Color, roughness := 0.9, emission_energy := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	if emission_energy > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission_energy
	return m


func _stone_mat(tint: Color, uv_scale: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = tint
	m.roughness = 0.95
	if ResourceLoader.exists(STONE_TEXTURE):
		m.albedo_texture = load(STONE_TEXTURE)
		m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	m.uv1_triplanar = true
	m.uv1_scale = Vector3.ONE * uv_scale
	return m


func _add_mesh(parent: Node, node_name: String, mesh: Mesh, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


func _box_mesh(size: Vector3, mat: Material) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = size
	m.material = mat
	return m


func _add_box_body(parent: Node, node_name: String, size: Vector3, pos: Vector3,
		mat: Material, rot_y_deg := 0.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.rotation_degrees.y = rot_y_deg
	body.collision_layer = 1
	_add_mesh(body, "Mesh", _box_mesh(size, mat), Vector3.ZERO)
	var col := CollisionShape3D.new()
	col.name = "Collision"
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	parent.add_child(body)
	return body


func _container(node_name: String) -> Node3D:
	var n := Node3D.new()
	n.name = node_name
	add_child(n)
	return n


# ------------------------------------------------------------- environment --

func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.02, 0.01, 0.05)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.28, 0.22, 0.5)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.1, 0.07, 0.2)
	env.fog_density = 0.018
	env.glow_enabled = true
	env.glow_intensity = 0.9
	env.glow_bloom = 0.08
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.08
	env.adjustment_saturation = 1.12
	var we := WorldEnvironment.new()
	we.name = "WorldEnvironment"
	we.environment = env
	add_child(we)

	# Dim cold "moonlight" so the arena stays readable.
	var sun := DirectionalLight3D.new()
	sun.name = "MoonLight"
	sun.light_color = Color(0.5, 0.55, 0.95)
	sun.light_energy = 0.45
	sun.rotation_degrees = Vector3(-60.0, 30.0, 0.0)
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)


# ------------------------------------------------------------------- floor --

func _build_floor() -> void:
	var root := _container("Floor")
	var size := ARENA_HALF * 2.0
	_add_box_body(root, "FloorBody", Vector3(size, 1.0, size), Vector3(0, -0.5, 0), _mat_base)
	var tile := size / TILE_COUNT
	var tile_mats: Array[Material] = [_mat_tile_a, _mat_tile_b]
	for variant in 2:
		var positions: Array[Vector3] = []
		for ix in TILE_COUNT:
			for iz in TILE_COUNT:
				if (ix + iz) % 2 == variant:
					positions.append(Vector3(-ARENA_HALF + tile * (ix + 0.5), 0.03, -ARENA_HALF + tile * (iz + 0.5)))
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = _box_mesh(Vector3(tile - 0.15, 0.06, tile - 0.15), tile_mats[variant])
		mm.instance_count = positions.size()
		for i in positions.size():
			mm.set_instance_transform(i, Transform3D(Basis.IDENTITY, positions[i]))
		var mmi := MultiMeshInstance3D.new()
		mmi.name = "Tiles_%d" % variant
		mmi.multimesh = mm
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mmi)


func _build_walls() -> void:
	var root := _container("Walls")
	var len_full := ARENA_HALF * 2.0 + WALL_THICKNESS * 2.0
	var y := WALL_HEIGHT * 0.5
	var off := ARENA_HALF + WALL_THICKNESS * 0.5
	_add_box_body(root, "WallNorth", Vector3(len_full, WALL_HEIGHT, WALL_THICKNESS), Vector3(0, y, -off), _mat_wall)
	_add_box_body(root, "WallSouth", Vector3(len_full, WALL_HEIGHT, WALL_THICKNESS), Vector3(0, y, off), _mat_wall)
	_add_box_body(root, "WallEast", Vector3(WALL_THICKNESS, WALL_HEIGHT, len_full), Vector3(off, y, 0), _mat_wall)
	_add_box_body(root, "WallWest", Vector3(WALL_THICKNESS, WALL_HEIGHT, len_full), Vector3(-off, y, 0), _mat_wall)


func _build_pillars() -> void:
	var root := _container("Pillars")
	var spots: Array[Vector2] = [
		Vector2(-9, -9), Vector2(9, -9), Vector2(-9, 9), Vector2(9, 9),
		Vector2(-16, 0), Vector2(16, 0), Vector2(-16, -16), Vector2(16, -16),
	]
	for i in spots.size():
		_add_pillar(root, "Pillar_%d" % i, spots[i], 0.9, 5.5)


func _add_pillar(parent: Node, node_name: String, xz: Vector2, radius: float, height: float) -> void:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = Vector3(xz.x, height * 0.5, xz.y)
	body.collision_layer = 1
	var cyl := CylinderMesh.new()
	cyl.top_radius = radius * 0.85
	cyl.bottom_radius = radius
	cyl.height = height
	cyl.radial_segments = 8
	cyl.rings = 1
	cyl.material = _mat_pillar
	_add_mesh(body, "Shaft", cyl, Vector3.ZERO)
	_add_mesh(body, "Base", _box_mesh(Vector3(radius * 2.7, 0.5, radius * 2.7), _mat_pillar), Vector3(0, -height * 0.5 + 0.25, 0))
	_add_mesh(body, "Cap", _box_mesh(Vector3(radius * 2.7, 0.5, radius * 2.7), _mat_pillar), Vector3(0, height * 0.5 - 0.25, 0))
	for ring_def in [[-1.3, _mat_rune_cyan], [-1.75, _mat_rune]]:
		var ring := CylinderMesh.new()
		ring.top_radius = radius * 1.07
		ring.bottom_radius = radius * 1.07
		ring.height = 0.12
		ring.radial_segments = 8
		ring.rings = 1
		ring.material = ring_def[1]
		var rmi := _add_mesh(body, "RuneRing", ring, Vector3(0, height * 0.5 + ring_def[0], 0))
		rmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var col := CollisionShape3D.new()
	col.name = "Collision"
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = height
	col.shape = shape
	body.add_child(col)
	parent.add_child(body)


func _build_obstacles() -> void:
	var root := _container("Obstacles")
	_add_box_body(root, "Block_A", Vector3(2.5, 1.2, 2.5), Vector3(-5, 0.6, 3), _mat_rubble, 20.0)
	_add_box_body(root, "Block_B", Vector3(2.0, 1.0, 2.0), Vector3(6, 0.5, -2), _mat_rubble, -15.0)
	_add_box_body(root, "BrokenWall_A", Vector3(5.0, 2.0, 0.8), Vector3(-8, 1.0, -4), _mat_rubble, 10.0)
	_add_box_body(root, "BrokenWall_B", Vector3(4.0, 1.6, 0.8), Vector3(10, 0.8, 6), _mat_rubble, 70.0)
	_add_box_body(root, "Block_C", Vector3(1.6, 0.8, 1.6), Vector3(0, 0.4, -6), _mat_rubble, 45.0)


# ---------------------------------------------------------------- crystals --

func _build_crystals() -> void:
	var root := _container("Crystals")
	var colors: Array[Color] = [Color(0.2, 0.5, 1.0), Color(0.1, 0.9, 0.8), Color(0.55, 0.25, 0.95)]
	for i in 14:
		var along := _rng.randf_range(-17.0, 17.0)
		var pos: Vector3
		match i % 4:
			0: pos = Vector3(along, 0, -19.0)
			1: pos = Vector3(along, 0, 19.0)
			2: pos = Vector3(19.0, 0, along)
			_: pos = Vector3(-19.0, 0, along)
		_add_crystal_cluster(root, "CrystalCluster_%d" % i, pos, colors[i % colors.size()], i % 2 == 0)


func _add_crystal_cluster(parent: Node, node_name: String, pos: Vector3, color: Color, with_light := true) -> void:
	var cluster := Node3D.new()
	cluster.name = node_name
	cluster.position = pos
	parent.add_child(cluster)
	var mat := _make_mat(color, 0.3, 3.0)
	if _crystal_scene != null:
		for k in _rng.randi_range(2, 3):
			var crystal := AssetLoader.instance_fitted(_crystal_scene, _rng.randf_range(1.0, 2.4))
			if crystal == null:
				break
			crystal.name = "CrystalModel_%d" % k
			crystal.position = Vector3(_rng.randf_range(-0.5, 0.5), 0, _rng.randf_range(-0.5, 0.5))
			crystal.rotation_degrees = Vector3(_rng.randf_range(-10, 10), _rng.randf_range(0, 360), _rng.randf_range(-10, 10))
			AssetLoader.apply_override(crystal, mat)
			cluster.add_child(crystal)
	else:
		_add_procedural_crystals(cluster, mat)
	for n in cluster.find_children("*", "MeshInstance3D", true, false):
		var gi := n as MeshInstance3D
		gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		gi.visibility_range_end = 45.0
	var crystal_light: OmniLight3D = null
	if with_light:
		var light := OmniLight3D.new()
		light.name = "CrystalLight"
		light.position = Vector3(0, 1.0, 0)
		light.light_color = color
		light.light_energy = 2.2
		light.omni_range = 11.0
		light.shadow_enabled = false
		light.distance_fade_enabled = true
		light.distance_fade_begin = 30.0
		light.distance_fade_length = 10.0
		cluster.add_child(light)
		crystal_light = light
	_add_pulse(mat, crystal_light, 2.2, 4.2, 1.6, 2.8, randf_range(0.8, 1.6), randf() * TAU)


func _add_procedural_crystals(cluster: Node3D, mat: Material) -> void:
	for k in _rng.randi_range(3, 4):
		var h := _rng.randf_range(0.8, 2.2)
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.0
		cyl.bottom_radius = _rng.randf_range(0.15, 0.3)
		cyl.height = h
		cyl.radial_segments = 5
		cyl.rings = 1
		cyl.material = mat
		var mi := _add_mesh(cluster, "Crystal_%d" % k, cyl,
			Vector3(_rng.randf_range(-0.4, 0.4), h * 0.5, _rng.randf_range(-0.4, 0.4)))
		mi.rotation_degrees = Vector3(_rng.randf_range(-14, 14), _rng.randf_range(0, 360), _rng.randf_range(-14, 14))


# ------------------------------------------------------------------- rocks --

func _build_rocks() -> void:
	var root := _container("Rocks")
	var rock_rng := RandomNumberGenerator.new()
	rock_rng.seed = 4242
	for i in 16:
		var side := i % 4
		var along := rock_rng.randf_range(-17.0, 17.0)
		var inset := rock_rng.randf_range(0.8, 3.0)
		var pos := Vector3.ZERO
		match side:
			0: pos = Vector3(along, 0, -ARENA_HALF + inset)
			1: pos = Vector3(along, 0, ARENA_HALF - inset)
			2: pos = Vector3(ARENA_HALF - inset, 0, along)
			_: pos = Vector3(-ARENA_HALF + inset, 0, along)
		if Vector2(pos.x, pos.z).distance_to(Vector2(0, 15)) < 4.0 or absf(pos.x) < 4.0 and pos.z < -15.0:
			continue  # keep player spawn and exit clear
		var radius := rock_rng.randf_range(0.5, 1.3)
		_add_rock(root, "Rock_%d" % i, pos, radius, rock_rng)


func _add_rock(parent: Node, node_name: String, pos: Vector3, radius: float, rock_rng: RandomNumberGenerator) -> void:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.rotation_degrees.y = rock_rng.randf_range(0, 360)
	body.collision_layer = 1
	var shape := SphereShape3D.new()
	shape.radius = radius * 0.8
	var col := CollisionShape3D.new()
	col.name = "Collision"
	col.shape = shape
	col.position.y = radius * 0.5
	body.add_child(col)
	if _stone_scene != null:
		var model := AssetLoader.instance_fitted(_stone_scene, radius * 1.4)
		if model != null:
			body.add_child(model)
	else:
		var mi := MeshInstance3D.new()
		mi.name = "Mesh"
		mi.mesh = _make_rock_mesh(radius)
		mi.material_override = _mat_rubble
		mi.position.y = radius * 0.35
		body.add_child(mi)
	parent.add_child(body)


## Low-poly boulder: a coarse sphere with per-vertex jitter (hash of position, so seams stay closed).
func _make_rock_mesh(radius: float) -> ArrayMesh:
	var sphere := SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	sphere.radial_segments = 7
	sphere.rings = 4
	var arrays := sphere.get_mesh_arrays()
	var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var normals := PackedVector3Array()
	normals.resize(verts.size())
	for i in verts.size():
		var v := verts[i]
		var key := Vector3i(roundi(v.x * 1000.0), roundi(v.y * 1000.0), roundi(v.z * 1000.0))
		var n := float(hash(key) % 1000) / 1000.0
		v = v * (0.72 + 0.5 * n)
		v.y = maxf(v.y, -radius * 0.45)
		verts[i] = v
		normals[i] = v.normalized()
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


# ------------------------------------------------------------ knight preview --

## If a knight model exists in assets/models/knight/, show it as a blue echo statue.
## (Echoes in Phase 3 will use the same model.)
func _build_knight_preview() -> void:
	var scene := AssetLoader.find_scene(KNIGHT_DIR)
	if scene == null:
		return
	var knight := AssetLoader.instance_fitted(scene, 1.85)
	if knight == null:
		return
	knight.name = "KnightEchoPreview"
	knight.position = Vector3(0, 0.06, 8)
	knight.rotation_degrees.y = 180.0
	var ghost := StandardMaterial3D.new()
	ghost.albedo_color = Color(0.25, 0.55, 1.0, 0.45)
	ghost.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ghost.emission_enabled = true
	ghost.emission = Color(0.15, 0.4, 1.0)
	ghost.emission_energy_multiplier = 1.2
	AssetLoader.apply_override(knight, ghost)
	add_child(knight)


# ------------------------------------------------------------ spawn / exit --

func _build_spawn_points() -> void:
	var root := _container("SpawnPoints")
	_player_spawn = Marker3D.new()
	_player_spawn.name = "PlayerSpawn"
	_player_spawn.position = Vector3(0, 0.1, 15)
	root.add_child(_player_spawn)
	_boss_spawn = Marker3D.new()
	_boss_spawn.name = "BossSpawn"
	_boss_spawn.position = Vector3(0, 0.1, -3)  # on the inner sigil ring
	root.add_child(_boss_spawn)

	var enemy_positions: Array[Vector3] = [
		Vector3(-11, 0.1, -9), Vector3(11, 0.1, -9), Vector3(0, 0.1, -13),
		Vector3(-13, 0.1, 6), Vector3(13, 0.1, 2),
		Vector3(-14, 0.1, -14), Vector3(14, 0.1, -14), Vector3(-6, 0.1, 9),
	]
	for i in enemy_positions.size():
		var m := Marker3D.new()
		m.name = "EnemySpawn_%d" % i
		m.position = enemy_positions[i]
		m.add_to_group("enemy_spawn")
		root.add_child(m)
		_enemy_spawns.append(m)


func _build_exit() -> void:
	var root := _container("Exit")
	root.position = Vector3(0, 0, -19.0)
	var stone := _mat_pillar
	_add_box_body(root, "ExitPillarL", Vector3(1.0, 5.0, 1.0), Vector3(-2.7, 2.5, 0), stone)
	_add_box_body(root, "ExitPillarR", Vector3(1.0, 5.0, 1.0), Vector3(2.7, 2.5, 0), stone)
	_add_box_body(root, "ExitLintel", Vector3(6.4, 1.0, 1.0), Vector3(0, 5.5, 0), stone)

	_exit_glow_mat = ShaderMaterial.new()
	var portal_shader := Shader.new()
	portal_shader.code = PORTAL_SHADER
	_exit_glow_mat.shader = portal_shader
	var quad := QuadMesh.new()
	quad.size = Vector2(4.4, 5.0)
	quad.material = _exit_glow_mat
	_add_mesh(root, "PortalGlow", quad, Vector3(0, 2.5, 0))

	_exit_light = OmniLight3D.new()
	_exit_light.name = "PortalLight"
	_exit_light.position = Vector3(0, 2.5, 1.5)
	_exit_light.light_energy = 2.5
	_exit_light.omni_range = 10.0
	root.add_child(_exit_light)

	var zone := Area3D.new()
	zone.name = "ExitZone"
	zone.collision_layer = 0
	zone.collision_mask = 2  # player
	zone.position = Vector3(0, 2.0, 1.0)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(4.0, 4.0, 1.5)
	col.shape = shape
	zone.add_child(col)
	root.add_child(zone)
	zone.body_entered.connect(_on_exit_body_entered)


func _on_exit_body_entered(body: Node3D) -> void:
	if exit_active and body.is_in_group("player"):
		exit_entered.emit()


# ------------------------------------------------------- animation / effects --

func _process(delta: float) -> void:
	_time += delta
	for p in _pulse:
		var k := 0.5 + 0.5 * sin(_time * float(p["speed"]) + float(p["phase"]))
		var m = p["mat"]
		if m != null:
			m.emission_energy_multiplier = lerpf(float(p["lo"]), float(p["hi"]), k)
		var l = p["light"]
		if l != null:
			l.light_energy = lerpf(float(p["llo"]), float(p["lhi"]), k)


func _add_pulse(mat, light, lo: float, hi: float, light_lo: float, light_hi: float, speed: float, phase: float) -> void:
	_pulse.append({"mat": mat, "light": light, "lo": lo, "hi": hi,
		"llo": light_lo, "lhi": light_hi, "speed": speed, "phase": phase})


## Glowing floor sigils (pulsing) - flat torus rings plus radial spokes.
func _build_runes() -> void:
	var root := _container("Runes")
	_add_rune_circle(root, "RuneCircleOuter", Vector3(0, 0.075, 0), 5.2, _mat_rune)
	_add_rune_circle(root, "RuneCircleInner", Vector3(0, 0.08, 0), 3.2, _mat_rune_cyan)
	_add_rune_circle(root, "SpawnCircle", Vector3(0, 0.075, 15), 2.0, _mat_rune_cyan)
	for i in 8:
		var a := deg_to_rad(i * 45.0)
		var spoke := _add_mesh(root, "Spoke_%d" % i, _box_mesh(Vector3(0.12, 0.02, 2.0), _mat_rune),
			Vector3(sin(a) * 4.2, 0.075, cos(a) * 4.2))
		spoke.rotation_degrees.y = i * 45.0
		spoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _add_rune_circle(parent: Node, node_name: String, pos: Vector3, radius: float, mat: Material) -> void:
	var torus := TorusMesh.new()
	torus.inner_radius = radius - 0.12
	torus.outer_radius = radius + 0.12
	torus.rings = 32
	torus.ring_segments = 4
	torus.material = mat
	var mi := _add_mesh(parent, node_name, torus, pos)
	mi.scale = Vector3(1.0, 0.12, 1.0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


## Glowing light bands running along the inside of the walls.
func _build_trim() -> void:
	var root := _container("WallTrim")
	var inner := ARENA_HALF - 0.04
	var len_full := ARENA_HALF * 2.0
	var bands: Array = [[1.4, _mat_rune, 0.14], [0.45, _mat_rune_cyan, 0.08]]
	for b in bands:
		var y: float = b[0]
		var h: float = b[2]
		var meshes: Array = [
			["TrimN", Vector3(len_full, h, 0.06), Vector3(0, y, -inner)],
			["TrimS", Vector3(len_full, h, 0.06), Vector3(0, y, inner)],
			["TrimE", Vector3(0.06, h, len_full), Vector3(inner, y, 0)],
			["TrimW", Vector3(0.06, h, len_full), Vector3(-inner, y, 0)],
		]
		for m in meshes:
			var mi := _add_mesh(root, m[0], _box_mesh(m[1], b[1]), m[2])
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


## Drifting magical motes filling the arena air.
func _build_dust() -> void:
	var p := CPUParticles3D.new()
	p.name = "MagicDust"
	var mesh := SphereMesh.new()
	mesh.radius = 0.03
	mesh.height = 0.06
	mesh.radial_segments = 4
	mesh.rings = 2
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.5, 0.7, 1.0)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.emission_enabled = true
	m.emission = Color(0.4, 0.6, 1.0)
	m.emission_energy_multiplier = 2.5
	mesh.material = m
	p.mesh = mesh
	p.amount = 120
	p.lifetime = 9.0
	p.preprocess = 9.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(19.0, 2.5, 19.0)
	p.position = Vector3(0, 3.0, 0)
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = 0.05
	p.initial_velocity_max = 0.35
	p.gravity = Vector3(0, 0.05, 0)
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.6
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(p)
