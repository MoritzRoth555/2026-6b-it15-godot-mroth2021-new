extends CanvasLayer
## End-of-run screen (death or victory): run summary + "next run" / "main menu".
## Pauses the game while visible. Signals tell the run manager what to do.

signal restart_requested
signal menu_requested

const UiTheme := preload("res://scripts/ui_theme.gd")

var _root: Control
var _title: Label
var _lines: Label
var _restart_btn: Button


func _ready() -> void:
	layer = 25
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.0, 0.04, 0.85)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 18)
	vb.custom_minimum_size.x = 460.0
	center.add_child(vb)

	_title = UiTheme.make_label("", 64, UiTheme.COL_BLOOD)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_title)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiTheme.panel_style())
	vb.add_child(panel)
	_lines = UiTheme.make_label("", 22, UiTheme.COL_TEXT)
	_lines.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panel.add_child(_lines)

	_restart_btn = Button.new()
	_restart_btn.text = "NÄCHSTER RUN"
	UiTheme.style_button(_restart_btn, 26)
	_restart_btn.pressed.connect(func() -> void: restart_requested.emit())
	vb.add_child(_restart_btn)
	var menu_btn := Button.new()
	menu_btn.text = "HAUPTMENÜ"
	UiTheme.style_button(menu_btn, 22)
	menu_btn.pressed.connect(func() -> void: menu_requested.emit())
	vb.add_child(menu_btn)


## summary keys: won, kills, score, time, new_best, best_score, boss, echo_saved, echoes_stored, run_number
func show_summary(summary: Dictionary) -> void:
	var won: bool = summary.get("won", false)
	_title.text = "SIEG" if won else "DU BIST GEFALLEN"
	_title.add_theme_color_override("font_color", UiTheme.COL_CYAN if won else UiTheme.COL_BLOOD)
	var t := int(float(summary.get("time", 0.0)))
	var text := "Run %d\n\nKills: %d%s\nZeit: %d:%02d\nScore: %d\n" % [
		int(summary.get("run_number", 0)), int(summary.get("kills", 0)),
		"   +  Boss besiegt" if summary.get("boss", false) else "", t / 60, t % 60, int(summary.get("score", 0))]
	text += "\nNEUER HIGHSCORE!" if summary.get("new_best", false) else "\nHighscore: %d" % int(summary.get("best_score", 0))
	if summary.get("echo_saved", false):
		text += "\nDein Echo #%d wurde gespeichert" % int(summary.get("echoes_stored", 0))
	_lines.text = text
	visible = true
	_root.modulate.a = 0.0
	var tw := create_tween()
	tw.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.tween_property(_root, "modulate:a", 1.0, 0.5)
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_restart_btn.grab_focus.call_deferred()


func hide_screen() -> void:
	visible = false
