extends CharacterBody3D
## Dungeon Guard. State machine: IDLE -> CHASE -> ATTACK -> DEAD.

signal died(enemy: Node3D)

const Health := preload("res://scripts/health_component.gd")
const Hitbox := preload("res://scripts/hitbox.gd")
const Hurtbox := preload("res://scripts/hurtbox.gd")
const Fx := preload("res://scripts/fx.gd")
const Pickup := preload("res://scripts/pickup.gd")

enum State { IDLE, CHASE, ATTACK, DEAD }

@export var max_health := 70.0
@export var move_speed := 3.8
@export var detect_range := 16.0
@export var lose_range := 26.0
@export var attack_range := 2.1
@export var attack_damage := 18.0
@export var attack_windup := 0.45
@export var attack_active := 0.15
@export var attack_recovery := 0.6
@export var attack_cooldown := 0.6
@export var gravity := 22.0
@export_range(0.0, 1.0) var drop_chance := 0.25
## Variant support (set by the run manager before the enemy enters the tree).
@export var scale_factor := 1.0
@export var tint := Color(0.17, 0.16, 0.22)
@export_range(0.0, 1.0) var stagger_resist := 0.0

@onready var visual: Node3D = $Visual

var state: State = State.IDLE
var health: Health
var hitbox: Hitbox
var hurtbox: Hurtbox

var _target: Node3D
var _attack_t := 0.0
var _strike_started := false
var _attack_cd := 0.0
var _stun_left := 0.0
var _t := 0.0
var _body_mat: StandardMaterial3D
var _eye_mat: StandardMaterial3D
var _weapon: Node3D
var _flash_tween: Tween
var _upper: Node3D
var _leg_l: Node3D
var _leg_r: Node3D
var _arm_l: Node3D
var _walk_phase := 0.0
var _recoil := 0.0

const EYE_IDLE := Color(0.7, 0.25, 1.0)
const EYE_ALERT := Color(1.0, 0.15, 0.1)


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4          # enemy
	collision_mask = 1 | 2 | 4   # world, player, enemy
	_build_visual()
	visual.scale = Vector3.ONE * scale_factor
	_body_mat.albedo_color = tint
	var body_shape := get_node("CollisionShape3D") as CollisionShape3D
	body_shape.scale = Vector3.ONE * scale_factor
	body_shape.position.y = 0.95 * scale_factor

	health = Health.new()
	health.name = "Health"
	add_child(health)
	health.setup(max_health)
	health.died.connect(_on_died)

	hurtbox = Hurtbox.new()
	hurtbox.name = "Hurtbox"
	hurtbox.collision_layer = 64  # hurtbox_enemy
	hurtbox.collision_mask = 0
	hurtbox.monitoring = false
	hurtbox.target = self
	_add_box_shape(hurtbox, Vector3(0.9, 1.9, 0.9), Vector3(0, 0.95, 0))
	hurtbox.scale = Vector3.ONE * scale_factor
	add_child(hurtbox)

	hitbox = Hitbox.new()
	hitbox.name = "Hitbox"
	hitbox.collision_layer = 16   # hitbox
	hitbox.collision_mask = 32    # hurtbox_player
	hitbox.damage = attack_damage
	hitbox.source = self
	hitbox.position = Vector3(0, 1.1, -1.2) * scale_factor
	hitbox.scale = Vector3.ONE * scale_factor
	_add_box_shape(hitbox, Vector3(1.5, 1.4, 1.6), Vector3.ZERO)
	add_child(hitbox)


func _physics_process(delta: float) -> void:
	_t += delta
	_attack_cd = maxf(_attack_cd - delta, 0.0)
	_animate(delta)
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1

	if state == State.DEAD:
		_friction(delta)
		move_and_slide()
		return

	if _stun_left > 0.0:
		_stun_left -= delta
		_friction(delta)
		move_and_slide()
		return

	_target = _find_player()
	var to := Vector3.ZERO
	var dist := INF
	if _target != null:
		to = _target.global_position - global_position
		to.y = 0.0
		dist = to.length()

	match state:
		State.IDLE:
			_friction(delta)
			if _target != null and dist <= detect_range:
				_set_state(State.CHASE)
		State.CHASE:
			if _target == null or dist > lose_range:
				_set_state(State.IDLE)
			elif dist <= attack_range and _attack_cd <= 0.0:
				_start_attack()
			else:
				var dir := to.normalized()
				_face(dir, delta)
				var spd := move_speed if dist > attack_range * 0.8 else 0.0
				velocity.x = dir.x * spd
				velocity.z = dir.z * spd
		State.ATTACK:
			_friction(delta)
			_update_attack(delta, to)

	move_and_slide()


# ------------------------------------------------------------------ states --

func _set_state(new_state: State) -> void:
	state = new_state
	if new_state != State.ATTACK:
		_eye_mat.emission = EYE_IDLE
		_eye_mat.albedo_color = EYE_IDLE


func _start_attack() -> void:
	state = State.ATTACK
	get_tree().call_group("audio", "play", "enemy_windup", global_position)
	_attack_t = 0.0
	_strike_started = false
	_eye_mat.emission = EYE_ALERT
	_eye_mat.albedo_color = EYE_ALERT


func _update_attack(delta: float, to: Vector3) -> void:
	_attack_t += delta
	var windup_end := attack_windup
	var active_end := attack_windup + attack_active
	var total := active_end + attack_recovery
	if _attack_t < windup_end:
		if to.length_squared() > 0.001:
			_face(to.normalized(), delta)
		var k := _attack_t / windup_end
		_weapon.rotation_degrees.x = lerpf(-10.0, 160.0, k)  # raise weapon overhead (telegraph)
	elif _attack_t < active_end:
		_weapon.rotation_degrees.x = lerpf(160.0, 80.0, (_attack_t - windup_end) / attack_active)  # overhead -> forward
		if not _strike_started:
			_strike_started = true
			hitbox.damage = attack_damage
			hitbox.begin_swing()
			get_tree().call_group("audio", "play", "enemy_swing", global_position)
	else:
		if hitbox.active:
			hitbox.end_swing()
		var k2 := clampf((_attack_t - active_end) / attack_recovery, 0.0, 1.0)
		_weapon.rotation_degrees.x = lerpf(80.0, -10.0, k2)
		if _attack_t >= total:
			_attack_cd = attack_cooldown
			_weapon.rotation_degrees.x = -10.0
			_set_state(State.CHASE)


func _find_player() -> Node3D:
	var best: Node3D = null
	var best_d := INF
	for p in get_tree().get_nodes_in_group("player"):
		if p.get("is_dead") == true:
			continue
		var d := global_position.distance_squared_to(p.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best


func _face(dir: Vector3, delta: float) -> void:
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 1.0 - exp(-10.0 * delta))


func _friction(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 25.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 25.0 * delta)


# ------------------------------------------------------------------ damage --

## Called by Hurtbox. Hit reaction: knockback, stagger, flash, sparks.
func apply_hit(damage: float, from_pos: Vector3, _source: Node) -> void:
	if state == State.DEAD:
		return
	var dealt := health.take_damage(damage, _source)
	if dealt <= 0.0:
		return
	Fx.burst(self, global_position + Vector3(0, 1.3, 0), Color(0.7, 0.9, 1.0), 12, 4.5, 0.4)
	if state == State.DEAD:
		return
	var away := global_position - from_pos
	away.y = 0.0
	if away.length_squared() > 0.001:
		velocity.x = away.normalized().x * 6.0 * (1.0 - stagger_resist)
		velocity.z = away.normalized().z * 6.0 * (1.0 - stagger_resist)
	_stun_left = 0.3 * (1.0 - stagger_resist)
	_recoil = 1.0
	if hitbox.active:
		hitbox.end_swing()
	if state != State.CHASE:
		_set_state(State.CHASE)
	_attack_cd = maxf(_attack_cd, 0.4)
	_weapon.rotation_degrees.x = -10.0
	_flash()


func _flash() -> void:
	_body_mat.emission_enabled = true
	_body_mat.emission = Color(1, 1, 1)
	_body_mat.emission_energy_multiplier = 2.0
	if _flash_tween:
		_flash_tween.kill()
	_flash_tween = create_tween()
	_flash_tween.tween_property(_body_mat, "emission_energy_multiplier", 0.0, 0.2)


func _on_died() -> void:
	state = State.DEAD
	get_tree().call_group("audio", "play", "enemy_death", global_position)
	hitbox.end_swing()
	collision_layer = 0
	hurtbox.set_deferred("monitorable", false)
	Fx.burst(self, global_position + Vector3(0, 1.2, 0), Color(0.5, 0.3, 1.0), 30, 6.0, 0.8)
	Fx.burst(self, global_position + Vector3(0, 0.8, 0), Color(0.5, 0.9, 1.0), 14, 1.2, 1.6, 1.5)  # rising soul wisps
	var tw := create_tween()
	tw.tween_property(visual, "rotation_degrees:x", 90.0, 0.5).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_interval(1.5)
	tw.tween_property(visual, "scale", Vector3.ZERO, 0.4)
	tw.tween_callback(queue_free)
	_spawn_drop.call_deferred()
	died.emit(self)


func _spawn_drop() -> void:
	if randf() > drop_chance:
		return
	var scene := get_tree().current_scene
	if scene == null:
		return
	var pu := Pickup.new()
	pu.name = "HealOrb"
	scene.add_child(pu)
	pu.global_position = global_position + Vector3(0, 0.6, 0)


# ------------------------------------------------------------------ visuals --

func _add_box_shape(area: Area3D, size: Vector3, pos: Vector3) -> void:
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	col.position = pos
	area.add_child(col)


func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


func _pivot(parent: Node3D, node_name: String, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.name = node_name
	n.position = pos
	parent.add_child(n)
	return n


## Skeletal-style rig made of pivots (hips, upper body, shoulders) so limbs can swing.
func _build_visual() -> void:
	_body_mat = StandardMaterial3D.new()
	_body_mat.albedo_color = Color(0.17, 0.16, 0.22)
	_body_mat.roughness = 0.5
	_body_mat.metallic = 0.5
	var trim := StandardMaterial3D.new()
	trim.albedo_color = Color(0.32, 0.12, 0.45)
	trim.roughness = 0.7
	var steel := StandardMaterial3D.new()
	steel.albedo_color = Color(0.6, 0.62, 0.7)
	steel.roughness = 0.3
	steel.metallic = 0.8
	_eye_mat = StandardMaterial3D.new()
	_eye_mat.albedo_color = EYE_IDLE
	_eye_mat.emission_enabled = true
	_eye_mat.emission = EYE_IDLE
	_eye_mat.emission_energy_multiplier = 3.0

	# Legs (hip pivots)
	_leg_l = _pivot(visual, "LegLPivot", Vector3(-0.22, 0.85, 0))
	_box(_leg_l, "Leg", Vector3(0.3, 0.85, 0.32), Vector3(0, -0.425, 0), _body_mat)
	_box(_leg_l, "Boot", Vector3(0.34, 0.16, 0.44), Vector3(0, -0.77, -0.05), steel)
	_leg_r = _pivot(visual, "LegRPivot", Vector3(0.22, 0.85, 0))
	_box(_leg_r, "Leg", Vector3(0.3, 0.85, 0.32), Vector3(0, -0.425, 0), _body_mat)
	_box(_leg_r, "Boot", Vector3(0.34, 0.16, 0.44), Vector3(0, -0.77, -0.05), steel)

	# Upper body (pivot at the waist, leans / recoils)
	_upper = _pivot(visual, "Upper", Vector3(0, 0.85, 0))
	_box(_upper, "Torso", Vector3(0.85, 0.95, 0.5), Vector3(0, 0.45, 0), _body_mat)
	_box(_upper, "Tabard", Vector3(0.4, 0.8, 0.04), Vector3(0, 0.25, -0.27), trim)
	_box(_upper, "RuneGem", Vector3(0.12, 0.12, 0.04), Vector3(0, 0.6, -0.27), _eye_mat)
	_box(_upper, "PauldronL", Vector3(0.4, 0.22, 0.5), Vector3(-0.6, 0.87, 0), steel)
	_box(_upper, "PauldronR", Vector3(0.4, 0.22, 0.5), Vector3(0.6, 0.87, 0), steel)
	_box(_upper, "Helmet", Vector3(0.46, 0.5, 0.46), Vector3(0, 1.13, 0), steel)
	_box(_upper, "Crest", Vector3(0.08, 0.2, 0.4), Vector3(0, 1.45, 0), trim)
	_box(_upper, "EyeL", Vector3(0.1, 0.06, 0.04), Vector3(-0.1, 1.15, -0.24), _eye_mat)
	_box(_upper, "EyeR", Vector3(0.1, 0.06, 0.04), Vector3(0.1, 1.15, -0.24), _eye_mat)

	# Left arm swings with the walk cycle
	_arm_l = _pivot(_upper, "ArmLPivot", Vector3(-0.58, 0.75, 0))
	_box(_arm_l, "Arm", Vector3(0.24, 0.8, 0.26), Vector3(0, -0.35, 0), _body_mat)
	_box(_arm_l, "Fist", Vector3(0.28, 0.2, 0.3), Vector3(0, -0.8, 0), steel)

	# Right arm + weapon (animated by the attack code)
	_weapon = _pivot(_upper, "WeaponPivot", Vector3(0.58, 0.75, 0))
	_weapon.rotation_degrees.x = -10.0
	_box(_weapon, "ArmR", Vector3(0.24, 0.8, 0.26), Vector3(0, -0.35, 0), _body_mat)
	_box(_weapon, "Handle", Vector3(0.08, 0.3, 0.08), Vector3(0, -0.75, 0), trim)
	_box(_weapon, "Blade", Vector3(0.14, 1.2, 0.05), Vector3(0, -1.5, 0), steel)
	_box(_weapon, "BladeGlow", Vector3(0.02, 1.1, 0.06), Vector3(0, -1.5, 0), _eye_mat)


## Walk cycle, leaning, attack anticipation, hit recoil and breathing.
func _animate(delta: float) -> void:
	var speed := Vector2(velocity.x, velocity.z).length()
	var walk := clampf(speed / maxf(move_speed, 0.1), 0.0, 1.0) if state != State.DEAD else 0.0
	_walk_phase += delta * (4.0 + speed * 2.0)
	var swing := sin(_walk_phase) * 0.75 * walk
	var k := 1.0 - exp(-20.0 * delta)
	_leg_l.rotation.x = lerpf(_leg_l.rotation.x, swing, k)
	_leg_r.rotation.x = lerpf(_leg_r.rotation.x, -swing, k)
	_arm_l.rotation.x = lerpf(_arm_l.rotation.x, -swing * 0.8, k)

	var lean := 0.0  # negative = forward
	match state:
		State.CHASE:
			lean = -0.12 * walk
		State.ATTACK:
			var windup_end := attack_windup
			var active_end := attack_windup + attack_active
			if _attack_t < windup_end:
				lean = lerpf(0.0, 0.3, _attack_t / windup_end)           # rear back
			elif _attack_t < active_end:
				lean = -0.4                                              # lunge
			else:
				lean = lerpf(-0.4, 0.0, clampf((_attack_t - active_end) / attack_recovery, 0.0, 1.0))
	_recoil = move_toward(_recoil, 0.0, delta * 4.0)
	lean += 0.5 * _recoil
	_upper.rotation.x = lerpf(_upper.rotation.x, lean, 1.0 - exp(-16.0 * delta))
	_upper.scale = Vector3(1.0, 1.0 + sin(_t * 2.2) * 0.012, 1.0)
	visual.position.y = absf(sin(_walk_phase)) * 0.05 * walk
