extends RefCounted
## Tiny one-shot particle bursts (CPUParticles3D, no external assets).

static func burst(from: Node, pos: Vector3, color: Color, amount := 14, speed := 4.0, lifetime := 0.5, gravity_y := -9.0) -> void:
	var scene := from.get_tree().current_scene
	if scene == null:
		return
	var p := CPUParticles3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.05
	mesh.height = 0.1
	mesh.radial_segments = 4
	mesh.rings = 2
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 3.0
	mesh.material = mat
	p.mesh = mesh
	p.amount = amount
	p.lifetime = lifetime
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, gravity_y, 0)
	p.emitting = true
	scene.add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
