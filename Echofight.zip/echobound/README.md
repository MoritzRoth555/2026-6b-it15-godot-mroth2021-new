# ECHOBOUND – THE LAST LOOP

3D-Roguelike in **Godot 4.3+** (GDScript, Forward+). Jeder Tod wird als Echo gespeichert,
das im nächsten Run an deiner Seite kämpft. Alle Assets bestehen aus Godot-Primitiven.

## Starten
1. Godot 4.3 oder neuer öffnen → *Import* → `project.godot` wählen.
2. Beim ersten Öffnen kurz warten (Import/Cache in `.godot/`).
3. `F5` startet das Hauptmenü (`ui/main_menu.tscn`) → *Spielen* lädt `scenes/Main.tscn`.

## Steuerung
| Taste | Aktion |
|---|---|
| WASD | Bewegen |
| Maus | Umsehen (First Person) |
| Shift | Sprinten |
| Leertaste | Springen |
| Q | Dash (1,2 s Cooldown, Unverwundbarkeit während des Dashs) |
| Linksklick | Schwertangriff (0,55 s Cooldown) |
| Rechtsklick | **Echo-Bolzen** (durchschlagend, 3 s Cooldown, lila Leiste im HUD) |
| K | Debug: sofort sterben (zum Testen der Echos) |
| F9 | Debug: Fortschritt löschen (Save, Echos, Stats) |
| Esc | Pause-Menü (Weiterspielen / Hauptmenü / Beenden / Lautstärke) |
| F3 | FPS-Anzeige ein/aus |

Input-Actions werden in `scripts/input_setup.gd` per Code registriert.

## Assets
Ordner `assets/models/<name>/` werden automatisch erkannt (`scripts/asset_loader.gd`, Formate glb/gltf/fbx/blend/obj),
Modelle werden auf passende Größe skaliert. Gibt es nichts, springt das Spiel auf Primitive zurück.
- **Kristall:** `crystal/crystal.fbx` (eingebunden, blau emissiv überfärbt)
- **Steine:** Textur aus dem Stone-Pack (`stones/stone_base_color.jpg`) auf Boden, Wänden, Säulen und Felsen.
  Das `.usdz` selbst kann Godot nicht laden → in Blender importieren, als `stones.glb` nach `assets/models/stones/` exportieren.
- **Ritter:** `.blend` in Blender als `knight.glb` (glTF 2.0, Texturen einbetten) nach `assets/models/knight/` exportieren.
  Er erscheint dann als blaue Echo-Statue vor dem Spawn und wird in Phase 3 das Echo-Modell.

## Fortschritt
- [x] **Phase 1** – Struktur, Dungeon, Spieler, Kamera
- [x] **Phase 2** – Schwertangriff, Dungeon Guard, Lebenspunkte
- [x] **Phase 3** – Echo-Aufnahme/-Wiedergabe
- [x] **Phase 4** – Mehrere Echos, Run-Management
- [x] **Phase 5** – Upgrades
- [ ] Phase 6 – UI, Menüs, Effekte
- [x] Phase 7 (Teil 1) – **Boss THE ECHO KEEPER**
- [x] **Phase 6** – Hauptmenü, Pause, Game-Over, Dark-Fantasy-HUD, Audio

## Architektur-Entscheidungen
- **Szenen minimal, Geometrie im Code:** `Dungeon.tscn` ist nur ein Wurzelknoten; `dungeon.gd`
  erzeugt Boden, Wände, Säulen, Kristalle, Spawn-Marker und Portal. Das ist robuster als von Hand
  geschriebene `.tscn`-Dateien und lässt sich später für zufällige Räume wiederverwenden.
- **Physik-Layer:** 1 world, 2 player, 3 enemy, 4 echo, 5 hitbox (siehe `project.godot`).
- **Kamera:** First Person. Maus dreht den Körper (Yaw) und `Head` (Pitch). Das Schwert hängt als Viewmodel an der Kamera (`SwordPivot`).
- **Spieler-API für spätere Phasen:** `teleport()`, Signale `jumped`/`dashed`, `speed_multiplier`,
  `dash_cooldown_left`, `sword_pivot` (Viewmodel).
- **Dungeon-API:** `get_player_spawn()`, `get_enemy_spawns()`, `set_exit_active()`, Signal `exit_entered`.

## Kampfsystem (Phase 2)
- `health_component.gd`: HP, `damaged`/`died`/`health_changed`, `invulnerable` (für Echos), `increase_max()` (Upgrades).
- `hitbox.gd` (Area3D): aktiv nur zwischen `begin_swing()` und `end_swing()`; jedes Ziel wird **pro Schlag nur einmal** getroffen.
- `hurtbox.gd` (Area3D): leitet Treffer an `target.apply_hit(damage, from_pos, source)` weiter.
- Layer: hitbox=5, hurtbox_player=6, hurtbox_enemy=7. Spieler-Schwert trifft nur Layer 7, Gegner-Angriffe nur Layer 6.
- `enemy.gd` (Dungeon Guard): State Machine IDLE → CHASE → ATTACK → DEAD, Windup-Telegraph (Waffe hebt sich, Augen rot),
  Knockback, Stagger, Treffer-Blitz, Funken, Heil-Orb-Drop (35 %). Keine Navmesh: Gegner laufen direkt auf dich zu.
- `fx.gd`: CPUParticles3D-Bursts. `debug_hud.gd`: schlichtes Test-HUD (HP, Dash, Gegnerzahl); das Dark-Fantasy-HUD folgt in Phase 6.
- Ablauf in `main.gd` (temporär, wandert in Phase 4 nach `run_manager.gd`): alle Gegner tot → Portal öffnet; Tod → Neustart nach 2,5 s.
- Hooks für Phase 3: Spieler-Signale `attack_started`, `dashed`, `jumped`; Flags `is_attacking`, `is_dashing`, `is_dead`.

## Echo-System (Phase 3)
- `echo_recording.gd`: Datensatz eines Runs – Samples (Zeit, Position, Yaw, Pitch, Zustands-Flags) mit 30 Hz plus **Events**
  (`attack` mit Schaden, `dash`, `jump`) mit Zeitstempel. Angriffe sind einzelne Events, kein Dauer-Boolean.
- `echo_recorder.gd`: nimmt nur den echten Spieler auf. Zeit = aufsummierte Physik-Delta (keine Wanduhr), Events bekommen den Zeitstempel ihres Physik-Ticks.
- `echo.gd`: spielt eine Aufnahme ab. Position wird zwischen den Samples interpoliert, jedes Event feuert **genau einmal**
  (Zeiger über die Eventliste); ein laufender Schlag blockiert einen zweiten. Eigener Hitbox (trifft Gegner), **keine Hurtbox → kein Schaden**.
  Der Echo nimmt nichts auf (er ist nie Ziel des Recorders). Blau-transparentes Ghost-Material; nutzt `assets/models/knight/` falls vorhanden.
  Am Ende der Aufnahme (= dein Todeszeitpunkt) löst er sich auf.
- `echo_manager.gd`: speichert alle Aufnahmen (nur anhängen, nie überschreiben), startet pro Run einen Echo je Aufnahme
  (maximal die neuesten 8 gleichzeitig, `max_active_echoes`) und die neue Aufnahme. Kürzere Runs als ~0,3 s werden verworfen.
- Ablauf: Run startet → `begin_run()`; Tod → `end_run()` speichert → Neustart → alle bisherigen Echos kämpfen mit.
- Bewusst einfach (wie gefordert): Echos spielen nur Positionen/Aktionen ab. Gegner ignorieren Echos (greifen nur dich an).
  Da Gegner nicht deterministisch sind, treffen Echo-Schläge nur, wenn Gegner zufällig am selben Ort sind wie damals.

## Run-Management (Phase 4)
- `run_manager.gd` (aus `main.gd` ausgelagert): Arena-Reset, Kills, Score, Run-Zähler, Highscore, Tod-/Sieg-Behandlung.
  `main.gd` verdrahtet nur noch HUD, EchoManager und RunManager.
- **Run-Ende:** durch Tod **oder** durch das geöffnete Portal (alle Gegner tot). Beides speichert einen Echo; nach 3 s startet der nächste Run.
- **Neustart:** volle HP, frische Cooldowns, Gegner neu gespawnt, Portal gesperrt, neue Aufnahme; alte Echos laufen mit.
- **Score:** Kills × 100 (+1000 bei Sieg). Persistent: Gesamt-Runs, Gesamt-Kills, Siege, bester Score, beste Kills, schnellste Siegzeit.
- **Speichern:** `user://echobound_save.json` (Godot: *Projekt → Benutzerdatenordner öffnen*). Enthält Stats und alle Echo-Aufnahmen,
  Echos überleben also einen Spielneustart. Speicherlimit 30 Aufnahmen (nur darüber fliegt die älteste raus); gleichzeitig spielen die neuesten 8.
  Defekte oder fehlende Dateien → frischer Stand. `F9` löscht alles.
- Der Run-Zähler zählt über alle Sessions weiter.

## Upgrades (Phase 5)
- **Ablauf:** Alle Gegner tot → kurze Pause → Menü mit **3 zufälligen, verschiedenen Upgrades** (Klick oder Taste 1/2/3) → Portal öffnet sich.
  Das Spiel ist im Menü pausiert (Recorder, Echos und Gegner frieren gemeinsam ein, die Echo-Synchronisation bleibt exakt).
- **Pool:** Klingenschärfe (+20 % Schaden), Eiserner Wille (+25 max. HP), Windschritt (+10 % Tempo),
  Flinke Klinge (−12 % Angriffs-Cooldown), Schattenschritt (−15 % Dash-Cooldown). Upgrades stapeln sich.
- **Persistent (Entwurfsentscheidung):** Upgrades gehen beim Tod nicht verloren, sondern werden gespeichert und zu Beginn jedes Runs
  neu angewendet (Meta-Progression, wie die Echos). `F9` setzt sie zurück. Werte stehen als Konstanten in `upgrade_manager.gd`.
- **Echos:** Jeder aufgezeichnete Angriff enthält den damaligen Schaden – ein Echo trägt also deine Upgrades von damals.
- Die Statuswerte werden immer aus Basiswert + Stufe neu berechnet (idempotent), nie addiert.

## Zweiter Angriff: Echo-Bolzen
- **Rechtsklick:** ein schneller, **durchschlagender** Energiebolzen (35 Schaden × Schadens-Multiplikator, 3 s Cooldown) aus der linken Hand
  zum Fadenkreuz (Rückstoß-Animation der Hand, Orb leuchtet auf). Trifft jeden Gegner im Weg einmal, stoppt an Wänden und Boden (`projectile.gd`).
- **Echos feuern ihn mit:** der Bolzen wird als Event `bolt` (mit Schaden) aufgezeichnet und vom Echo in Blickrichtung (inkl. Neigung) wiedergegeben.
- **Upgrade „Echo-Resonanz“:** +25 % Bolzenschaden, −12 % Bolzen-Cooldown (stapelbar).
- Werte: `bolt_damage`, `bolt_cooldown`, `bolt_speed` am Spieler (`player.gd`).

## Schwierigkeit (angehoben)
- **Wellen statt einer Gruppe:** 3 Wellen vor dem Boss (5 Wachen → 3 Wachen + 4 Späher → 3 Wachen + 2 Späher + 2 Brutes), nach jeder Welle eine Upgrade-Wahl.
  Neue Typen: **Späher** (schnell, fragil, erkennen dich auf 40 m) und **Brute** (groß, 170 HP, 28 Schaden, kaum zu staggern).
- **Echo-Last:** je 2 aktive Echos +1 Wache pro Welle (max. +4) – deine Verstärkung zieht mehr Gegner an.
- **Stärkere Wachen:** 70 HP (vorher 60), 18 Schaden (15), schneller (3,8), kürzeres Windup (0,45 s), Erkennung 16 m, seltenere Heil-Orbs (25 %, 15 HP statt 20).
- **Boss:** 900 HP (600), 36 Nahkampf- / 30 Schockwellen-Schaden, schneller, Schockwelle alle 6 s; **ruft Späher** bei 50 % (3) und 25 % (4) HP.
- **Upgrades gelten nur noch pro Run** (`persistent_upgrades := false` in `run_manager.gd`; auf `true` setzen für die alte Meta-Progression). Echos und Highscore bleiben persistent.
- Schutzzeit nach einem Treffer 0,35 s (vorher 0,45 s).
- Alle Zahlen sind Konstanten bzw. `@export`-Werte (`enemy.gd`, `boss.gd`, `run_manager.gd`: `WAVES`, `_spawn_enemy`).

## Menüs, HUD & Audio (Phase 6)
- **Hauptmenü** (`main_menu.gd`, Startszene): Titel mit Echo-Geistern, Partikel, Spielen / Fortschritt löschen (Doppelklick-Bestätigung) / Beenden, Lifetime-Stats.
- **Pause** (`pause_menu.gd`): Esc; ignoriert, wenn Upgrade- oder Game-Over-Screen das Spiel schon pausieren. Master-Lautstärke-Regler.
- **Game-Over / Sieg** (`game_over.gd`): Zusammenfassung (Kills, Boss, Zeit, Score, Highscore, Echo-Nr.), „Nächster Run“ oder „Hauptmenü“.
  Kein Auto-Restart mehr; der Bildschirm erscheint 1,6 s nach dem Tod, damit die Todesanimation läuft.
- **HUD** (`hud.gd`, ersetzt `debug_hud.gd`): Status-Panel (Run, Echos, Gegner), Score-Panel, Lebensbalken mit „Ghost“-Verlustanzeige,
  Dash-Leiste, Upgrade-Liste, Boss-Balken, Meldungen, Fadenkreuz, Steuerungshinweis (blendet sich nach 14 s aus), Vignette. Gemeinsamer Stil in `ui_theme.gd`.
- **Audio-Schnittstelle** (`audio_manager.gd`): beliebige Skripte rufen `get_tree().call_group("audio", "play", "hit", global_position)`
  (3D) bzw. ohne Position (2D) auf. Suchreihenfolge: `assets/audio/<name>.ogg|wav|mp3` → **synthetisierter Platzhalter** (`sfx_synth.gd`) → Stille. Es gibt nie Fehler.
  Namen: `sword_swing, echo_swing, enemy_swing, enemy_windup, hit, player_hurt, player_death, enemy_death, dash, jump, pickup, upgrade,
  echo_spawn, arena_clear, portal_open, boss_roar, boss_charge, boss_slam, boss_wave, boss_death, ui_hover, ui_click, run_win, run_lose, ambience`.
  Eigene Dateien mit genau diesen Namen in `assets/audio/` ersetzen die Platzhalter automatisch.

## Boss: THE ECHO KEEPER
- **Ablauf:** Guards besiegen → Upgrade-Wahl → der Boss erhebt sich aus dem inneren Sigil (3 s, unverwundbar, Boss-Lebensbalken oben) →
  Boss besiegt → Belohnung (3 Heil-Orbs à 40 HP, **zweite Upgrade-Wahl**, +500 Score, Statistik „Bosse besiegt“) → Portal öffnet → Sieg.
- **Werte (`boss.gd`, alles `@export`):** 600 HP, Tempo 2,3 (wütend 3,1), Nahkampf 30 Schaden (Windup 1,1 s – langsam, gut lesbar), Spezial 25 Schaden.
- **Nahkampf:** Zweihand-Schwert hebt sich über den Kopf, Einschlag mit Staub und Kamerawackeln.
- **Spezialattacke „Schockwelle“:** Boss hebt beide Arme, rote Warnung am Boden (1,4 s), dann läuft ein Ring bis 24 m nach außen.
  Ausweichen durch **Springen** oder **Dash** (Unverwundbarkeit). Echos nehmen keinen Schaden.
- **Wut ab 50 % HP:** schneller, kürzere Telegraphs, häufigere Schockwellen, rotes Leuchten.
- **Echos treffen den Boss** (gleiche Hurtbox-Ebene wie die Wachen).
- Bossmodell aus Primitiven: Rüstung, leuchtender Echo-Kern, Hörnerkrone, kreisende Echo-Splitter, Riesenschwert; Pivots für Geh-/Angriffs-Animation.

## Grafik & Animation (Überarbeitung)
- **Umgebung:** pulsierende Kristalle (Emission + Licht), leuchtende Bodensiegel (Ringe + Speichen), Lichtbänder an den Wänden und
  Runenringe an den Säulen (alle pulsieren), treibender Magie-Staub, leichte Farbkorrektur (Kontrast/Sättigung).
- **Portal:** animierter Wirbel-Shader (gesperrt: violett/langsam, offen: türkis/schnell).
- **HUD:** Vignette-Shader (dauerhaft leicht), roter Treffer-Rand, pulsierender Rand bei niedrigen Lebenspunkten.
- **Spieler (Ego):** Atmen im Stand, Lauf-Wippen (stärker beim Sprinten), Sprint-Haltung, Dash-Rückzug, Landungs-Dip, Strafe-Neigung der Kamera,
  Schwert mit Parierstange/Hohlkehle/Spitze, linke Hand mit pulsierender Echo-Kugel, Schlag mit Ausholen + Vorstoß des ganzen Arms,
  leuchtender Schwung-Bogen und kurzer Hit-Stop (Zeitlupe 0,05 s) bei Treffern (läuft in Spielzeit, Echos bleiben synchron).
- **Dungeon Guard:** Rig aus Pivots – Beine/linker Arm schwingen im Gehzyklus, Oberkörper lehnt sich vor, holt beim Angriff aus (zurücklehnen → Ausfall),
  Rückstoß bei Treffer, Atmen im Stand, leuchtendes Runen-Juwel, aufsteigende Seelen beim Tod.
- **Echo:** Beine/Arm schwingen nach den aufgezeichneten Zuständen (Gehen/Sprint), flimmernde Emission, Boden-Ring, Partikelschweif, Auflösung mit aufsteigenden Funken.
- Alles ohne externe Assets; Partikel sind CPU-Partikel (insgesamt wenige hundert), neue Leuchtobjekte werfen keine Schatten.

## Performance
- Bodenfliesen: 2 MultiMeshes statt 64 Einzel-Meshes, ohne Schattenwurf.
- Deko (Kristalle) wirft keine Schatten, Distanz-Culling ab 45 m; nur jede 2. Kristallgruppe hat ein Licht (mit Distanz-Fade).
- Sonnenlicht: ein einziger Shadow-Split, 45 m Reichweite, Shadowmap 2048.
- Kein MSAA mehr, stattdessen FXAA; Texturen ohne anisotropen Filter.
- FPS-Anzeige im Test-HUD (links oben). Falls es weiter ruckelt: Projekteinstellungen → Rendering → Renderer auf *Mobile* oder
  *Compatibility* stellen und/oder `glow_enabled` in `dungeon.gd` ausschalten.

## Teststatus
Phase 1 und 2 wurden **nicht in Godot ausgeführt** (keine Godot-Binary in der Entwicklungsumgebung). Der Code
wurde nur manuell geprüft. Bitte einmal starten und Fehler aus dem *Output*-Panel melden.
