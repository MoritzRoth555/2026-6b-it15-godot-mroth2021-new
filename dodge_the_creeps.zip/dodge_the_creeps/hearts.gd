extends Control

const MAX_LIVES: int = 3

var lives: int = 3:
	set(value):
		lives = value
		queue_redraw()


func _heart(center: Vector2, s: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 40:
		var t: float = TAU * i / 40.0
		var x: float = 16.0 * pow(sin(t), 3)
		var y: float = -(13.0 * cos(t) - 5.0 * cos(2.0 * t) - 2.0 * cos(3.0 * t) - cos(4.0 * t))
		pts.append(center + Vector2(x, y) * s)
	return pts


func _draw() -> void:
	for i in MAX_LIVES:
		var pts := _heart(Vector2(20 + i * 40, 18), 0.9)
		var closed := pts.duplicate()
		closed.append(pts[0])
		if i < lives:
			draw_colored_polygon(pts, Color("ff4d6d"))
			draw_polyline(closed, Color("ffffff"), 2.0)
		else:
			draw_polyline(closed, Color(1, 1, 1, 0.35), 2.0)
