extends Node

const SAVE_PATH := "user://highscore.save"

@export var mob_scene: PackedScene
@export var coin_scene: PackedScene
@export var bullet_scene: PackedScene

var game_running: bool = false
var score: int = 0
var high_score: int = 0
var speed_bonus: float = 0.0
var level: int = 1
var lives: int = 3
var shoot_cooldown: float = 0.0


func _ready() -> void:
	# Spawn-Pfad entlang der Bildschirmkante
	var curve := Curve2D.new()
	curve.add_point(Vector2(0, 0))
	curve.add_point(Vector2(480, 0))
	curve.add_point(Vector2(480, 720))
	curve.add_point(Vector2(0, 720))
	curve.add_point(Vector2(0, 0))
	$MobPath.curve = curve
	Input.set_default_cursor_shape(Input.CURSOR_CROSS)
	load_high_score()
	update_labels()
	show_message("DODGE THE CREEPS\n\nDu hast 3 Leben!\nWeiche den Monstern aus\nund sammle Münzen (+5)\n\nZielen: Maus\nSchießen: Linksklick / Leertaste\n\nEnter zum Starten")


func _process(delta: float) -> void:
	shoot_cooldown -= delta
	if game_running and shoot_cooldown <= 0.0 and Input.is_action_pressed("shoot"):
		shoot()


func _unhandled_input(event: InputEvent) -> void:
	if not game_running and event.is_action_pressed("ui_accept"):
		new_game()


func new_game() -> void:
	get_tree().call_group("mobs", "queue_free")
	get_tree().call_group("coins", "queue_free")
	get_tree().call_group("bullets", "queue_free")
	score = 0
	level = 1
	lives = 3
	speed_bonus = 0.0
	$MobTimer.wait_time = 0.6
	$Background.modulate = Color.from_hsv(0.58, 0.35, 0.8)
	$HUD/MessageLabel.hide()
	$HUD/Dim.hide()
	update_labels()
	$Player.start($StartPosition.position)
	$MobTimer.start()
	$ScoreTimer.start()
	$CoinTimer.start()
	game_running = true


func _on_player_hit() -> void:
	lives -= 1
	update_labels()
	burst($Player.position, Color("ff4d6d"), 24)
	shake_screen()
	if lives > 0:
		$Player.hurt()
	else:
		game_over()


func game_over() -> void:
	game_running = false
	$Player.die()
	$MobTimer.stop()
	$ScoreTimer.stop()
	$CoinTimer.stop()
	var message := "GAME OVER\n\nPunkte: %d\nLevel: %d" % [score, level]
	if score > high_score:
		high_score = score
		save_high_score()
		message += "\n\nNEUER REKORD!"
	message += "\n\nEnter für Neustart"
	update_labels()
	show_message(message)


func _on_score_timer_timeout() -> void:
	# Jede Sekunde: Punkt + das Spiel wird schwerer
	score += 1
	speed_bonus = minf(speed_bonus + 4.0, 250.0)
	$MobTimer.wait_time = maxf($MobTimer.wait_time - 0.015, 0.2)
	var new_level: int = 1 + score / 15
	if new_level != level:
		level = new_level
		# Hintergrundfarbe wechselt mit jedem Level
		var tween := create_tween()
		tween.tween_property($Background, "modulate", Color.from_hsv(fmod(0.58 + level * 0.11, 1.0), 0.35, 0.8), 1.0)
	update_labels()


func _on_coin_timer_timeout() -> void:
	var coin = coin_scene.instantiate()
	coin.position = Vector2(randf_range(40, 440), randf_range(60, 680))
	coin.collected.connect(_on_coin_collected)
	coin.add_to_group("coins")
	add_child(coin)


func _on_coin_collected(pos: Vector2) -> void:
	score += 5
	burst(pos, Color("ffd60a"), 14)
	update_labels()


func _on_mob_timer_timeout() -> void:
	var mob = mob_scene.instantiate()
	var spawn: PathFollow2D = $MobPath/MobSpawnLocation
	spawn.progress_ratio = randf()
	mob.position = spawn.position

	var direction: float = spawn.rotation + PI / 2
	direction += randf_range(-PI / 4, PI / 4)
	mob.rotation = direction

	var velocity := Vector2(randf_range(150.0 + speed_bonus, 250.0 + speed_bonus), 0.0)
	mob.linear_velocity = velocity.rotated(direction)
	mob.add_to_group("mobs")
	add_child(mob)


func shoot() -> void:
	shoot_cooldown = 0.28
	var dir: Vector2 = ($Player.position + Vector2(0, 12)).direction_to(get_viewport().get_mouse_position())
	var bullet = bullet_scene.instantiate()
	bullet.position = $Player.position + Vector2(0, 12) + dir * 34
	bullet.velocity = dir * bullet.SPEED
	bullet.killed.connect(_on_mob_killed)
	bullet.add_to_group("bullets")
	add_child(bullet)
	burst(bullet.position, Color("ffd60a"), 5)


func _on_mob_killed(pos: Vector2) -> void:
	score += 2
	burst(pos, Color("ff9f1c"), 18)
	update_labels()


func update_labels() -> void:
	$HUD/ScoreLabel.text = "Punkte: %d   Level: %d" % [score, level]
	$HUD/HighScoreLabel.text = "Rekord: %d" % high_score
	$HUD/Hearts.lives = lives


func show_message(text: String) -> void:
	$HUD/MessageLabel.text = text
	$HUD/MessageLabel.show()
	$HUD/Dim.show()


func shake_screen() -> void:
	var tween := create_tween()
	for i in 8:
		tween.tween_property($Camera2D, "offset", Vector2(randf_range(-14, 14), randf_range(-14, 14)), 0.04)
	tween.tween_property($Camera2D, "offset", Vector2.ZERO, 0.05)


func save_high_score() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_32(high_score)


func load_high_score() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if file:
			high_score = file.get_32()


# Kleine Partikel-Explosion (Münze eingesammelt / Treffer)
func burst(pos: Vector2, color: Color, amount: int) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = amount
	p.lifetime = 0.6
	p.spread = 180.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 80.0
	p.initial_velocity_max = 220.0
	p.scale_amount_min = 3.0
	p.scale_amount_max = 7.0
	p.color = color
	p.emitting = true
	add_child(p)
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)
