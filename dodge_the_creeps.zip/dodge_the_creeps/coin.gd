extends Area2D

signal collected(pos: Vector2)

var time: float = 0.0


func _ready() -> void:
	area_entered.connect(_on_area_entered)
	# Münze "poppt" auf und verschwindet nach 5 Sekunden wieder
	scale = Vector2.ZERO
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)
	tween.tween_interval(3.5)
	tween.tween_property(self, "modulate:a", 0.0, 1.0)
	tween.tween_callback(queue_free)


func _process(delta: float) -> void:
	time += delta
	queue_redraw()


func _draw() -> void:
	var squash: float = abs(cos(time * 3.0)) * 0.7 + 0.3  # Münze "dreht" sich
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(squash, 1.0))
	draw_circle(Vector2.ZERO, 16, Color("e09f00"))
	draw_circle(Vector2.ZERO, 13, Color("ffd60a"))
	draw_arc(Vector2.ZERO, 9, 0, TAU, 24, Color("ffee88"), 2.0)
	draw_circle(Vector2(-4, -5), 3, Color(1, 1, 1, 0.7))


func _on_area_entered(area: Area2D) -> void:
	# Nur der Spieler (Area2D mit start()) kann Münzen sammeln
	if area.has_method("start"):
		set_deferred("monitoring", false)
		collected.emit(position)
		queue_free()
