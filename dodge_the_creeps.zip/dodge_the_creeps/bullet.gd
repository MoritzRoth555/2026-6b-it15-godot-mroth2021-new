extends Area2D

signal killed(pos: Vector2)

const SPEED: float = 700.0

var velocity: Vector2 = Vector2.ZERO


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	position += velocity * delta
	# Außerhalb des Bildschirms löschen
	if position.x < -30 or position.x > 510 or position.y < -30 or position.y > 750:
		queue_free()


func _draw() -> void:
	draw_circle(Vector2.ZERO, 10, Color(1, 0.84, 0.04, 0.3))
	draw_circle(Vector2.ZERO, 6, Color("ffd60a"))
	draw_circle(Vector2.ZERO, 3, Color.WHITE)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("mobs"):
		set_deferred("monitoring", false)
		killed.emit(body.position)
		body.queue_free()
		queue_free()
