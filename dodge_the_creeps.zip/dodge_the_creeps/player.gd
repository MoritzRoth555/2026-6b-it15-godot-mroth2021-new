extends Area2D

signal hit

@export var speed: int = 400
var screen_size: Vector2
var blink_tween: Tween


func _ready() -> void:
	screen_size = get_viewport_rect().size
	hide()


func _process(delta: float) -> void:
	var velocity: Vector2 = Vector2.ZERO
	if Input.is_action_pressed("move_right"):
		velocity.x += 1
	if Input.is_action_pressed("move_left"):
		velocity.x -= 1
	if Input.is_action_pressed("move_down"):
		velocity.y += 1
	if Input.is_action_pressed("move_up"):
		velocity.y -= 1

	if velocity.length() > 0:
		velocity = velocity.normalized() * speed
		$AnimatedSprite2D.play()
	else:
		$AnimatedSprite2D.stop()

	position += velocity * delta
	position = position.clamp(Vector2.ZERO, screen_size)
	queue_redraw()

	# Animationsauswahl
	if velocity.x != 0:
		$AnimatedSprite2D.animation = "walk"
		$AnimatedSprite2D.flip_v = false
		$AnimatedSprite2D.flip_h = velocity.x < 0
	elif velocity.y != 0:
		$AnimatedSprite2D.animation = "up"
		$AnimatedSprite2D.flip_v = velocity.y > 0


# Kleine Laserpistole, zeigt immer zur Maus
func _draw() -> void:
	draw_set_transform(Vector2(0, 12), get_local_mouse_position().angle())
	draw_rect(Rect2(4, -4, 22, 8), Color("495057"))
	draw_rect(Rect2(22, -5, 10, 10), Color("adb5bd"))
	draw_rect(Rect2(4, 0, 8, 10), Color("343a40"))
	draw_rect(Rect2(30, -2, 4, 4), Color("ff4d6d"))


func _on_body_entered(body: Node2D) -> void:
	hit.emit()
	$CollisionShape2D.set_deferred("disabled", true)


# Leben verloren, aber noch im Spiel: kurz blinken und unverwundbar sein
func hurt() -> void:
	_stop_blink()
	blink_tween = create_tween()
	for i in 6:
		blink_tween.tween_property(self, "modulate:a", 0.25, 0.12)
		blink_tween.tween_property(self, "modulate:a", 1.0, 0.12)
	blink_tween.tween_callback(func(): $CollisionShape2D.set_deferred("disabled", false))


# Letztes Leben verloren
func die() -> void:
	_stop_blink()
	hide()


func start(pos: Vector2) -> void:
	_stop_blink()
	position = pos
	show()
	$CollisionShape2D.disabled = false


func _stop_blink() -> void:
	if blink_tween:
		blink_tween.kill()
	modulate.a = 1.0
